import CrisisSupport from '../CrisisSupport';

export default function CrisisSupportExample() {
  return (
    <div className="p-8 max-w-md mx-auto">
      <CrisisSupport />
    </div>
  );
}
