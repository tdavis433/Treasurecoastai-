Paste into Replit AI:

STACK: Vite + React + TypeScript + Tailwind + Express backend + wouter routing.
Goal: Add a new landing page at /landing-preview (do not replace existing landing yet).

1) Add landing component:
- Create/replace: client/src/pages/LandingPreview.tsx using the file in this zip.
- Verify the hero background uses: /landing/assets/backgrounds/tca-hero-bg-4k.jpg
- Background must NOT repeat (cover + no-repeat) and must fade into #0B0E13 at the bottom.

2) Add routing:
- Edit client/src/App.tsx and add:
  import LandingPreview from "./pages/LandingPreview";
  <Route path="/landing-preview" component={LandingPreview} />

3) Verify build:
- Open /landing-preview and confirm nav + buttons scroll to sections, /login works.

Do NOT delete existing routes/pages.
