# Treasure Coast AI — Full Asset Pack (Poster Vibe + Functional Landing)

## What this zip includes
- **All generated assets** (backgrounds, orbs, neon wave, UI frames, widget elements, icons)
- A working React component for Vite + React + Tailwind + wouter:
  - `client/src/pages/LandingPreview.tsx`

## Install steps (Vite + React + Tailwind + wouter)
1) Copy everything in this zip into your repo (merge folders).
2) Ensure assets are under:
   - `client/public/landing/assets/...`
3) Add route to `client/src/App.tsx` (wouter):

```tsx
import LandingPreview from "./pages/LandingPreview";
<Route path="/landing-preview" component={LandingPreview} />
```

4) Visit:
- `/landing-preview`

## Notes
- Background is **one image**, set to `bg-cover bg-no-repeat` with a bottom fade overlay.
- Buttons/chips are CSS (editable).
- Included PNG frames/icons are available if you want to swap from CSS to image-based UI.
