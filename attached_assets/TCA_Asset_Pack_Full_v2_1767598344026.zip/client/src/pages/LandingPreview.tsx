import { Link } from "wouter";

/**
 * Treasure Coast AI — Poster-Vibe Functional Landing (Vite + React + Tailwind + wouter)
 * Route this component at /landing-preview
 *
 * Assets expected in Vite public folder:
 * /landing/assets/backgrounds/tca-hero-bg-4k.jpg
 * /landing/assets/decor/neon-wave-4096x1024.png
 * /landing/assets/fx/orb-cyan-2048.png
 * /landing/assets/fx/orb-magenta-2048.png
 * /landing/assets/fx/orb-violet-2048.png
 * /landing/assets/fx/noise-overlay-4k.png
 */

function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "start" });
}

export default function LandingPreview() {
  return (
    <div className="min-h-screen bg-[#0B0E13] text-white overflow-hidden">
      {/* FULL-BLEED POSTER BACKGROUND (single image, no-repeat) */}
      <div className="fixed inset-0 -z-10">
        <div
          className="absolute inset-0 bg-no-repeat bg-cover bg-center"
          style={{ backgroundImage: "url('/landing/assets/backgrounds/tca-hero-bg-4k.jpg')" }}
        />

        {/* Neon orbs (optional) */}
        <img
          src="/landing/assets/fx/orb-cyan-2048.png"
          alt=""
          className="absolute -top-48 -left-64 w-[48rem] opacity-45 mix-blend-screen pointer-events-none"
        />
        <img
          src="/landing/assets/fx/orb-violet-2048.png"
          alt=""
          className="absolute top-24 -right-72 w-[46rem] opacity-35 mix-blend-screen pointer-events-none"
        />
        <img
          src="/landing/assets/fx/orb-magenta-2048.png"
          alt=""
          className="absolute bottom-[-22rem] left-1/2 -translate-x-1/2 w-[52rem] opacity-28 mix-blend-screen pointer-events-none"
        />

        {/* Readability overlay + bottom fade (prevents any “repeat vibe”) */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/25 to-[#0B0E13]" />

        {/* Grain overlay */}
        <img
          src="/landing/assets/fx/noise-overlay-4k.png"
          alt=""
          className="absolute inset-0 w-full h-full object-cover opacity-[0.20] mix-blend-overlay pointer-events-none"
        />
      </div>

      {/* NAV */}
      <header className="sticky top-0 z-50 border-b border-white/10 bg-black/20 backdrop-blur-xl">
        <div className="mx-auto max-w-6xl px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl border border-white/15 bg-white/5 shadow-[0_0_18px_rgba(0,255,255,0.10)]" />
            <div className="font-extrabold tracking-widest">TREASURE COAST AI</div>
          </div>

          <nav className="hidden md:flex items-center gap-8 text-white/70 font-semibold">
            <button onClick={() => scrollToId("how")} className="hover:text-white">
              How it works
            </button>
            <button onClick={() => scrollToId("templates")} className="hover:text-white">
              Templates
            </button>
            <button onClick={() => scrollToId("pricing")} className="hover:text-white">
              Pricing
            </button>
          </nav>

          <div className="flex items-center gap-3">
            <Link href="/login" className="text-white/70 hover:text-white font-semibold">
              Client Login
            </Link>

            <button
              onClick={() => scrollToId("book")}
              className="rounded-full px-4 py-2 text-sm font-extrabold border border-white/15 bg-white/5
              shadow-[0_0_22px_rgba(0,255,255,0.16),inset_0_1px_0_rgba(255,255,255,0.14)]
              hover:shadow-[0_0_28px_rgba(255,0,200,0.16),0_0_26px_rgba(0,255,255,0.18)]
              transition"
            >
              Book Demo
            </button>
          </div>
        </div>
      </header>

      {/* HERO */}
      <section className="mx-auto max-w-6xl px-4 pt-14 pb-12 relative">
        <div className="grid lg:grid-cols-2 gap-10 items-center">
          {/* Left */}
          <div>
            <h1 className="text-5xl sm:text-6xl font-extrabold leading-[1.02]">
              AI Chatbots that run{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-fuchsia-300">
                your front desk 24/7.
              </span>
            </h1>

            <p className="mt-4 text-lg text-white/75 max-w-xl">
              Answer questions instantly, capture leads, and send customers to booking — without hiring staff.
            </p>

            <div className="mt-7 flex flex-wrap gap-3">
              <button
                onClick={() => scrollToId("book")}
                className="rounded-full px-6 py-3 font-extrabold border border-white/15
                bg-gradient-to-r from-cyan-400/25 to-fuchsia-500/25
                shadow-[0_0_26px_rgba(0,255,255,0.18),0_0_22px_rgba(255,0,200,0.12),inset_0_1px_0_rgba(255,255,255,0.14)]
                hover:shadow-[0_0_34px_rgba(0,255,255,0.22),0_0_28px_rgba(255,0,200,0.16)]
                transition"
              >
                Book a Live Demo →
              </button>

              <button
                onClick={() => scrollToId("templates")}
                className="rounded-full px-6 py-3 font-extrabold border border-white/15 bg-white/5
                shadow-[0_0_18px_rgba(140,80,255,0.14),inset_0_1px_0_rgba(255,255,255,0.12)]
                hover:shadow-[0_0_26px_rgba(140,80,255,0.18)]
                transition"
              >
                View Interactive Demo
              </button>
            </div>

            {/* Feature chips */}
            <div className="mt-8 flex flex-wrap gap-2 rounded-3xl border border-white/12 bg-white/5 backdrop-blur-xl px-4 py-4
                            shadow-[0_16px_40px_rgba(0,0,0,0.35),inset_0_1px_0_rgba(255,255,255,0.10)]">
              <Chip>24/7 Responses</Chip>
              <Chip>Lead Capture</Chip>
              <Chip>Booking Links</Chip>
              <Chip>Done-For-You Setup</Chip>
              <Chip>Multi-Industry Templates</Chip>
            </div>
          </div>

          {/* Right */}
          <div className="relative">
            <WidgetPreview />

            {/* Neon wave image (crisp, poster vibe) */}
            <img
              src="/landing/assets/decor/neon-wave-4096x1024.png"
              alt=""
              className="absolute left-1/2 -translate-x-1/2 bottom-[-80px] w-[120%] max-w-none opacity-90 mix-blend-screen pointer-events-none
              drop-shadow-[0_0_18px_rgba(0,255,255,0.35)]"
            />
          </div>
        </div>
      </section>

      {/* CONTENT SECTIONS */}
      <Section id="how" title="How it works">
        <div className="grid md:grid-cols-3 gap-4">
          <CardStep n="01" title="Add the widget">Copy/paste one embed. We handle setup.</CardStep>
          <CardStep n="02" title="AI chats 24/7">Answers FAQs, captures leads, routes intent.</CardStep>
          <CardStep n="03" title="Manage in one dashboard">Review convos, leads, links, settings.</CardStep>
        </div>
      </Section>

      <Section id="templates" title="Templates (Demos)">
        <div className="grid md:grid-cols-2 gap-4">
          <DemoCard name="Fade Factory" niche="Barbershop" />
          <DemoCard name="Faith House" niche="Sober Living" />
          <DemoCard name="Luxe Locks" niche="Salon" />
          <DemoCard name="Coastal Breeze Grill" niche="Restaurant" />
        </div>
      </Section>

      <Section id="pricing" title="Pricing">
        <div className="grid md:grid-cols-2 gap-4">
          <PricingCard plan="Starter" price="$29/mo" bullets={["Website widget", "FAQ + lead capture", "Basic templates", "Email alerts"]} />
          <PricingCard plan="Pro" price="$79/mo" bullets={["Everything in Starter", "Booking links", "Automated follow-ups", "Advanced configuration"]} featured />
        </div>
      </Section>

      <Section id="book" title="Book a demo">
        <div className="mx-auto max-w-xl rounded-3xl border border-white/12 bg-white/5 backdrop-blur-xl p-6">
          <div className="grid gap-3">
            <Input placeholder="Name" />
            <Input placeholder="Email" />
            <Input placeholder="Phone" />
            <textarea
              className="h-28 rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white/85 placeholder:text-white/40 outline-none"
              placeholder="Tell us your business + what you want automated…"
            />
            <button className="rounded-full px-6 py-3 font-extrabold border border-white/15 bg-gradient-to-r from-cyan-400/25 to-fuchsia-500/25
                               shadow-[0_0_26px_rgba(0,255,255,0.18),0_0_22px_rgba(255,0,200,0.12),inset_0_1px_0_rgba(255,255,255,0.14)]
                               hover:shadow-[0_0_34px_rgba(0,255,255,0.22),0_0_28px_rgba(255,0,200,0.16)]
                               transition">
              Submit →
            </button>
            <div className="text-center text-white/55 text-sm">No contracts. Cancel anytime.</div>
          </div>
        </div>
      </Section>

      <footer className="py-10 text-center text-white/50 text-sm">
        © {new Date().getFullYear()} Treasure Coast AI — Your Business, Upgraded.
      </footer>
    </div>
  );
}

/* ---------- Components ---------- */

function Chip({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-full border border-white/12 bg-white/5 px-3 py-2 text-sm font-bold text-white/80
                    shadow-[0_0_14px_rgba(0,255,255,0.08),inset_0_1px_0_rgba(255,255,255,0.10)]">
      {children}
    </div>
  );
}

function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} className="mx-auto max-w-6xl px-4 py-14">
      <h2 className="text-3xl font-extrabold">{title}</h2>
      <div className="mt-5">{children}</div>
    </section>
  );
}

function CardStep({ n, title, children }: { n: string; title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-3xl border border-white/12 bg-white/5 backdrop-blur-xl p-5
                    shadow-[0_18px_45px_rgba(0,0,0,0.38),inset_0_1px_0_rgba(255,255,255,0.10)]">
      <div className="text-white/55 font-extrabold tracking-widest">STEP {n}</div>
      <div className="mt-2 text-xl font-extrabold">{title}</div>
      <div className="mt-2 text-white/70">{children}</div>
    </div>
  );
}

function DemoCard({ name, niche }: { name: string; niche: string }) {
  return (
    <div className="rounded-3xl border border-white/12 bg-white/5 backdrop-blur-xl p-5">
      <div className="text-white/60 text-sm font-bold">{niche}</div>
      <div className="mt-1 text-2xl font-extrabold">{name}</div>
      <div className="mt-3 flex gap-3">
        <button className="rounded-full px-4 py-2 text-sm font-extrabold border border-white/12 bg-white/5 hover:bg-white/10 transition">
          View Demo
        </button>
        <button className="rounded-full px-4 py-2 text-sm font-extrabold border border-white/12 bg-white/5 hover:bg-white/10 transition">
          Use Template
        </button>
      </div>
    </div>
  );
}

function PricingCard({
  plan, price, bullets, featured,
}: { plan: string; price: string; bullets: string[]; featured?: boolean; }) {
  return (
    <div className={`rounded-3xl border backdrop-blur-xl p-6 ${
      featured ? "border-fuchsia-300/20 bg-gradient-to-b from-white/10 to-white/5 shadow-[0_0_34px_rgba(255,0,200,0.14)]"
               : "border-white/12 bg-white/5"
    }`}>
      <div className="flex items-baseline justify-between">
        <div className="text-2xl font-extrabold">{plan}</div>
        <div className="text-white/85 font-extrabold">{price}</div>
      </div>
      <ul className="mt-4 space-y-2 text-white/75">
        {bullets.map((b) => <li key={b}>• {b}</li>)}
      </ul>
      <button className="mt-6 w-full rounded-full px-6 py-3 font-extrabold border border-white/15 bg-gradient-to-r from-cyan-400/20 to-fuchsia-500/20">
        Choose {plan}
      </button>
    </div>
  );
}

function Input({ placeholder }: { placeholder: string }) {
  return (
    <input
      className="h-12 rounded-2xl border border-white/10 bg-black/30 px-4 text-white/85 placeholder:text-white/40 outline-none"
      placeholder={placeholder}
    />
  );
}

function WidgetPreview() {
  return (
    <div className="rounded-[32px] border border-white/12 bg-white/5 backdrop-blur-xl p-5
                    shadow-[0_22px_55px_rgba(0,0,0,0.45),0_0_32px_rgba(0,255,255,0.10),inset_0_1px_0_rgba(255,255,255,0.12)]">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-extrabold tracking-wide">Treasure Coast AI Assistant</div>
          <div className="text-white/55 text-sm">Live Preview</div>
        </div>
        <div className="h-10 w-10 rounded-2xl border border-white/12 bg-white/5" />
      </div>

      <div className="mt-4 space-y-3">
        <Bubble side="left">How much is a haircut?</Bubble>
        <Bubble side="left">Are you open today?</Bubble>
        <Bubble side="left">Can I book for tomorrow at 5?</Bubble>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <Pill>Lead captured</Pill>
        <Pill>Booking link sent</Pill>
        <Pill>Follow-up automated</Pill>
      </div>

      <div className="mt-4 flex items-center gap-2 rounded-2xl border border-white/10 bg-black/30 px-4 py-3">
        <div className="h-2.5 w-2.5 rounded-full bg-cyan-300/80" />
        <div className="text-white/45 text-sm">Ask anything…</div>
      </div>
    </div>
  );
}

function Bubble({ side, children }: { side: "left" | "right"; children: React.ReactNode }) {
  const base = "max-w-[92%] rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-white/85";
  return <div className={side === "right" ? `ml-auto ${base}` : base}>{children}</div>;
}

function Pill({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-extrabold text-white/80">
      {children}
    </div>
  );
}
