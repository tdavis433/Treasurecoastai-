import DemoPageTemplate from "@/components/demo/DemoPageTemplate";
import { fitnessConfig } from "@/components/demo/configs/fitness";

export default function DemoFitness() {
  return <DemoPageTemplate config={fitnessConfig} />;
}
