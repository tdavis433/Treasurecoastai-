import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import express from "express";
import rateLimit from "express-rate-limit";
import crypto from "crypto";
import { storage, db } from "./storage";
import { insertAppointmentSchema, insertClientSettingsSchema, adminUsers, type AdminRole, bots, botSettings, leads, appointments, clientSettings, workspaces, workspaceMemberships, botRequests, insertBotRequestSchema, chatSessions, conversationMessages, chatAnalyticsEvents, dailyAnalytics, passwordResetTokens, systemLogs } from "@shared/schema";
import { emailService, getPendingResetTokens, clearPendingResetTokens } from "./emailService";
import OpenAI from "openai";
import bcrypt from "bcryptjs";
import { z } from "zod";
import path from "path";
import fs from "fs";
import { eq, and, sql, desc, or, gte } from "drizzle-orm";
import {
  getBotConfig,
  getBotConfigAsync,
  getBotConfigByBotId,
  getBotConfigByBotIdAsync,
  getAllBotConfigs,
  getAllBotConfigsAsync,
  getAllTemplates,
  getTemplateById,
  getWorkspaces,
  getWorkspaceBySlug,
  createWorkspace,
  updateWorkspace,
  deleteWorkspace,
  getBotsByWorkspaceId,
  getClients,
  getClientById,
  getBotsByClientId,
  getDemoBots,
  getRealTenantBots,
  detectCrisisInMessage,
  getCrisisResponse as getBotCrisisResponse,
  buildSystemPromptFromConfig,
  saveBotConfig,
  saveBotConfigAsync,
  createBotConfig,
  registerClient,
  updateClientStatus,
  updateClientPlan,
  updateWorkspacePlan,
  getClientStatus,
  clearCache,
  type BotConfig
} from "./botConfig";
import { logConversation as logConversationToFile, getConversationLogs, getLogStats } from "./conversationLogger";
import { 
  processAutomations, 
  triggerWorkflowByEvent,
  type BotAutomationConfig, 
  type AutomationContext,
  type AutomationResult
} from "./automations";
import {
  checkMessageLimit,
  incrementMessageCount,
  incrementLeadCount,
  incrementAutomationCount,
  checkAutomationEnabled,
  getUsageSummary
} from "./planLimits";

import {
  sendLeadCreatedWebhook,
  sendLeadUpdatedWebhook,
  sendAppointmentCreatedWebhook,
  sendSessionStartedWebhook,
  sendSessionEndedWebhook,
  testWebhook
} from "./webhooks";

import { 
  getWidgetSecret, 
  getOpenAIConfig, 
  getTwilioConfig, 
  getResendApiKey,
  getAdminCredentials,
  getStaffCredentials
} from './env';

import { scrapeWebsite, applyScrapedDataToBot, importWebsite, type WebsiteImportSuggestions } from './scraper';
import { resetDemoWorkspace, seedAllDemoWorkspaces, getDemoSlugs, getDemoConfig } from './demoSeed';
import { getWidgetEmbedCode, getEmbedInstructions, type WidgetEmbedOptions } from './embed';
import { extractBookingInfoFromConversation, type ExtractedBookingInfo, type ChatMessage as OrchestratorChatMessage } from './orchestrator';
import { requireExportClientId } from './utils/tenantScope';
import { logAuditEvent, createAuditHelper, getAuditLogs, extractRequestInfo } from './auditLogger';
import { retryFetch, createNotificationRetryLogger } from './retryUtils';
import { exportClientData, deleteClientData, getRetentionConfig, purgeOldData } from './dataLifecycle';
import { INDUSTRY_TEMPLATES, type IndustryTemplate } from './industryTemplates';
import { generatePreviewToken, verifyPreviewToken, getTokenTimeRemaining, type PreviewTokenPayload } from './previewToken';
import { validateBookingUrl } from './urlValidator';
import { csrfProtection } from './csrfMiddleware';
import { structuredLogger } from './structuredLogger';
import { buildClientFromTemplate, validateTemplateForProvisioning, ensureTemplatesSeeded, type TemplateOverrides } from './templates';

// =============================================
// PHASE 2.4: SIGNED WIDGET TOKENS
// =============================================

// Widget signing secret - uses centralized env module with fallback for dev
const WIDGET_SECRET = getWidgetSecret();

// Generate a signed token for widget authentication
function generateWidgetToken(clientId: string, botId: string, expiresIn: number = 86400): string {
  const timestamp = Date.now();
  const expires = timestamp + (expiresIn * 1000);
  const payload = `${clientId}:${botId}:${expires}`;
  const signature = crypto
    .createHmac('sha256', WIDGET_SECRET)
    .update(payload)
    .digest('hex');
  // Format: base64(payload):signature
  const encodedPayload = Buffer.from(payload).toString('base64');
  return `${encodedPayload}.${signature}`;
}

// Verify a widget token and extract clientId/botId
function verifyWidgetToken(token: string): { valid: boolean; clientId?: string; botId?: string; error?: string } {
  try {
    const [encodedPayload, signature] = token.split('.');
    if (!encodedPayload || !signature) {
      return { valid: false, error: 'Invalid token format' };
    }
    
    const payload = Buffer.from(encodedPayload, 'base64').toString('utf-8');
    const [clientId, botId, expiresStr] = payload.split(':');
    
    if (!clientId || !botId || !expiresStr) {
      return { valid: false, error: 'Invalid token payload' };
    }
    
    // Verify signature
    const expectedSignature = crypto
      .createHmac('sha256', WIDGET_SECRET)
      .update(payload)
      .digest('hex');
    
    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))) {
      return { valid: false, error: 'Invalid token signature' };
    }
    
    // Check expiration
    const expires = parseInt(expiresStr, 10);
    if (Date.now() > expires) {
      return { valid: false, error: 'Token expired' };
    }
    
    return { valid: true, clientId, botId };
  } catch (error) {
    return { valid: false, error: 'Token verification failed' };
  }
}

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

// Strong password validation for new passwords and password changes
const strongPasswordSchema = z.string()
  .min(8, "Password must be at least 8 characters long")
  .max(128, "Password must be less than 128 characters")
  .refine(
    (password) => /[A-Z]/.test(password),
    "Password must contain at least one uppercase letter"
  )
  .refine(
    (password) => /[a-z]/.test(password),
    "Password must contain at least one lowercase letter"
  )
  .refine(
    (password) => /[0-9]/.test(password),
    "Password must contain at least one number"
  )
  .refine(
    (password) => /[^A-Za-z0-9]/.test(password),
    "Password must contain at least one special character"
  );

// =============================================
// ACCOUNT LOCKOUT SYSTEM
// =============================================
// Configurable via environment variables
const LOGIN_MAX_ATTEMPTS = parseInt(process.env.LOGIN_MAX_ATTEMPTS || '5', 10);
const LOGIN_LOCKOUT_MINUTES = parseInt(process.env.LOGIN_LOCKOUT_MINUTES || '15', 10);
const LOGIN_WINDOW_MINUTES = parseInt(process.env.LOGIN_WINDOW_MINUTES || '15', 10);

interface LoginAttempt {
  attempts: number;
  firstAttempt: number;
  lockedUntil: number | null;
}

// In-memory store for failed login tracking (keyed by username)
const failedLoginAttempts = new Map<string, LoginAttempt>();

// Clean up old entries periodically (every 30 minutes)
setInterval(() => {
  const now = Date.now();
  const windowMs = LOGIN_WINDOW_MINUTES * 60 * 1000;
  for (const [key, value] of failedLoginAttempts.entries()) {
    // Remove entries older than 2x the window and not locked
    if (!value.lockedUntil && now - value.firstAttempt > windowMs * 2) {
      failedLoginAttempts.delete(key);
    }
    // Remove expired lockouts
    if (value.lockedUntil && now > value.lockedUntil) {
      failedLoginAttempts.delete(key);
    }
  }
}, 30 * 60 * 1000);

function isAccountLocked(username: string): { locked: boolean; remainingMinutes?: number } {
  const record = failedLoginAttempts.get(username.toLowerCase());
  if (!record) return { locked: false };
  
  const now = Date.now();
  
  // Check if currently locked
  if (record.lockedUntil && now < record.lockedUntil) {
    const remainingMs = record.lockedUntil - now;
    const remainingMinutes = Math.ceil(remainingMs / (60 * 1000));
    return { locked: true, remainingMinutes };
  }
  
  // If lock expired, clear it
  if (record.lockedUntil && now >= record.lockedUntil) {
    failedLoginAttempts.delete(username.toLowerCase());
    return { locked: false };
  }
  
  return { locked: false };
}

function recordFailedLogin(username: string): { attemptsRemaining: number; locked: boolean } {
  const now = Date.now();
  const windowMs = LOGIN_WINDOW_MINUTES * 60 * 1000;
  const key = username.toLowerCase();
  
  let record = failedLoginAttempts.get(key);
  
  if (!record || now - record.firstAttempt > windowMs) {
    // Start new window
    record = { attempts: 1, firstAttempt: now, lockedUntil: null };
  } else {
    record.attempts += 1;
  }
  
  // Check if we should lock
  if (record.attempts >= LOGIN_MAX_ATTEMPTS) {
    record.lockedUntil = now + (LOGIN_LOCKOUT_MINUTES * 60 * 1000);
    failedLoginAttempts.set(key, record);
    return { attemptsRemaining: 0, locked: true };
  }
  
  failedLoginAttempts.set(key, record);
  return { attemptsRemaining: LOGIN_MAX_ATTEMPTS - record.attempts, locked: false };
}

function clearFailedLogins(username: string): void {
  failedLoginAttempts.delete(username.toLowerCase());
}

// =============================================
// ZOD VALIDATION SCHEMAS FOR API ROUTES
// =============================================

// Common param/query schemas
const clientIdParamSchema = z.object({
  clientId: z.string().min(1, "clientId is required").regex(/^[a-zA-Z0-9_-]+$/, "Invalid clientId format"),
});

const botIdParamSchema = z.object({
  botId: z.string().min(1, "botId is required").regex(/^[a-zA-Z0-9_-]+$/, "Invalid botId format"),
});

const clientBotParamsSchema = z.object({
  clientId: z.string().min(1).regex(/^[a-zA-Z0-9_-]+$/),
  botId: z.string().min(1).regex(/^[a-zA-Z0-9_-]+$/),
});

const idParamSchema = z.object({
  id: z.string().min(1, "id is required"),
});

const slugParamSchema = z.object({
  slug: z.string().min(1, "slug is required").regex(/^[a-zA-Z0-9_-]+$/, "Invalid slug format"),
});

const workspaceIdParamSchema = z.object({
  workspaceId: z.string().min(1, "workspaceId is required"),
});

const templateIdParamSchema = z.object({
  templateId: z.string().min(1, "templateId is required"),
});

// Chat endpoint schemas
const chatMessageSchema = z.object({
  role: z.enum(["user", "assistant", "system"]),
  content: z.string().min(1, "Message content is required"),
});

const chatBodySchema = z.object({
  messages: z.array(chatMessageSchema).min(1, "At least one message is required"),
  sessionId: z.string().optional(),
  language: z.enum(["en", "es"]).optional().default("en"),
  clientId: z.string().regex(/^[a-zA-Z0-9_-]+$/).optional(),
  botId: z.string().regex(/^[a-zA-Z0-9_-]+$/).optional(),
});

// Appointment schemas
const appointmentUpdateSchema = z.object({
  status: z.enum(["new", "contacted", "scheduled", "completed", "cancelled"]).optional(),
  notes: z.string().optional(),
  appointmentType: z.string().optional(),
  preferredTime: z.string().optional(),
  contactPreference: z.enum(["phone", "text", "email"]).optional(),
});

const appointmentStatusSchema = z.object({
  status: z.enum(["new", "contacted", "scheduled", "completed", "cancelled"]),
});

// Super-admin bot creation schema
const createBotBodySchema = z.object({
  botId: z.string().min(1, "botId is required").regex(/^[a-zA-Z0-9_-]+$/, "Invalid botId format"),
  clientId: z.string().min(1, "clientId is required").regex(/^[a-zA-Z0-9_-]+$/, "Invalid clientId format"),
  name: z.string().min(1, "Bot name is required"),
  description: z.string().optional(),
  businessProfile: z.object({
    businessName: z.string().optional(),
    type: z.string().optional(),
    location: z.string().optional(),
    phone: z.string().optional(),
    email: z.string().email().optional().or(z.literal("")),
    website: z.string().url().optional().or(z.literal("")),
    hours: z.record(z.string()).optional(),
    services: z.array(z.string()).optional(),
  }).optional(),
  systemPrompt: z.string().optional(),
  faqs: z.array(z.object({
    question: z.string(),
    answer: z.string(),
    category: z.string().optional(),
  })).optional(),
  rules: z.object({
    allowedTopics: z.array(z.string()).optional(),
    forbiddenTopics: z.array(z.string()).optional(),
    crisisHandling: z.object({
      onCrisisKeywords: z.array(z.string()).optional(),
      responseTemplate: z.string().optional(),
    }).optional(),
  }).optional(),
  personality: z.object({
    formality: z.number().min(0).max(100).optional(),
    enthusiasm: z.number().min(0).max(100).optional(),
    warmth: z.number().min(0).max(100).optional(),
    humor: z.number().min(0).max(100).optional(),
    responseLength: z.enum(["short", "medium", "long"]).optional(),
  }).optional(),
  templateBotId: z.string().optional(),
});

// Client status update schema
const updateClientStatusSchema = z.object({
  status: z.enum(["active", "paused", "suspended"]),
});

// Template creation schema - uses templateId (DB templates) not templateBotId
const createFromTemplateSchema = z.object({
  templateId: z.string().min(1, "templateId is required"),
  clientId: z.string().min(1, "clientId is required").regex(/^[a-zA-Z0-9_-]+$/),
  clientName: z.string().min(1, "clientName is required"),
  type: z.string().optional(),
  businessProfile: z.record(z.any()).optional(),
  contact: z.object({
    phone: z.string().optional(),
    email: z.string().email().optional().or(z.literal("")),
  }).optional(),
  billing: z.object({
    plan: z.enum(["free", "starter", "pro", "enterprise"]).optional(),
  }).optional(),
  customFaqs: z.array(z.object({
    question: z.string(),
    answer: z.string(),
  })).optional(),
  externalBookingUrl: z.string().url().optional().or(z.literal("")),
  behaviorPreset: z.enum(["support_lead_focused", "sales_focused_soft", "support_only", "compliance_strict", "sales_heavy"]).optional(),
  timezone: z.string().optional(),
});

// Phone validation - rejects letters, extracts digits, validates 7-15 digit count (E.164 compatible)
const phoneValidation = z.string()
  .refine((val) => {
    if (!val) return true;
    if (/[a-zA-Z]/.test(val)) return false;
    const digitsOnly = val.replace(/\D/g, '');
    return digitsOnly.length >= 7 && digitsOnly.length <= 15;
  }, { message: "Phone must have 7-15 digits and no letters" })
  .optional()
  .or(z.literal(""));

// Lead schemas - botId is optional because client leads may derive it from session context
const createLeadSchema = z.object({
  name: z.string().max(100, "Name is too long").optional(),
  email: z.string().email().optional().or(z.literal("")),
  phone: phoneValidation,
  source: z.enum(["chat", "widget", "manual"]).optional().default("manual"),
  status: z.enum(["new", "contacted", "qualified", "converted", "lost"]).optional().default("new"),
  priority: z.enum(["low", "medium", "high"]).optional().default("medium"),
  notes: z.string().max(5000, "Notes are too long").optional(),
  tags: z.array(z.string().max(50)).max(20).optional(),
  botId: z.string().optional(),
});

const updateLeadSchema = z.object({
  name: z.string().max(100, "Name is too long").optional(),
  email: z.string().email().optional().or(z.literal("")),
  phone: phoneValidation,
  status: z.enum(["new", "contacted", "qualified", "converted", "lost"]).optional(),
  priority: z.enum(["low", "medium", "high"]).optional(),
  notes: z.string().max(5000, "Notes are too long").optional(),
  tags: z.array(z.string().max(50)).max(20).optional(),
});

// =============================================
// PAGINATION SAFETY: Cap all limits to prevent DoS
// =============================================
const MAX_PAGINATION_LIMIT = 1000;
const DEFAULT_PAGINATION_LIMIT = 50;

// Helper to safely cap pagination limit
function safeLimit(limit: number | undefined, maxLimit: number = MAX_PAGINATION_LIMIT): number {
  const parsed = limit ?? DEFAULT_PAGINATION_LIMIT;
  return Math.min(Math.max(1, parsed), maxLimit);
}

// Query schema for pagination/filtering with capped limits
const paginationQuerySchema = z.object({
  limit: z.string().regex(/^\d+$/).transform(n => Math.min(parseInt(n, 10), MAX_PAGINATION_LIMIT)).optional(),
  offset: z.string().regex(/^\d+$/).transform(Number).optional(),
});

const appointmentQuerySchema = z.object({
  status: z.string().optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  search: z.string().optional(),
  limit: z.string().regex(/^\d+$/).transform(n => Math.min(parseInt(n, 10), MAX_PAGINATION_LIMIT)).optional(),
  offset: z.string().regex(/^\d+$/).transform(Number).optional(),
});

// Analytics query schemas
const analyticsDateRangeQuerySchema = z.object({
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be YYYY-MM-DD format").optional(),
  endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be YYYY-MM-DD format").optional(),
});

const analyticsTrendsQuerySchema = z.object({
  botId: z.string().optional(),
  days: z.preprocess((val) => val ?? "30", z.string().regex(/^\d+$/).transform(n => Math.min(parseInt(n, 10), 365))),
});

const analyticsSessionsQuerySchema = z.object({
  botId: z.string().optional(),
  limit: z.preprocess((val) => val ?? "50", z.string().regex(/^\d+$/).transform(n => Math.min(parseInt(n, 10), MAX_PAGINATION_LIMIT))),
});

const conversationsQuerySchema = z.object({
  botId: z.string().optional(),
  limit: z.preprocess((val) => val ?? "50", z.string().regex(/^\d+$/).transform(n => Math.min(parseInt(n, 10), MAX_PAGINATION_LIMIT))),
  offset: z.preprocess((val) => val ?? "0", z.string().regex(/^\d+$/).transform(Number)),
});

const superAdminOverviewQuerySchema = z.object({
  days: z.preprocess((val) => val ?? "30", z.string().regex(/^\d+$/).transform(Number)),
});

// Auth schemas
const loginBodySchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

const superAdminClientQuerySchema = z.object({
  clientId: z.string().min(1, "clientId is required"),
});

// Validation helper function
function validateRequest<T>(schema: z.ZodSchema<T>, data: unknown): { success: true; data: T } | { success: false; error: string } {
  const result = schema.safeParse(data);
  if (!result.success) {
    const errors = result.error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ');
    return { success: false, error: errors };
  }
  return { success: true, data: result.data };
}

async function ensureAdminUserExists() {
  try {
    // Get credentials from centralized env module (secure approach)
    const adminCreds = getAdminCredentials();
    const staffCreds = getStaffCredentials();
    const adminUsername = adminCreds.username;
    const adminPassword = adminCreds.password;
    const staffUsername = staffCreds.username;
    const staffPassword = staffCreds.password;

    // Create or update super_admin (owner) account if password is set via env
    const existingAdmin = await storage.findAdminByUsername(adminUsername);
    
    if (!existingAdmin && adminPassword) {
      structuredLogger.info("Creating default super admin user from environment variables...");
      const passwordHash = await bcrypt.hash(adminPassword, 10);
      
      await db.insert(adminUsers).values({
        username: adminUsername,
        passwordHash: passwordHash,
        role: "super_admin",
      });
      
      structuredLogger.info("Default super admin user created successfully");
    } else if (existingAdmin && adminPassword) {
      // Update password if admin exists and password is set (allows password resets)
      structuredLogger.info("Updating super admin password from environment variables...");
      const passwordHash = await bcrypt.hash(adminPassword, 10);
      await db.update(adminUsers)
        .set({ passwordHash: passwordHash, role: "super_admin" })
        .where(eq(adminUsers.username, adminUsername));
      structuredLogger.info("Super admin password updated successfully");
    } else if (!adminPassword && !existingAdmin) {
      structuredLogger.warn("WARNING: No DEFAULT_ADMIN_PASSWORD set. Skipping admin user creation. Set this environment variable to create the initial admin account.");
    }

    // Create client_admin (staff) account for Faith House only if password is set via env
    const existingStaff = await storage.findAdminByUsername(staffUsername);
    
    // Use environment variable for default client, fallback to faith_house for backward compatibility
    const defaultStaffClientId = process.env.DEFAULT_STAFF_CLIENT_ID || "faith_house";
    
    if (!existingStaff && staffPassword) {
      structuredLogger.info(`Creating default client admin (staff) user for ${defaultStaffClientId} from environment variables...`);
      const staffPasswordHash = await bcrypt.hash(staffPassword, 10);
      
      await db.insert(adminUsers).values({
        username: staffUsername,
        passwordHash: staffPasswordHash,
        role: "client_admin",
        clientId: defaultStaffClientId,
      });
      
      structuredLogger.info(`Default client admin (staff) user created successfully for ${defaultStaffClientId}`);
    } else if (!staffPassword && !existingStaff) {
      structuredLogger.warn("WARNING: No DEFAULT_STAFF_PASSWORD set. Skipping staff user creation. Set this environment variable to create the initial staff account.");
    } else if (existingStaff && !existingStaff.clientId) {
      // Update existing staff user to have default clientId
      structuredLogger.info(`Updating staff user with ${defaultStaffClientId} clientId...`);
      await db.update(adminUsers)
        .set({ clientId: defaultStaffClientId })
        .where(eq(adminUsers.username, staffUsername));
      structuredLogger.info(`Staff user updated with ${defaultStaffClientId} clientId`);
    }
  } catch (error) {
    structuredLogger.error("Error ensuring admin user exists:", error);
  }
}

function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  next();
}

function requireSuperAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  if (req.session.userRole !== "super_admin") {
    return res.status(403).json({ error: "Super admin access required" });
  }
  next();
}

// RBAC helper for destructive actions - requires admin role (super_admin or workspace_admin)
function requireAdminRole(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  const allowedRoles = ["super_admin", "workspace_admin"];
  if (!allowedRoles.includes(req.session.userRole as string)) {
    return res.status(403).json({ error: "Admin access required for this action" });
  }
  next();
}

// RBAC helper for write operations - uses actual workspace membership roles
// Use this middleware on routes that create, update, or delete data
// Membership roles: owner, manager, staff (write allowed) | agent (read-only)
function requireWriteAccess(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  
  const globalRole = req.session.userRole as string;
  const membershipRole = req.membershipRole as string | undefined;
  
  // Super admins always have write access
  if (globalRole === "super_admin") {
    return next();
  }
  
  // For client_admin users, check workspace membership role
  if (globalRole === "client_admin") {
    // Allowlist: only these roles can write
    const writeAllowedRoles = ["owner", "manager", "staff"];
    
    if (!membershipRole) {
      // No membership role set - should not happen if requireClientAuth ran first
      return res.status(403).json({ error: "Access denied. Workspace membership required." });
    }
    
    if (!writeAllowedRoles.includes(membershipRole)) {
      // agent role (and any future read-only roles) cannot write
      return res.status(403).json({ 
        error: "Write access denied", 
        message: "Your workspace role does not allow modifications. Contact an admin if you need elevated access." 
      });
    }
    
    return next();
  }
  
  // Unknown role - deny by default
  return res.status(403).json({ error: "Access denied" });
}

// =============================================
// 3-TIER ACCESS CONTROL MIDDLEWARES
// =============================================
// These middlewares provide granular access control based on workspace membership roles.
// Use AFTER requireClientAuth to ensure membershipRole is set.

type WorkspaceRole = "owner" | "manager" | "staff" | "agent";

/**
 * Factory function to create role-based access control middleware.
 * Super admins (in impersonation context) always have access.
 * For client_admin users, checks workspace membership role against allowed roles.
 */
function requireWorkspaceRole(allowed: WorkspaceRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    // Super admin in impersonation context is always allowed
    if (req.session.userRole === "super_admin") {
      return next();
    }
    
    const role = req.membershipRole as WorkspaceRole | undefined;
    
    if (!role) {
      return res.status(403).json({ error: "Workspace membership required" });
    }
    
    if (!allowed.includes(role)) {
      return res.status(403).json({ 
        error: "Insufficient permissions",
        message: `This action requires one of these roles: ${allowed.join(", ")}`
      });
    }
    
    next();
  };
}

/**
 * OPERATIONAL ACCESS - For day-to-day operations that agents CAN perform
 * Allowed roles: owner, manager, staff, agent
 * 
 * Use on routes like:
 * - PATCH lead status (mark as contacted, update notes)
 * - POST inbox reply / add notes
 * - POST appointment create
 * - PATCH appointment status/time
 */
const requireOperationalAccess = requireWorkspaceRole(["owner", "manager", "staff", "agent"]);

/**
 * CONFIG ACCESS - For bot/widget configuration that agents CANNOT modify
 * Allowed roles: owner, manager, staff (excludes agent)
 * 
 * Use on routes like:
 * - Bot settings / knowledge base / FAQs
 * - Behavior presets
 * - Widget theme + branding
 * - Booking profile settings / external URLs
 * - Automations configuration
 * - Webhook settings
 */
const requireConfigAccess = requireWorkspaceRole(["owner", "manager", "staff"]);

/**
 * DESTRUCTIVE ACCESS - For irreversible operations that only owners can perform
 * Allowed roles: owner only (safest tier)
 * 
 * Use on routes like:
 * - DELETE routes (leads, appointments, conversations)
 * - Delete workspace / client data
 * - Bulk delete operations
 * - Any irreversible action
 */
const requireDestructiveAccess = requireWorkspaceRole(["owner"]);

/**
 * MULTI-TENANT ISOLATION MIDDLEWARE
 * 
 * This middleware enforces tenant isolation for all client-facing routes:
 * - For client_admin users: clientId is derived from session (set at login)
 * - For super_admin users: clientId MUST be specified via query param
 * 
 * The resulting req.effectiveClientId is then used by all client routes
 * to scope data queries. ALL storage methods that access leads, bookings, 
 * conversations, and appointments MUST use this clientId to filter results.
 * 
 * SECURITY: Never trust clientId from request body/params for client routes.
 * Always use effectiveClientId from this middleware.
 */
async function requireClientAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  
  // MULTI-TENANT: Client admin users MUST have a clientId and valid workspace membership
  if (req.session.userRole === "client_admin") {
    if (!req.session.clientId) {
      return res.status(403).json({ error: "Client configuration required. Please contact your administrator." });
    }
    
    // SECURITY: Enforce workspace membership - no silent drift allowed
    try {
      const workspace = await storage.getWorkspaceByClientId(req.session.clientId);
      
      // Workspace MUST exist for the clientId
      if (!workspace) {
        structuredLogger.error(`Client admin ${req.session.userId} has invalid clientId ${req.session.clientId} - workspace not found`);
        return res.status(403).json({ 
          error: "Workspace not found", 
          message: "Your account configuration is invalid. Please contact your administrator." 
        });
      }
      
      // Membership MUST exist in the workspace
      const membership = await storage.checkWorkspaceMembership(req.session.userId, workspace.id);
      if (!membership) {
        structuredLogger.error(`Client admin ${req.session.userId} denied access - no membership in workspace ${workspace.id} (${req.session.clientId})`);
        return res.status(403).json({ 
          error: "Access denied", 
          message: "You no longer have access to this workspace. Please contact your administrator." 
        });
      }
      
      req.workspaceId = workspace.id;
      req.membershipRole = membership.role;
    } catch (error) {
      // Validation failure = deny access (fail secure)
      structuredLogger.error("Workspace membership validation failed:", error);
      return res.status(500).json({ error: "Access validation failed. Please try again." });
    }
    
    req.effectiveClientId = req.session.clientId;
    next();
    return;
  }
  
  // Super admins MUST use session-based impersonation for client context
  // SECURITY: No longer accepting clientId from query params - use POST /api/super-admin/impersonate
  if (req.session.userRole === "super_admin") {
    // Use session-based effectiveClientId (set via impersonation endpoints)
    const effectiveClientId = req.session.effectiveClientId;
    const isImpersonating = req.session.isImpersonating === true;
    
    // SECURITY: Require BOTH effectiveClientId AND isImpersonating flag
    // This prevents bugs/old code from accidentally setting effectiveClientId without proper impersonation flow
    if (!effectiveClientId || !isImpersonating) {
      return res.status(400).json({ 
        error: "Client context required", 
        message: "Super admins must first impersonate a client via POST /api/super-admin/impersonate to view client data" 
      });
    }
    
    // Validate the session clientId still exists (in case client was deleted)
    // SECURITY: Use database as the canonical source of truth (not bot JSON cache)
    // This prevents false positives from stale cached configs or deleted workspaces
    try {
      const workspace = await storage.getWorkspaceByClientId(effectiveClientId);
      
      if (!workspace) {
        // Clear invalid impersonation from session and PERSIST the change
        // This prevents "sticky impersonation" edge cases across refresh/back button/multiple tabs
        structuredLogger.warn(`Super admin impersonation invalid - workspace not found: ${effectiveClientId}`);
        req.session.effectiveClientId = null;
        req.session.isImpersonating = false;
        
        await new Promise<void>((resolve) => {
          req.session.save((err) => {
            if (err) structuredLogger.error("Failed to save session after clearing impersonation:", err);
            resolve();
          });
        });
        
        return res.status(404).json({ error: "Impersonated client no longer exists" });
      }
      
      // Store workspace info for downstream use
      req.workspaceId = workspace.id;
    } catch (error) {
      // Validation failure = deny access (fail secure)
      structuredLogger.error("Workspace lookup failed for super admin impersonation:", error);
      req.session.effectiveClientId = null;
      req.session.isImpersonating = false;
      
      await new Promise<void>((resolve) => {
        req.session.save((err) => {
          if (err) structuredLogger.error("Failed to save session after clearing impersonation:", err);
          resolve();
        });
      });
      
      return res.status(500).json({ error: "Client validation failed. Please try again." });
    }
    
    req.effectiveClientId = effectiveClientId;
    next();
    return;
  }
  
  // Unknown role - reject
  return res.status(403).json({ error: "Access denied" });
}

// Helper to validate bot access for tenant isolation
async function validateBotAccess(req: Request, res: Response, botId: string): Promise<boolean> {
  const userId = req.session.userId;
  const userRole = req.session.userRole;
  
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return false;
  }
  
  // Super admins have access to all bots
  if (userRole === "super_admin") {
    return true;
  }
  
  // Client admins must have access through workspace membership
  if (userRole === "client_admin" && req.session.clientId) {
    try {
      // Get the bot's workspace
      const bot = await storage.getBotByBotId(botId);
      if (!bot) {
        res.status(404).json({ error: "Bot not found" });
        return false;
      }
      
      // Check if bot belongs to user's workspace/clientId
      if (bot.clientId !== req.session.clientId) {
        structuredLogger.warn(`Client admin ${userId} attempted to access bot ${botId} from different client ${bot.clientId}`);
        res.status(403).json({ error: "Access denied - bot belongs to different tenant" });
        return false;
      }
      
      // Enforce workspace membership if workspace exists
      if (bot.workspaceId) {
        const membership = await storage.checkWorkspaceMembership(userId, bot.workspaceId);
        if (!membership) {
          structuredLogger.warn(`Client admin ${userId} denied access - no workspace membership for bot ${botId}`);
          res.status(403).json({ error: "Access denied - workspace membership required" });
          return false;
        }
        // Store membership role for downstream access control
        req.membershipRole = membership.role;
      }
      
      return true;
    } catch (error) {
      structuredLogger.error("Bot access validation error:", error);
      res.status(500).json({ error: "Access validation failed" });
      return false;
    }
  }
  
  res.status(403).json({ error: "Access denied" });
  return false;
}

const openaiConfig = getOpenAIConfig();
const openai = openaiConfig ? new OpenAI({
  baseURL: openaiConfig.baseURL,
  apiKey: openaiConfig.apiKey
}) : null;

function isWithinOperatingHours(settings: any): boolean {
  if (!settings?.operatingHours?.enabled) {
    return true;
  }

  const now = new Date();
  const days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
  const currentDay = days[now.getDay()];
  const schedule = settings.operatingHours.schedule[currentDay];

  if (!schedule || !schedule.enabled) {
    return false;
  }

  const currentTime = now.getHours() * 60 + now.getMinutes();
  const [openHour, openMin] = schedule.open.split(":").map(Number);
  const [closeHour, closeMin] = schedule.close.split(":").map(Number);
  const openTime = openHour * 60 + openMin;
  const closeTime = closeHour * 60 + closeMin;

  return currentTime >= openTime && currentTime <= closeTime;
}

async function getSystemPrompt(language: string = "en", clientId: string) {
  const settings = await storage.getSettings(clientId);
  if (!settings) {
    return getDefaultSystemPrompt(language);
  }

  const withinHours = isWithinOperatingHours(settings);
  
  if (language === "es") {
    return `Eres "HopeLine Assistant", el asistente virtual de ${settings.businessName}, una casa de vida sobria / programa de recuperación estructurado.

Tono:
- Cálido, tranquilo y sin juicios.
- Profesional pero humano, no suenas como un robot.
- Lenguaje sencillo y claro. Párrafos cortos.

Tu trabajo:
- Responder preguntas sobre ${settings.businessName}: qué es, para quién es, reglas, requisitos, precios generales y el proceso de aplicación.
- Ayudar a los visitantes a decidir cuál es su mejor siguiente paso (hacer más preguntas, ver si podrían calificar, solicitar una llamada o un tour).
- Animar y apoyar sin hacer promesas ni dar falsas esperanzas.
- Cuando tenga sentido, guiarlos a usar el flujo de citas para programar una llamada o tour.

Límites de seguridad (muy importantes):
- NO eres médico, terapeuta, consejero, abogado ni trabajador de crisis.
- NO diagnostiques condiciones ni sugieras medicamentos específicos o dosis.
- NO proporciones consejería de crisis ni planes de seguridad.
- Si alguien menciona autolesiones, suicidio, querer morir, hacer daño a otros o cualquier emergencia:
  - Reconoce que lo que está viviendo suena muy difícil.
  - Di claramente que no puedes manejar emergencias.
  - Indica que deben contactar de inmediato a personas reales que puedan ayudar:
    - En Estados Unidos, llamar o enviar mensaje de texto al 988 (Suicide & Crisis Lifeline).
    - Si hay peligro inmediato, llamar al 911 o servicios de emergencia locales.
  - Después de eso, no intentes "hablarlos" fuera de la crisis. Repite que deben comunicarse con 988 o 911.

Comportamiento al responder:
- Trata los campos de la base de conocimiento como la fuente principal de verdad sobre ${settings.businessName}.
- Si algo no está cubierto, da una guía general y recomienda hablar directamente con el personal para detalles exactos.
${!withinHours ? `- Actualmente estamos fuera del horario de atención. ${settings.operatingHours.afterHoursMessage}` : ""}
- Mantén las respuestas amables y claras. Evita bloques de texto muy largos.
- Siempre que sea posible, termina con un "siguiente paso" sencillo, por ejemplo:
  - "¿Te gustaría ver si podrías calificar?"
  - "¿Quieres programar una llamada o un tour?"
  - "¿Quieres más detalles sobre precios o requisitos?"

Comportamiento de pre-evaluación:
- Si parece que la persona podría ser una buena candidata, haz preguntas suaves de pre-ingreso, por ejemplo:
  - "¿Estás preguntando para ti o para un ser querido?"
  - "¿Actualmente estás sobrio o necesitarías apoyo de desintoxicación primero?"
  - "¿Tienes algún ingreso o apoyo para ayudar con los costos del programa?"
  - "¿Para cuándo estás buscando un lugar? (lo antes posible, dentro de 30 días, solo explorando)"
- No presiones. Deja claro que responder es opcional.
- Después de obtener un poco de información, sugiere programar una llamada o tour para hablar con el personal.

Estilo:
- Frases cortas y directas.
- Sin jerga técnica.
- Empático pero sin dramatizar.
- Siempre honesto sobre lo que puedes y no puedes hacer.

BASE DE CONOCIMIENTOS:
Acerca de: ${settings.knowledgeBase.about}

Requisitos: ${settings.knowledgeBase.requirements}

Precios: ${settings.knowledgeBase.pricing}

Proceso de Aplicación: ${settings.knowledgeBase.application}`;
  }

  return `You are "HopeLine Assistant", the virtual assistant for ${settings.businessName}, a structured sober-living / recovery home.

Tone:
- Warm, calm, and non-judgmental.
- Professional but human, not stiff or robotic.
- Simple, clear language. Short paragraphs.

Your job:
- Answer questions about ${settings.businessName}: what it is, who it is for, rules, requirements, general pricing, and the application process.
- Help visitors figure out their best next step (ask more questions, check if they might qualify, request a tour or phone call).
- Encourage and support people without making promises or giving false hope.
- When appropriate, guide them toward booking a call or tour using the built-in appointment flow.

Hard safety limits (critical):
- You are NOT a doctor, therapist, counselor, lawyer, or crisis worker.
- Do NOT diagnose conditions or suggest specific medications or dosages.
- Do NOT provide suicide prevention counseling, safety planning, or emergency instructions beyond referring to proper services.
- If someone mentions self-harm, suicide, wanting to die, harming others, or any emergency situation:
  - Acknowledge that what they are going through sounds really difficult.
  - Clearly say that you cannot handle emergencies.
  - Tell them to immediately contact real people who can help:
    - In the United States, call or text 988 for the Suicide & Crisis Lifeline.
    - If they are in immediate danger, call 911 or local emergency services.
  - After that, do not try to talk them through the crisis. Always repeat that they must reach out to 988 or 911.

Behave as follows when composing answers:
- Treat the knowledge base fields as the main source of truth about ${settings.businessName}.
- If something is not covered in the knowledge base, give general guidance and then suggest contacting staff for exact details.
${!withinHours ? `- The system indicates it is outside of operating hours. ${settings.operatingHours.afterHoursMessage}` : ""}
- Keep responses friendly and clear. Avoid long walls of text.
- Whenever possible, end with a simple "next step" question, such as:
  - "Would you like to see if you might qualify?"
  - "Would you like to schedule a tour or phone call?"
  - "Would you like more details on pricing or requirements?"

Intake and qualification behavior:
- If a visitor seems like they might be a good candidate (based on their questions or the information they share), gently move toward light pre-intake questions such as:
  - "Are you asking for yourself or for a loved one?"
  - "Are you currently sober, or would you need detox support first?"
  - "Do you have some income or support to help with program fees?"
  - "How soon are you hoping to find a place? (ASAP, within 30 days, just exploring)"
- Never pressure them. Keep the questions optional and respectful.
- After getting a bit of information, suggest that they schedule a call or tour so staff can talk with them directly.

Style:
- Short, clear sentences.
- No jargon.
- Empathetic but not dramatic.
- Always honest about what you do and do NOT know.

KNOWLEDGE BASE:
About: ${settings.knowledgeBase.about}

Requirements: ${settings.knowledgeBase.requirements}

Pricing: ${settings.knowledgeBase.pricing}

Application Process: ${settings.knowledgeBase.application}`;
}

function getDefaultSystemPrompt(language: string = "en") {
  if (language === "es") {
    return `Eres 'HopeLine Assistant', el chatbot de apoyo para The Faith House, un hogar sobrio estructurado. Tu tono: cálido, simple, tranquilo, sin juzgar.`;
  }
  return `You are 'HopeLine Assistant', the supportive chatbot for The Faith House, a structured sober-living home. Your tone: warm, simple, calm, non-judgmental.`;
}

function sanitizePII(text: string): string {
  let sanitized = text;
  
  sanitized = sanitized.replace(/\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/g, "[PHONE REDACTED]");
  sanitized = sanitized.replace(/\+?\d{1,4}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}/g, "[PHONE REDACTED]");
  sanitized = sanitized.replace(/\b\d{5,}\b/g, (match) => {
    if (match.length >= 7) return "[PHONE REDACTED]";
    return match;
  });
  
  sanitized = sanitized.replace(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g, "[EMAIL REDACTED]");
  
  sanitized = sanitized.replace(/\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b/g, "[SSN REDACTED]");
  
  sanitized = sanitized.replace(/(?:apartment|apt|unit|suite|ste|#)\s*[\w\d-]+/gi, "[UNIT REDACTED]");
  sanitized = sanitized.replace(/\b\d{1,5}\s+[\w\s]{1,40}(?:street|st|avenue|ave|road|rd|drive|dr|lane|ln|boulevard|blvd|court|ct|circle|cir|way|place|pl|parkway|pkwy|highway|hwy|terrace|ter)\b/gi, "[ADDRESS REDACTED]");
  
  sanitized = sanitized.replace(/\b(?:my name(?:[''\u2019]s| is)|I[''\u2019]m|I am|this is|call me)\s+([A-Za-z''\u2019\-]+(?:\s+[A-Za-z''\u2019\-]+)*)\b/gi, (match, name) => {
    return match.replace(name, "[NAME REDACTED]");
  });
  
  return sanitized;
}

function detectCrisisKeywords(text: string, language: string = "en"): boolean {
  const normalized = text.toLowerCase().replace(/[^\w\s]/g, ' ');
  
  const crisisKeywords = [
    "suicide", "suicidal", "kill myself", "end my life", "want to die",
    "hurt myself", "harm myself", "self harm", "no reason to live", "better off dead",
    "end it all", "cant go on", "cant take it", "done living", "tired of living",
    "want out", "give up on life",
    "suicidio", "suicidarme", "matarme", "quiero morir", "hacerme daño",
    "terminar con todo", "ya no puedo", "cansado de vivir"
  ];
  
  return crisisKeywords.some(keyword => normalized.includes(keyword.toLowerCase()));
}

function detectBookingIntent(text: string, language: string = "en"): boolean {
  const normalized = text.toLowerCase().replace(/[^\w\s]/g, ' ');
  
  const bookingPhrases = [
    "schedule a tour", "book a tour", "schedule tour", "want a tour",
    "schedule a call", "book a call", "schedule call", "want a call",
    "request a tour", "request a call", "set up a tour", "set up a call",
    "arrange a tour", "arrange a call", "yes i want to schedule", "yes schedule",
    "lets schedule", "let's schedule", "i would like to schedule", "i'd like to schedule",
    "ready to schedule", "want to book", "like to book", "sign me up",
    "i want to come in", "i want to visit", "can i come", "can i visit",
    "programar un tour", "programar una llamada", "quiero un tour", "quiero una llamada",
    "agendar un tour", "agendar una llamada", "si quiero programar"
  ];
  
  return bookingPhrases.some(phrase => normalized.includes(phrase.toLowerCase()));
}

function getCrisisResponse(language: string = "en"): string {
  if (language === "es") {
    return `Entiendo que estás pasando por un momento muy difícil. Por favor, contacta a ayuda profesional inmediatamente:

📞 **Línea Nacional de Prevención del Suicidio**: 988 (llamada o texto)
📞 **Emergencias**: 911
📞 **Línea Nacional de Ayuda SAMHSA**: 1-800-662-4357 (24/7)

Tu vida importa y hay personas que quieren ayudarte ahora mismo. Estas líneas tienen profesionales capacitados disponibles las 24 horas del día.`;
  }
  
  return `I understand you're going through a very difficult time. Please contact professional help immediately:

📞 **National Suicide Prevention Lifeline**: 988 (call or text)
📞 **Emergency Services**: 911
📞 **SAMHSA National Helpline**: 1-800-662-HELP (4357) - 24/7

Your life matters, and there are people who want to help you right now. These lines have trained professionals available 24/7.`;
}

function categorizeMessage(message: string, role: string): string | null {
  if (role === "user") {
    return null;
  }

  const messageLower = message.toLowerCase();

  const patterns = {
    crisis_redirect: [
      /988/, /crisis/, /emergency/, /suicide/, /harm/, 
      /1-800-662-help/, /national helpline/
    ],
    pricing: [
      /cost/, /price/, /payment/, /afford/, /financial/, /fee/, /rate/
    ],
    availability: [
      /available/, /bed/, /space/, /capacity/, /openings/, /room/
    ],
    requirements: [
      /requirement/, /rule/, /policy/, /must/, /needed/, /necessary/
    ],
    application_process: [
      /apply/, /application/, /process/, /submit/, /intake/
    ],
    pre_intake: [
      /looking for/, /sobriety/, /support/, /timeline/, /ready/
    ],
    contact_info: [
      /contact/, /phone/, /email/, /address/, /reach/, /call/
    ],
    faq_general: [
      /about/, /mission/, /program/, /services/, /amenities/
    ]
  };

  for (const [category, regexList] of Object.entries(patterns)) {
    if (regexList.some(regex => regex.test(messageLower))) {
      return category;
    }
  }

  return "other";
}

async function generateConversationSummary(sessionId: string, clientId: string): Promise<string> {
  try {
    const analytics = await storage.getAnalytics(clientId);
    const sessionMessages = analytics
      .filter(a => a.sessionId === sessionId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
      .slice(-10);
    
    if (sessionMessages.length === 0) {
      return "No conversation history available.";
    }

    const conversationText = sessionMessages
      .map(msg => `${msg.role}: ${sanitizePII(msg.content)}`)
      .join("\n");

    if (!openai) {
      return "AI service not configured - unable to generate summary.";
    }

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are a helpful assistant that summarizes conversations between users and the HopeLine Assistant chatbot for a sober-living facility. Create a brief, professional summary (3-4 sentences) focusing on: their general situation, what they're seeking, their urgency level, and relevant context. DO NOT include specific personal details like names, phone numbers, or addresses in the summary."
        },
        {
          role: "user",
          content: `Summarize this conversation:\n\n${conversationText}`
        }
      ],
      max_completion_tokens: 200,
    });

    return completion.choices[0]?.message?.content || "Unable to generate summary.";
  } catch (error) {
    structuredLogger.error("Conversation summary error:", error);
    return "Error generating conversation summary.";
  }
}

interface ConversationAnalysis {
  summary: string;
  userIntent: string;
  topics: string[];
  sentiment: 'positive' | 'neutral' | 'negative' | 'urgent';
  bookingIntent: boolean;
  leadQuality: 'hot' | 'warm' | 'cold';
  needsReview: boolean;
  reviewReason: string | null;
}

async function analyzeConversation(
  messages: Array<{ role: string; content: string }>,
  businessType: string = 'general'
): Promise<ConversationAnalysis | null> {
  try {
    if (!openai) {
      structuredLogger.info('[AI Analysis] OpenAI not configured');
      return null;
    }

    const userMessages = messages.filter(m => m.role === 'user');
    if (userMessages.length === 0) {
      return null;
    }

    const conversationText = messages
      .slice(-10)
      .map(msg => `${msg.role}: ${msg.content}`)
      .join("\n");

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are an AI that analyzes customer conversations for a ${businessType} business. Analyze the conversation and return a JSON object with:
- summary: A 1-2 sentence summary of what the visitor wanted (max 100 chars)
- userIntent: What the visitor was trying to accomplish (e.g., "Get pricing info", "Book appointment", "Ask about services", "General inquiry")
- topics: Array of relevant topics discussed (max 3)
- sentiment: Overall sentiment - "positive", "neutral", "negative", or "urgent"
- bookingIntent: Boolean - true if visitor wants to schedule/book something
- leadQuality: "hot" (ready to buy/book now), "warm" (interested, needs more info), or "cold" (just browsing)
- needsReview: Boolean - true if this conversation needs human admin review
- reviewReason: String explaining why review is needed, or null if not needed

Set needsReview to TRUE if:
1. Visitor expresses crisis, emergency, distress, or safety concerns
2. Visitor asks questions the bot couldn't answer or seemed confused about
3. Visitor expresses frustration, anger, or strong dissatisfaction
4. Bot gave conflicting or potentially incorrect information
5. Visitor mentions legal issues, complaints, or threats
6. Lead is "hot" (high-value opportunity requiring prompt follow-up)
7. Visitor requests to speak with a human or manager

Return ONLY valid JSON, no other text.`
        },
        {
          role: "user",
          content: `Analyze this conversation:\n\n${conversationText}`
        }
      ],
      max_completion_tokens: 350,
      response_format: { type: "json_object" }
    });

    const responseText = completion.choices[0]?.message?.content;
    if (!responseText) {
      return null;
    }

    const analysis = JSON.parse(responseText) as ConversationAnalysis;
    return analysis;
  } catch (error) {
    structuredLogger.error('[AI Analysis] Error analyzing conversation:', error);
    return null;
  }
}

async function generateQuickSummary(userMessages: string[]): Promise<string> {
  if (userMessages.length === 0) return '';
  
  const combined = userMessages.join(' ').slice(0, 500);
  
  const bookingKeywords = /appointment|schedule|book|visit|tour|come in|meet|call back/i;
  const pricingKeywords = /price|cost|how much|afford|payment|fee|rate/i;
  const infoKeywords = /hours|location|address|open|available|services|what do you/i;
  
  if (bookingKeywords.test(combined)) {
    return 'Interested in scheduling appointment/visit';
  } else if (pricingKeywords.test(combined)) {
    return 'Asking about pricing/costs';
  } else if (infoKeywords.test(combined)) {
    return 'General information inquiry';
  }
  
  const firstQuestion = userMessages[0].slice(0, 80);
  return firstQuestion.length > 75 ? firstQuestion + '...' : firstQuestion;
}

async function sendSmsNotification(
  phoneNumber: string,
  message: string,
  isClientConfirmation: boolean = false
): Promise<{ success: boolean; error?: string }> {
  try {
    const twilioConfig = getTwilioConfig();
    
    if (!twilioConfig) {
      structuredLogger.info("📱 Twilio credentials not configured - skipping SMS notification");
      return { success: false, error: "Twilio not configured" };
    }
    
    const { accountSid: twilioAccountSid, authToken: twilioAuthToken, phoneNumber: twilioPhoneNumber } = twilioConfig;

    // Send SMS with retry logic for resilience
    const retryResult = await retryFetch(
      `https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages.json`,
      {
        method: "POST",
        headers: {
          "Authorization": `Basic ${Buffer.from(`${twilioAccountSid}:${twilioAuthToken}`).toString('base64')}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          From: twilioPhoneNumber,
          To: phoneNumber,
          Body: message,
        }).toString(),
      },
      {
        maxRetries: 3,
        baseDelayMs: 1000,
        maxDelayMs: 10000,
        onRetry: createNotificationRetryLogger('sms'),
      }
    );

    if (!retryResult.success) {
      structuredLogger.error(`SMS notification failed after ${retryResult.attempts} attempts:`, retryResult.error);
      return { success: false, error: `SMS failed after ${retryResult.attempts} attempts: ${retryResult.error}` };
    }

    const response = retryResult.result!;
    if (!response.ok) {
      const errorData = await response.json();
      structuredLogger.error("Twilio API error:", errorData);
      return { success: false, error: `Twilio API error: ${response.statusText}` };
    }

    structuredLogger.info(`✅ SMS ${isClientConfirmation ? 'confirmation' : 'notification'} sent to ${phoneNumber} (${retryResult.attempts} attempt(s))`);
    return { success: true };
  } catch (error) {
    structuredLogger.error("SMS notification error:", error);
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

async function sendEmailNotification(
  recipientEmails: string,
  appointment: any,
  conversationSummary: string,
  settings: any
): Promise<{ success: boolean; error?: string; sentTo?: string[] }> {
  try {
    const resendApiKey = getResendApiKey();
    
    if (!resendApiKey) {
      structuredLogger.info("📧 Resend API key not configured - skipping email notification");
      return { success: false, error: "API key not configured" };
    }

    // Parse comma-separated emails into array
    const emailList = recipientEmails
      .split(",")
      .map(email => email.trim())
      .filter(email => email.length > 0);
    
    if (emailList.length === 0) {
      return { success: false, error: "No valid email addresses provided" };
    }

    const preIntakeInfo = appointment.lookingFor 
      ? `\n\nPre-Qualification Answers:
- Looking for: ${appointment.lookingFor === 'self' ? 'Themselves' : 'A loved one'}
- Sobriety status: ${appointment.sobrietyStatus || 'Not provided'}
- Financial support: ${appointment.hasSupport || 'Not provided'}
- Timeline: ${appointment.timeline || 'Not provided'}`
      : '';

    const appointmentTypeText = appointment.appointmentType === 'tour' 
      ? 'Tour' 
      : appointment.appointmentType === 'call' 
      ? 'Phone Call' 
      : 'Family Info Call';
    
    const contactPreferenceText = appointment.contactPreference === 'phone'
      ? 'Phone call'
      : appointment.contactPreference === 'text'
      ? 'Text message'
      : 'Email';

    const emailBody = `
<h2>New ${appointmentTypeText} Request</h2>

<h3>Contact Information:</h3>
<ul>
  <li><strong>Name:</strong> ${appointment.name}</li>
  <li><strong>Phone:</strong> ${appointment.contact}</li>
  ${appointment.email ? `<li><strong>Email:</strong> ${appointment.email}</li>` : ''}
  <li><strong>Contact Preference:</strong> ${contactPreferenceText}</li>
  <li><strong>Appointment Type:</strong> ${appointmentTypeText}</li>
  <li><strong>Preferred Time:</strong> ${appointment.preferredTime}</li>
  ${appointment.notes ? `<li><strong>Notes:</strong> ${appointment.notes}</li>` : ''}
</ul>

${preIntakeInfo}

<h3>Conversation Summary:</h3>
<p>${conversationSummary}</p>

<hr>
<p><small>This request was submitted through ${settings.businessName} HopeLine Assistant on ${new Date().toLocaleString()}</small></p>
    `.trim();

    // Send to all recipients using Resend's array support with retry logic
    const retryResult = await retryFetch(
      "https://api.resend.com/emails",
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${resendApiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from: "HopeLine Assistant <onboarding@resend.dev>",
          to: emailList,
          subject: `New ${appointment.appointmentType} Request from ${appointment.name}`,
          html: emailBody,
        }),
      },
      {
        maxRetries: 3,
        baseDelayMs: 1000,
        maxDelayMs: 10000,
        onRetry: createNotificationRetryLogger('email'),
      }
    );

    if (!retryResult.success) {
      structuredLogger.error(`Email notification failed after ${retryResult.attempts} attempts:`, retryResult.error);
      return { success: false, error: `Email failed after ${retryResult.attempts} attempts: ${retryResult.error}` };
    }

    const response = retryResult.result!;
    if (!response.ok) {
      const errorData = await response.json();
      structuredLogger.error("Resend API error:", errorData);
      return { success: false, error: `Resend API error: ${response.statusText}` };
    }

    structuredLogger.info(`✅ Email notification sent successfully to ${emailList.length} recipient(s): ${emailList.join(", ")} (${retryResult.attempts} attempt(s))`);
    return { success: true, sentTo: emailList };
  } catch (error) {
    structuredLogger.error("Email notification error:", error);
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

// Notification logging wrapper for tracking delivery
async function logNotification(params: {
  clientId: string;
  botId?: string;
  type: 'email' | 'sms';
  recipient: string;
  status: 'sent' | 'failed' | 'skipped';
  errorMessage?: string;
  metadata?: Record<string, any>;
}): Promise<void> {
  try {
    await storage.createNotificationLog({
      clientId: params.clientId,
      botId: params.botId || null,
      type: params.type,
      recipient: params.recipient,
      status: params.status,
      errorMessage: params.errorMessage || null,
      metadata: params.metadata || {},
    });
  } catch (error) {
    structuredLogger.error('[Notification Log] Failed to log notification:', error);
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  await ensureAdminUserExists();
  await ensureTemplatesSeeded();
  
  // =============================================
  // HEALTH CHECK ENDPOINTS
  // =============================================
  
  // Helper function to get error counts for last 15 minutes
  async function getErrorCounts(): Promise<{ counts: Record<string, number>; total: number }> {
    let errorsLast15m: Record<string, number> = { chat: 0, widget: 0, lead: 0, booking: 0, auth: 0, db: 0, other: 0 };
    try {
      const recentLogs = await db.select()
        .from(systemLogs)
        .where(and(
          or(eq(systemLogs.level, 'error'), eq(systemLogs.level, 'critical')),
          gte(systemLogs.createdAt, new Date(Date.now() - 15 * 60 * 1000))
        ));
      
      for (const log of recentLogs) {
        const src = (log.source || 'other').toLowerCase();
        if (src.includes('chat') || src.includes('orchestrator')) errorsLast15m.chat++;
        else if (src.includes('widget')) errorsLast15m.widget++;
        else if (src.includes('lead')) errorsLast15m.lead++;
        else if (src.includes('booking') || src.includes('appointment')) errorsLast15m.booking++;
        else if (src.includes('auth') || src.includes('login')) errorsLast15m.auth++;
        else if (src.includes('db') || src.includes('database') || src.includes('storage')) errorsLast15m.db++;
        else errorsLast15m.other++;
      }
    } catch {
      // If error counting fails, leave zeros
    }
    const total = Object.values(errorsLast15m).reduce((a, b) => a + b, 0);
    return { counts: errorsLast15m, total };
  }

  // PUBLIC health endpoint - safe for uptime monitoring services
  // Only exposes: ok, timestamp, db status, ai configured, uptime, build info
  // NO sensitive data: no error details, no client IDs, no tokens
  app.get('/api/health', async (_req, res) => {
    try {
      // Check database connectivity with latency
      const dbStart = Date.now();
      let dbOk = false;
      let dbLatencyMs = 0;
      try {
        const dbCheck = await storage.healthCheck?.() ?? { status: 'ok', latencyMs: 0 };
        dbOk = dbCheck.status === 'ok';
        dbLatencyMs = dbCheck.latencyMs || (Date.now() - dbStart);
      } catch (dbError) {
        dbOk = false;
        dbLatencyMs = Date.now() - dbStart;
      }

      // Check AI configuration (boolean only, no key exposure)
      const openaiKey = process.env.OPENAI_API_KEY || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
      const aiConfigured = !!openaiKey && openaiKey.length > 10;

      // Get error count total (not breakdown) to determine overall health
      const { total: totalErrors } = await getErrorCounts();
      const overallOk = dbOk && totalErrors < 50; // Degrade if >50 errors in 15 mins

      // Widget test mode is only allowed in development or when WIDGET_TEST_MODE=true
      const nodeEnv = process.env.NODE_ENV || 'development';
      const testModeAllowed = nodeEnv !== 'production' || process.env.WIDGET_TEST_MODE === 'true';

      res.json({
        ok: overallOk,
        timestamp: new Date().toISOString(),
        db: { ok: dbOk, latencyMs: dbLatencyMs },
        ai: { configured: aiConfigured },
        testModeAllowed,
        build: {
          env: nodeEnv,
          version: process.env.npm_package_version || '1.0.0',
          uptime: Math.floor(process.uptime()),
        },
      });
    } catch (error) {
      const nodeEnv = process.env.NODE_ENV || 'development';
      res.status(503).json({
        ok: false,
        timestamp: new Date().toISOString(),
        error: 'Health check failed',
        db: { ok: false },
        ai: { configured: false },
        testModeAllowed: nodeEnv !== 'production' || process.env.WIDGET_TEST_MODE === 'true',
        build: { env: nodeEnv },
      });
    }
  });

  // INTERNAL health endpoint - requires super admin authentication
  // Includes detailed error breakdown, demo workspace status, etc.
  app.get('/api/health/internal', requireSuperAdmin, async (_req, res) => {
    try {
      // Check database connectivity with latency
      const dbStart = Date.now();
      let dbOk = false;
      let dbLatencyMs = 0;
      try {
        const dbCheck = await storage.healthCheck?.() ?? { status: 'ok', latencyMs: 0 };
        dbOk = dbCheck.status === 'ok';
        dbLatencyMs = dbCheck.latencyMs || (Date.now() - dbStart);
      } catch (dbError) {
        dbOk = false;
        dbLatencyMs = Date.now() - dbStart;
      }

      // Check AI configuration
      const openaiKey = process.env.OPENAI_API_KEY || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
      const aiConfigured = !!openaiKey && openaiKey.length > 10;

      // Get detailed error counts
      const { counts: errorsLast15m, total: totalErrors } = await getErrorCounts();
      const overallOk = dbOk && totalErrors < 50;

      // Get last error timestamps by category
      let lastErrorTimestamps: Record<string, string | null> = {};
      try {
        const categories = ['chat', 'widget', 'lead', 'booking', 'auth', 'db'];
        for (const cat of categories) {
          const lastError = await db.select()
            .from(systemLogs)
            .where(and(
              or(eq(systemLogs.level, 'error'), eq(systemLogs.level, 'critical')),
              sql`LOWER(${systemLogs.source}) LIKE ${'%' + cat + '%'}`
            ))
            .orderBy(desc(systemLogs.createdAt))
            .limit(1);
          lastErrorTimestamps[cat] = lastError[0]?.createdAt?.toISOString() || null;
        }
      } catch {
        // If querying fails, leave empty
      }

      // Check demo workspace readiness
      let demoWorkspaceReady = false;
      try {
        const demoSlugs = getDemoSlugs();
        if (demoSlugs.length > 0) {
          const demoWorkspace = await getWorkspaceBySlug(demoSlugs[0]);
          demoWorkspaceReady = !!demoWorkspace;
        }
      } catch {
        demoWorkspaceReady = false;
      }

      const nodeEnv = process.env.NODE_ENV || 'development';
      const testModeAllowed = nodeEnv !== 'production' || process.env.WIDGET_TEST_MODE === 'true';

      res.json({
        ok: overallOk,
        timestamp: new Date().toISOString(),
        db: { ok: dbOk, latencyMs: dbLatencyMs },
        ai: { configured: aiConfigured },
        errorsLast15m,
        totalErrors,
        lastErrorTimestamps,
        demoWorkspaceReady,
        testModeAllowed,
        build: {
          env: nodeEnv,
          version: process.env.npm_package_version || '1.0.0',
          uptime: Math.floor(process.uptime()),
        },
      });
    } catch (error) {
      const nodeEnv = process.env.NODE_ENV || 'development';
      res.status(503).json({
        ok: false,
        timestamp: new Date().toISOString(),
        error: 'Internal health check failed',
        db: { ok: false },
        ai: { configured: false },
        build: { env: nodeEnv },
      });
    }
  });
  
  // =============================================
  // EMBEDDABLE CHAT WIDGET - Static Files & CORS
  // =============================================
  
  // CORS middleware for widget endpoints
  const widgetCors = (req: Request, res: Response, next: NextFunction) => {
    // Allow any origin to access widget resources (for embedding on client sites)
    const origin = req.headers.origin;
    if (origin) {
      res.setHeader('Access-Control-Allow-Origin', origin);
    } else {
      res.setHeader('Access-Control-Allow-Origin', '*');
    }
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Max-Age', '86400');
    
    if (req.method === 'OPTIONS') {
      return res.status(204).end();
    }
    next();
  };
  
  // Apply CORS to widget chat endpoint
  app.options('/api/chat/:clientId/:botId', widgetCors);
  app.use('/api/chat/:clientId/:botId', widgetCors);
  
  // Serve widget static files with proper headers
  const widgetPath = path.join(process.cwd(), 'public', 'widget');
  app.use('/widget', (req: Request, res: Response, next: NextFunction) => {
    // Set CORS headers for widget files
    const origin = req.headers.origin;
    if (origin) {
      res.setHeader('Access-Control-Allow-Origin', origin);
    } else {
      res.setHeader('Access-Control-Allow-Origin', '*');
    }
    
    // Set appropriate content types
    const ext = path.extname(req.path).toLowerCase();
    if (ext === '.js') {
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    } else if (ext === '.css') {
      res.setHeader('Content-Type', 'text/css; charset=utf-8');
    } else if (ext === '.html') {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
    }
    
    // Cache control for production
    if (process.env.NODE_ENV === 'production') {
      res.setHeader('Cache-Control', 'public, max-age=3600');
    }
    
    next();
  }, express.static(widgetPath));

  // Serve test pages for widget testing (only in development)
  const testPath = path.join(process.cwd(), 'public', 'test');
  app.use('/test', (req: Request, res: Response, next: NextFunction) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    next();
  }, express.static(testPath));
  
  // Serve widget-test.html for testing embedded widget
  app.get('/widget-test.html', (req: Request, res: Response) => {
    const testFile = path.join(process.cwd(), 'public', 'widget-test.html');
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.sendFile(testFile);
  });
  
  // Generate default quick actions based on bot type
  function getDefaultQuickActions(botType?: string, businessName?: string): Array<{id: string; label: string; labelEs?: string}> {
    const defaults: Record<string, Array<{id: string; label: string; labelEs?: string}>> = {
      'restaurant': [
        { id: 'menu', label: 'View Menu', labelEs: 'Ver Menú' },
        { id: 'hours', label: 'Hours & Location', labelEs: 'Horario y Ubicación' },
        { id: 'reservation', label: 'Make Reservation', labelEs: 'Hacer Reservación' },
        { id: 'specials', label: "Today's Specials", labelEs: 'Especiales del Día' },
        { id: 'delivery', label: 'Delivery Options', labelEs: 'Opciones de Entrega' },
        { id: 'contact', label: 'Contact Us', labelEs: 'Contáctenos' },
      ],
      'barber': [
        { id: 'services', label: 'Our Services', labelEs: 'Nuestros Servicios' },
        { id: 'pricing', label: 'Pricing', labelEs: 'Precios' },
        { id: 'appointment', label: 'Book Appointment', labelEs: 'Reservar Cita' },
        { id: 'hours', label: 'Hours & Location', labelEs: 'Horario y Ubicación' },
        { id: 'barbers', label: 'Our Barbers', labelEs: 'Nuestros Barberos' },
        { id: 'contact', label: 'Contact Us', labelEs: 'Contáctenos' },
      ],
      'gym': [
        { id: 'memberships', label: 'Membership Options', labelEs: 'Opciones de Membresía' },
        { id: 'classes', label: 'Class Schedule', labelEs: 'Horario de Clases' },
        { id: 'tour', label: 'Schedule Tour', labelEs: 'Agendar Tour' },
        { id: 'hours', label: 'Hours & Location', labelEs: 'Horario y Ubicación' },
        { id: 'trainers', label: 'Personal Trainers', labelEs: 'Entrenadores' },
        { id: 'contact', label: 'Contact Us', labelEs: 'Contáctenos' },
      ],
      'auto_shop': [
        { id: 'services', label: 'Our Services', labelEs: 'Nuestros Servicios' },
        { id: 'estimate', label: 'Get Estimate', labelEs: 'Obtener Cotización' },
        { id: 'appointment', label: 'Book Appointment', labelEs: 'Reservar Cita' },
        { id: 'hours', label: 'Hours & Location', labelEs: 'Horario y Ubicación' },
        { id: 'specials', label: 'Current Specials', labelEs: 'Especiales Actuales' },
        { id: 'contact', label: 'Contact Us', labelEs: 'Contáctenos' },
      ],
      'sober_living': [
        { id: 'about', label: `About ${businessName || 'Us'}`, labelEs: `Sobre ${businessName || 'Nosotros'}` },
        { id: 'requirements', label: 'Requirements', labelEs: 'Requisitos' },
        { id: 'availability', label: 'Availability', labelEs: 'Disponibilidad' },
        { id: 'pricing', label: 'Pricing', labelEs: 'Precios' },
        { id: 'tour', label: 'Request Tour', labelEs: 'Solicitar Tour' },
        { id: 'contact', label: 'Contact Info', labelEs: 'Información de Contacto' },
      ],
      'med_spa': [
        { id: 'treatments', label: 'Our Treatments', labelEs: 'Nuestros Tratamientos' },
        { id: 'pricing', label: 'Pricing', labelEs: 'Precios' },
        { id: 'consultation', label: 'Book Consultation', labelEs: 'Reservar Consulta' },
        { id: 'specials', label: 'Current Specials', labelEs: 'Especiales Actuales' },
        { id: 'hours', label: 'Hours & Location', labelEs: 'Horario y Ubicación' },
        { id: 'contact', label: 'Contact Us', labelEs: 'Contáctenos' },
      ],
      'real_estate': [
        { id: 'listings', label: 'View Listings', labelEs: 'Ver Propiedades' },
        { id: 'buying', label: 'Buying Help', labelEs: 'Ayuda para Comprar' },
        { id: 'selling', label: 'Selling Help', labelEs: 'Ayuda para Vender' },
        { id: 'schedule', label: 'Schedule Viewing', labelEs: 'Agendar Visita' },
        { id: 'valuation', label: 'Home Valuation', labelEs: 'Valuación de Casa' },
        { id: 'contact', label: 'Contact Agent', labelEs: 'Contactar Agente' },
      ],
      'home_services': [
        { id: 'services', label: 'Our Services', labelEs: 'Nuestros Servicios' },
        { id: 'quote', label: 'Get Free Quote', labelEs: 'Cotización Gratis' },
        { id: 'schedule', label: 'Schedule Service', labelEs: 'Agendar Servicio' },
        { id: 'areas', label: 'Service Areas', labelEs: 'Áreas de Servicio' },
        { id: 'reviews', label: 'Customer Reviews', labelEs: 'Reseñas de Clientes' },
        { id: 'contact', label: 'Contact Us', labelEs: 'Contáctenos' },
      ],
      'tattoo': [
        { id: 'portfolio', label: 'View Portfolio', labelEs: 'Ver Portafolio' },
        { id: 'artists', label: 'Our Artists', labelEs: 'Nuestros Artistas' },
        { id: 'consultation', label: 'Book Consultation', labelEs: 'Reservar Consulta' },
        { id: 'pricing', label: 'Pricing Info', labelEs: 'Información de Precios' },
        { id: 'aftercare', label: 'Aftercare Tips', labelEs: 'Consejos de Cuidado' },
        { id: 'contact', label: 'Contact Us', labelEs: 'Contáctenos' },
      ],
    };
    
    return defaults[botType || 'generic'] || [
      { id: 'services', label: 'Our Services', labelEs: 'Nuestros Servicios' },
      { id: 'pricing', label: 'Pricing', labelEs: 'Precios' },
      { id: 'hours', label: 'Hours & Location', labelEs: 'Horario y Ubicación' },
      { id: 'contact', label: 'Contact Us', labelEs: 'Contáctenos' },
      { id: 'appointment', label: 'Book Appointment', labelEs: 'Reservar Cita' },
      { id: 'faq', label: 'FAQs', labelEs: 'Preguntas Frecuentes' },
    ];
  }

  // Widget configuration endpoint
  app.get('/api/widget/config/:clientId/:botId', widgetCors, async (req, res) => {
    try {
      const { clientId, botId } = req.params;
      
      const botConfig = await getBotConfigAsync(clientId, botId);
      if (!botConfig) {
        return res.status(404).json({ error: 'Bot not found' });
      }
      
      const clientStatus = getClientStatus(clientId);
      if (clientStatus === 'paused') {
        return res.json({
          status: 'paused',
          message: 'This service is currently paused.'
        });
      }
      
      // Phase 2.4: Generate signed widget token (expires in 24 hours)
      const widgetToken = generateWidgetToken(clientId, botId, 86400);
      
      // Get quick actions - use bot config if set, otherwise use defaults based on bot type
      const quickActions = botConfig.quickActions && botConfig.quickActions.length > 0
        ? botConfig.quickActions
        : getDefaultQuickActions(botConfig.botType, botConfig.businessProfile?.businessName);
      
      // Get client settings for behavior configuration
      const settings = await storage.getSettings(clientId);
      
      // Return safe widget configuration (no sensitive data)
      res.json({
        status: 'active',
        botName: botConfig.name,
        businessName: botConfig.businessProfile?.businessName || botConfig.name,
        botTagline: `${botConfig.businessProfile?.businessName || 'AI'} Assistant`,
        welcomeMessage: `Hi! I'm the ${botConfig.businessProfile?.businessName || 'AI'} assistant. How can I help you today?`,
        primaryColor: '#2563eb',
        theme: 'dark',
        token: widgetToken,
        quickActions,
        enableHumanHandoff: true,
        // Behavior settings for AI behavior control
        behaviorPreset: settings?.behaviorPreset || 'support_lead_focused',
        leadCaptureEnabled: settings?.leadCaptureEnabled ?? true,
        leadDetectionSensitivity: settings?.leadDetectionSensitivity || 'medium',
      });
    } catch (error) {
      structuredLogger.error('Widget config error:', error);
      res.status(500).json({ error: 'Failed to load widget configuration' });
    }
  });

  // =============================================
  // PUBLIC PREVIEW PAGE API - Token-validated preview access
  // =============================================
  
  // Get preview page data (public, token-validated)
  app.get('/api/preview/:workspaceSlug', async (req, res) => {
    try {
      const { workspaceSlug } = req.params;
      const token = req.query.t as string;
      
      if (!token) {
        return res.status(401).json({ error: 'Preview token required' });
      }
      
      // Verify the preview token
      const tokenResult = verifyPreviewToken(token, workspaceSlug);
      if (!tokenResult.valid || !tokenResult.payload) {
        return res.status(401).json({ error: tokenResult.error || 'Invalid preview token' });
      }
      
      const { botId } = tokenResult.payload;
      
      // Get workspace info
      const workspace = await getWorkspaceBySlug(workspaceSlug);
      if (!workspace) {
        return res.status(404).json({ error: 'Workspace not found' });
      }
      
      // Get bot config
      const botConfig = await getBotConfigByBotIdAsync(botId) || getBotConfigByBotId(botId);
      if (!botConfig) {
        return res.status(404).json({ error: 'Bot not found' });
      }
      
      // Get time remaining on token
      const timeRemaining = getTokenTimeRemaining(tokenResult.payload);
      
      // Generate a widget token for the preview session (uses same expiry as preview token)
      const secondsLeft = Math.max(60, tokenResult.payload.exp - Math.floor(Date.now() / 1000));
      const widgetToken = generateWidgetToken(botConfig.clientId, botId, secondsLeft);
      
      // Get quick actions
      const quickActions = botConfig.quickActions && botConfig.quickActions.length > 0
        ? botConfig.quickActions
        : getDefaultQuickActions(botConfig.botType, botConfig.businessProfile?.businessName);
      
      // Build wow buttons - showcase bot capabilities
      const wowButtons = [
        { label: 'Tell me about your services', message: 'What services do you offer?' },
        { label: 'Book an appointment', message: 'I would like to book an appointment' },
        { label: 'What are your hours?', message: 'What are your business hours?' },
        { label: 'Contact information', message: 'How can I contact you?' },
        { label: 'Pricing info', message: 'Tell me about your pricing' },
      ];
      
      // Return preview page data
      res.json({
        success: true,
        preview: {
          workspaceSlug,
          workspaceName: workspace.name || workspaceSlug,
          botId,
          botName: botConfig.name,
          businessName: botConfig.businessProfile?.businessName || botConfig.name,
          businessType: botConfig.botType || 'generic',
          logo: botConfig.businessProfile?.logo || null,
          primaryColor: botConfig.widgetSettings?.primaryColor || '#06b6d4',
          tagline: botConfig.businessProfile?.tagline || `Your AI Assistant`,
        },
        widget: {
          clientId: botConfig.clientId,
          botId,
          token: widgetToken,
          quickActions,
        },
        wowButtons,
        expiry: {
          expiresAt: new Date(tokenResult.payload.exp * 1000).toISOString(),
          timeRemaining: timeRemaining.humanReadable,
          hoursRemaining: timeRemaining.hoursRemaining,
          secondsRemaining: timeRemaining.secondsRemaining,
        },
      });
    } catch (error) {
      structuredLogger.error('[Preview API] Error:', error);
      res.status(500).json({ error: 'Failed to load preview data' });
    }
  });

  // =============================================
  // PLATFORM HELP BOT - Answers questions about Treasure Coast AI
  // =============================================
  const PLATFORM_KNOWLEDGE = `You are the Treasure Coast AI Platform Assistant - an incredibly helpful, friendly, and knowledgeable AI that helps users understand and navigate the Treasure Coast AI platform.

## About Treasure Coast AI
Treasure Coast AI is a premium, agency-managed AI assistant platform for local businesses. We BUILD and MANAGE custom AI assistants powered by GPT-4 for businesses - they don't have to do anything technical. It's a fully managed service.

## Core Concept
- Agency-managed service: Tyler (the agency) builds and manages ALL bots
- Clients get VIEW-ONLY dashboards to see their conversations, leads, and bookings
- No self-service bot creation - we handle everything for the client
- Premium experience with white-glove service

## Key Features
1. **Custom AI Assistants**: GPT-4 powered assistants trained on each business's specific info
2. **Lead Capture**: Automatically captures names, emails, and phone numbers
3. **Appointment Booking**: AI handles scheduling and booking requests
4. **24/7 Availability**: Bots work around the clock, never taking breaks
5. **Client Dashboard**: View-only analytics showing conversations, leads, and bookings
6. **Fully Managed**: We handle all setup, training, and ongoing management

## Pricing (Approximate)
- Starter: $297/month - 1 bot, 500 conversations, basic features
- Professional: $497/month - 1 bot, unlimited conversations, advanced features
- Enterprise: Custom pricing - multiple bots, white-label, dedicated support

## How It Works
1. Business shares their info (services, hours, FAQs, etc.)
2. We build and configure their custom AI assistant
3. We deploy the widget on their website
4. They log into their dashboard to see results

## Technical Details (for curious users)
- Powered by OpenAI GPT-4
- Embeddable chat widget for any website
- Real-time conversation analytics
- Secure, encrypted data handling
- Professional glassmorphism design with cyan/purple accents

## Your Personality
- Be incredibly helpful, friendly, and enthusiastic
- Use simple language - no technical jargon unless asked
- Be confident about the platform's capabilities
- If you don't know something, offer to connect them with the team
- Keep responses concise but informative (2-4 sentences max)
- Never use emojis in your responses

## Common Questions You Should Handle
- What is Treasure Coast AI?
- How does the AI assistant work?
- What's included in each pricing tier?
- How long does setup take? (48-72 hours typically)
- Can I customize my bot's personality?
- How do I see my leads and conversations?
- What industries do you serve?
- How do I get started?

Always be positive and solution-oriented. If someone wants to get started, direct them to fill out the contact form or mention they can reach out for a consultation.`;

  app.post("/api/platform-help/chat", async (req, res) => {
    try {
      const { message, history, context } = req.body;
      
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ error: 'Message is required' });
      }

      if (!openai) {
        return res.status(503).json({ error: 'AI service not configured' });
      }

      // Build conversation history
      const messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }> = [
        { role: 'system', content: PLATFORM_KNOWLEDGE }
      ];

      // Add history if provided
      if (Array.isArray(history)) {
        for (const msg of history.slice(-10)) { // Limit to last 10 messages
          if (msg.role === 'user' || msg.role === 'assistant') {
            messages.push({ role: msg.role, content: msg.content });
          }
        }
      }

      // Add current message
      messages.push({ role: 'user', content: message });

      const completion = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages,
        max_tokens: 300,
        temperature: 0.7,
      });

      const response = completion.choices[0]?.message?.content || 
        "I'm here to help! Feel free to ask me anything about Treasure Coast AI.";

      res.json({ response });
    } catch (error) {
      structuredLogger.error('Platform help chat error:', error);
      res.status(500).json({ error: 'Failed to process message' });
    }
  });
  
  app.post("/api/chat", async (req, res) => {
    try {
      const validation = validateRequest(chatBodySchema, req.body);
      if (!validation.success) {
        return res.status(400).json({ error: validation.error });
      }
      const { messages, sessionId, language, clientId: bodyClientId, botId: bodyBotId } = validation.data;
      
      // clientId is required for tenant isolation
      if (!bodyClientId) {
        return res.status(400).json({ error: "Client ID required" });
      }
      const effectiveClientId = bodyClientId;

      if (sessionId && messages.length > 0) {
        const lastUserMessage = messages[messages.length - 1];
        if (lastUserMessage.role === "user") {
          await storage.logConversation(effectiveClientId, {
            sessionId,
            role: "user",
            content: sanitizePII(lastUserMessage.content),
            category: null
          });
          
          if (detectCrisisKeywords(lastUserMessage.content, language)) {
            const crisisReply = getCrisisResponse(language);
            
            await storage.logConversation(effectiveClientId, {
              sessionId,
              role: "assistant",
              content: sanitizePII(crisisReply),
              category: "crisis_redirect"
            });
            
            return res.json({ reply: crisisReply });
          }
        }
      }

      const systemPrompt = await getSystemPrompt(language, effectiveClientId);
      
      if (!openai) {
        return res.status(503).json({ error: "AI service not configured" });
      }

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages
        ],
        max_completion_tokens: 500,
      });

      const defaultReply = language === "es" 
        ? "Estoy aquí para ayudar. ¿Cómo puedo asistirte hoy?"
        : "I'm here to help. How can I assist you today?";
      const reply = completion.choices[0]?.message?.content || defaultReply;
      
      if (sessionId) {
        const category = categorizeMessage(reply, "assistant");
        await storage.logConversation(effectiveClientId, {
          sessionId,
          role: "assistant",
          content: sanitizePII(reply),
          category
        });
      }
      
      const lastUserMessage = messages[messages.length - 1];
      const userWantsToBook = lastUserMessage?.role === "user" && detectBookingIntent(lastUserMessage.content, language);
      
      res.json({ 
        reply,
        showAppointmentFlow: userWantsToBook
      });
    } catch (error) {
      structuredLogger.error("Chat error:", error);
      res.status(500).json({ error: "Failed to process chat message" });
    }
  });

  // =============================================
  // MULTI-TENANT CHAT ENDPOINTS (UNIFIED ORCHESTRATOR)
  // =============================================

  // Multi-tenant chat endpoint: POST /api/chat/:clientId/:botId
  // Uses the unified orchestrator for consistent behavior across all surfaces
  app.post("/api/chat/:clientId/:botId", async (req, res) => {
    try {
      // Validate params
      const paramsValidation = validateRequest(clientBotParamsSchema, req.params);
      if (!paramsValidation.success) {
        return res.status(400).json({ error: paramsValidation.error });
      }
      const { clientId, botId } = paramsValidation.data;
      
      // Load bot configuration first to check security settings
      const botConfig = await getBotConfigAsync(clientId, botId);
      if (!botConfig) {
        return res.status(404).json({ error: `Bot not found: ${clientId}/${botId}` });
      }

      // HTTP-level security: Widget token validation
      const authHeader = req.headers.authorization;
      const isProduction = process.env.NODE_ENV === 'production';
      const requireToken = botConfig.security?.requireWidgetToken ?? false;
      
      if (authHeader?.startsWith('Bearer ')) {
        const token = authHeader.substring(7);
        const tokenResult = verifyWidgetToken(token);
        
        if (!tokenResult.valid) {
          return res.status(401).json({ error: 'Invalid widget token', details: tokenResult.error });
        }
        
        if (tokenResult.clientId !== clientId || tokenResult.botId !== botId) {
          return res.status(403).json({ error: 'Token mismatch - clientId/botId does not match token' });
        }
      } else if (requireToken) {
        return res.status(401).json({ 
          error: 'Widget token required',
          message: 'This bot requires authentication. Please obtain a token from /api/widget/config'
        });
      } else if (isProduction) {
        structuredLogger.warn(`[SECURITY] Chat request without widget token for ${clientId}/${botId}`);
      }
      
      // HTTP-level security: Domain validation
      if (botConfig.security?.allowedDomains && botConfig.security.allowedDomains.length > 0) {
        const origin = req.get('origin') || req.get('referer');
        if (origin) {
          try {
            const originDomain = new URL(origin).hostname;
            const isAllowed = botConfig.security.allowedDomains.some(domain => 
              originDomain === domain || originDomain.endsWith(`.${domain}`)
            );
            if (!isAllowed) {
              structuredLogger.warn(`[SECURITY] Request from unauthorized domain ${originDomain} for ${clientId}/${botId}`);
              return res.status(403).json({ 
                error: 'Domain not authorized',
                message: 'This widget is not authorized to run on this domain'
              });
            }
          } catch {
            structuredLogger.warn(`[SECURITY] Invalid origin header for ${clientId}/${botId}: ${origin}`);
          }
        }
      }
      
      // Validate body
      const bodyValidation = validateRequest(chatBodySchema, req.body);
      if (!bodyValidation.success) {
        return res.status(400).json({ error: bodyValidation.error });
      }
      const { messages, sessionId, language } = bodyValidation.data;
      
      // Determine source from request context
      const source = req.body.source || 'widget';
      const actualSessionId = sessionId || `session_${Date.now()}`;
      
      // Use unified orchestrator for all chat processing
      const { orchestrator } = await import('./orchestrator');
      const result = await orchestrator.processMessage({
        clientId,
        botId,
        messages,
        sessionId: actualSessionId,
        language: language || 'en',
        source,
        widgetToken: authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : undefined,
      });
      
      // Handle orchestrator errors
      if (!result.success) {
        const statusMap: Record<string, number> = {
          'BOT_NOT_FOUND': 404,
          'CLIENT_PAUSED': 503,
          'LIMIT_EXCEEDED': 429,
          'AI_UNAVAILABLE': 503,
          'INTERNAL_ERROR': 500,
        };
        const status = statusMap[result.errorCode || 'INTERNAL_ERROR'] || 500;
        return res.status(status).json({ 
          error: result.error,
          message: result.error,
          status: result.errorCode === 'CLIENT_PAUSED' ? 'paused' : undefined,
        });
      }
      
      // Run AI analysis asynchronously (after response sent)
      res.json({ 
        reply: result.reply,
        meta: result.meta
      });
      
      // Background AI analysis for lead enrichment
      (async () => {
        try {
          const contactInfo = extractContactInfo(messages);
          const userMessageTexts = messages.filter(m => m.role === 'user').map(m => m.content);
          const conversationPreview = await generateQuickSummary(userMessageTexts) || messages[messages.length - 1]?.content?.slice(0, 200) || '';
          const analysis = await analyzeConversation(messages, botConfig.businessProfile?.type || 'general');
          
          if (analysis) {
            const freshSession = await storage.getChatSession(actualSessionId, clientId, botId);
            const freshMetadata = (freshSession?.metadata as Record<string, unknown>) || {};
            
            const updatedMetadata = {
              ...freshMetadata,
              aiSummary: analysis.summary,
              userIntent: analysis.userIntent,
              sentiment: analysis.sentiment,
              leadQuality: analysis.leadQuality,
              bookingIntent: analysis.bookingIntent,
              analyzedAt: new Date().toISOString()
            };
            
            await storage.createOrUpdateChatSession({
              sessionId: actualSessionId,
              clientId,
              botId,
              appointmentRequested: analysis.bookingIntent || freshSession?.appointmentRequested || false,
              topics: freshSession?.topics as string[] || [],
              metadata: updatedMetadata as any,
              needsReview: analysis.needsReview,
              reviewReason: analysis.reviewReason
            });
          }
          
          await autoCaptureLead(
            clientId,
            botId,
            actualSessionId,
            contactInfo,
            conversationPreview,
            result.meta.showBooking,
            analysis
          );
        } catch (err) {
          structuredLogger.error('[AI Analysis] Background processing failed:', err);
        }
      })();
    } catch (error) {
      structuredLogger.error("Multi-tenant chat error:", error);
      res.status(500).json({ error: "Failed to process chat message" });
    }
  });

  // Streaming chat endpoint with SSE
  app.post("/api/chat/:clientId/:botId/stream", widgetCors, async (req, res) => {
    const startTime = Date.now();
    
    try {
      // Validate params
      const paramsValidation = validateRequest(clientBotParamsSchema, req.params);
      if (!paramsValidation.success) {
        return res.status(400).json({ error: paramsValidation.error });
      }
      const { clientId, botId } = paramsValidation.data;
      
      // Validate body
      const bodyValidation = validateRequest(chatBodySchema, req.body);
      if (!bodyValidation.success) {
        return res.status(400).json({ error: bodyValidation.error });
      }
      const { messages, sessionId, language } = bodyValidation.data;

      // Load bot configuration
      const botConfig = await getBotConfigAsync(clientId, botId);
      if (!botConfig) {
        return res.status(404).json({ error: `Bot not found: ${clientId}/${botId}` });
      }

      // Check client status
      const clientStatus = getClientStatus(clientId);
      if (clientStatus === 'paused') {
        return res.status(503).json({ 
          error: "Service temporarily unavailable",
          message: "This service is currently paused."
        });
      }

      // Check plan limits
      const limitCheck = await checkMessageLimit(clientId);
      if (!limitCheck.allowed) {
        return res.status(429).json({
          error: "Usage limit reached",
          message: limitCheck.reason
        });
      }

      const lastUserMessage = messages[messages.length - 1];
      const actualSessionId = sessionId || `session_${Date.now()}`;
      
      // Crisis detection (non-streamed response)
      if (lastUserMessage?.role === "user" && detectCrisisInMessage(lastUserMessage.content, botConfig)) {
        const crisisReply = getBotCrisisResponse(botConfig);
        return res.json({ 
          reply: crisisReply,
          meta: { clientId, botId, crisis: true, sessionId: actualSessionId }
        });
      }

      // Set up SSE headers
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.flushHeaders();

      // Fetch client settings for external booking/payment URLs
      const clientSettings = await storage.getSettings(clientId);
      
      // Inject external URLs into bot config for system prompt building
      // Check clientSettings first, then fall back to botConfig (for JSON-defined bots)
      const resolvedExternalBookingUrl = clientSettings?.externalBookingUrl || botConfig.externalBookingUrl || undefined;
      const resolvedExternalPaymentUrl = clientSettings?.externalPaymentUrl || botConfig.externalPaymentUrl || undefined;
      const botConfigWithUrls = {
        ...botConfig,
        externalBookingUrl: resolvedExternalBookingUrl,
        externalPaymentUrl: resolvedExternalPaymentUrl,
      };

      // Build system prompt with suggested replies instruction
      const systemPrompt = buildSystemPromptFromConfig(botConfigWithUrls, clientSettings?.behaviorPreset as any);
      const enhancedPrompt = `${systemPrompt}

IMPORTANT: After your response, always include 2-3 suggested follow-up questions the user might want to ask. Format them as JSON at the very end of your response on a new line like this:
[SUGGESTIONS]{"replies":["Question 1?","Question 2?","Question 3?"]}[/SUGGESTIONS]
These suggestions should be relevant to what was just discussed and help guide the conversation.`;

      if (!openai) {
        res.write(`data: ${JSON.stringify({ type: 'error', error: 'AI service not configured' })}\n\n`);
        res.end();
        return;
      }

      let fullReply = '';
      
      // Create streaming completion
      const stream = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: enhancedPrompt },
          ...messages
        ],
        max_completion_tokens: 500,
        stream: true,
      });

      // Stream the response
      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || '';
        if (content) {
          fullReply += content;
          
          // Don't stream the suggestions metadata
          if (!content.includes('[SUGGESTIONS]') && !fullReply.includes('[SUGGESTIONS]')) {
            res.write(`data: ${JSON.stringify({ type: 'chunk', content })}\n\n`);
          }
        }
      }

      const responseTime = Date.now() - startTime;
      
      // Extract suggested replies from the response
      let suggestedReplies: string[] = [];
      let cleanReply = fullReply;
      
      const suggestionsMatch = fullReply.match(/\[SUGGESTIONS\](.*?)\[\/SUGGESTIONS\]/s);
      if (suggestionsMatch) {
        try {
          const suggestionsData = JSON.parse(suggestionsMatch[1]);
          suggestedReplies = suggestionsData.replies || [];
          cleanReply = fullReply.replace(/\[SUGGESTIONS\].*?\[\/SUGGESTIONS\]/s, '').trim();
        } catch (e) {
          structuredLogger.error('Failed to parse suggestions:', e);
        }
      }

      // Check for booking intent - explicit phrases, affirmative responses, or already in booking flow
      const streamingBookingKeywords = /\b(book|booking|schedule|scheduling|appointment|reserve|reservation)\b|\bset up (a |an )?(appointment|meeting|visit|consultation)\b|\bwant to (come in|visit|see you)\b/i;
      const affirmativeKeywords = /\b(yes|yeah|sure|please|ok|okay|sounds good|that works|let'?s do|perfect|great)\b/i;
      const aiAskedAboutBooking = /\b(schedule|book|appointment|come in|visit|when|preferred|date|time)\b/i;
      
      // Get the PREVIOUS assistant message (not the current reply)
      const previousAssistantMessage = messages.filter(m => m.role === 'assistant').slice(-1)[0]?.content || "";
      
      const directBookingIntent = streamingBookingKeywords.test(lastUserMessage?.content || "");
      const isAffirmativeToBookingPrompt = affirmativeKeywords.test(lastUserMessage?.content || "") && aiAskedAboutBooking.test(previousAssistantMessage);
      
      // Check if session already has booking request
      const existingSessionForBooking = await storage.getChatSession(actualSessionId, clientId, botId);
      const alreadyRequestedBooking = existingSessionForBooking?.appointmentRequested || false;
      
      // Check if ANY message in the conversation history has booking intent
      const conversationHasBookingIntent = messages.some(m => m.role === 'user' && streamingBookingKeywords.test(m.content || ""));
      
      // Check if AI response mentions booking button/scheduling (indicating booking flow is active)
      const aiMentionsBookingButton = /\b(book\s*appointment|click.*button|scheduling\s*page|finalize.*booking|complete.*booking)\b/i.test(cleanReply);
      
      const mentionsAppointment = directBookingIntent || isAffirmativeToBookingPrompt || alreadyRequestedBooking || conversationHasBookingIntent || aiMentionsBookingButton;
      const streamingExternalBookingUrl = mentionsAppointment ? (resolvedExternalBookingUrl || null) : null;
      const streamingExternalPaymentUrl = mentionsAppointment ? (resolvedExternalPaymentUrl || null) : null;

      // Send final message with metadata
      res.write(`data: ${JSON.stringify({ 
        type: 'done', 
        suggestedReplies,
        meta: { 
          clientId, 
          botId, 
          sessionId: actualSessionId, 
          responseTimeMs: responseTime,
          showBooking: mentionsAppointment,
          externalBookingUrl: streamingExternalBookingUrl,
          externalPaymentUrl: streamingExternalPaymentUrl
        }
      })}\n\n`);
      
      res.end();

      // Async analytics and logging (after response is sent)
      const messageCategory = categorizeMessageTopic(lastUserMessage?.content || "");
      const existingSession = await storage.getChatSession(actualSessionId, clientId, botId);
      
      const sessionData = {
        sessionId: actualSessionId,
        clientId,
        botId,
        startedAt: existingSession?.startedAt || new Date(),
        userMessageCount: (existingSession?.userMessageCount || 0) + 1,
        botMessageCount: (existingSession?.botMessageCount || 0) + 1,
        totalResponseTimeMs: (existingSession?.totalResponseTimeMs || 0) + responseTime,
        crisisDetected: existingSession?.crisisDetected || false,
        appointmentRequested: existingSession?.appointmentRequested || directBookingIntent || isAffirmativeToBookingPrompt || conversationHasBookingIntent,
        topics: [...(existingSession?.topics as string[] || [])],
      };
      
      if (messageCategory && !sessionData.topics.includes(messageCategory)) {
        sessionData.topics.push(messageCategory);
      }

      await storage.createOrUpdateChatSession(sessionData);
      
      // Log booking intent analytics event if booking detected
      if (mentionsAppointment) {
        await storage.logAnalyticsEvent({
          clientId,
          botId,
          sessionId: actualSessionId,
          eventType: 'booking_intent',
          actor: 'user',
          messageContent: lastUserMessage?.content || "",
          metadata: { 
            hasBookingUrl: !!streamingExternalBookingUrl,
            bookingUrl: streamingExternalBookingUrl,
          } as Record<string, any>,
        });
      }
      await incrementMessageCount(clientId);
      
      await storage.updateOrCreateDailyAnalytics({
        date: new Date().toISOString().split('T')[0],
        clientId,
        botId,
        totalConversations: existingSession ? 0 : 1,
        totalMessages: 2,
        userMessages: 1,
        botMessages: 1,
      });

      // Log to file
      logConversationToFile({
        timestamp: new Date().toISOString(),
        clientId,
        botId,
        sessionId: actualSessionId,
        userMessage: lastUserMessage?.content || "",
        botReply: cleanReply
      });

      // Run AI analysis and lead capture asynchronously (streaming - after response sent)
      (async () => {
        try {
          const contactInfo = extractContactInfo(messages);
          const userMessageTexts = messages.filter(m => m.role === 'user').map(m => m.content);
          const conversationPreview = await generateQuickSummary(userMessageTexts) || lastUserMessage?.content?.slice(0, 200) || '';
          
          // Run AI analysis for richer insights
          const analysis = await analyzeConversation(messages, botConfig.businessProfile?.type || 'general');
          
          // Update session with AI analysis - fetch fresh session state to avoid race conditions
          if (analysis) {
            const freshSession = await storage.getChatSession(actualSessionId, clientId, botId);
            const freshMetadata = (freshSession?.metadata as Record<string, unknown>) || {};
            
            const updatedMetadata = {
              ...freshMetadata,
              aiSummary: analysis.summary,
              userIntent: analysis.userIntent,
              sentiment: analysis.sentiment,
              leadQuality: analysis.leadQuality,
              bookingIntent: analysis.bookingIntent,
              analyzedAt: new Date().toISOString()
            };
            
            await storage.createOrUpdateChatSession({
              sessionId: actualSessionId,
              clientId,
              botId,
              appointmentRequested: analysis.bookingIntent || freshSession?.appointmentRequested || false,
              topics: freshSession?.topics as string[] || [],
              metadata: updatedMetadata as any,
              needsReview: analysis.needsReview,
              reviewReason: analysis.reviewReason
            });
            
            if (analysis.needsReview) {
              structuredLogger.info(`[AI Analysis] Streaming session ${actualSessionId} FLAGGED for review: ${analysis.reviewReason}`);
            } else {
              structuredLogger.info(`[AI Analysis] Streaming session ${actualSessionId} enriched`);
            }
          }
          
          // Capture lead with AI insights
          await autoCaptureLead(
            clientId,
            botId,
            actualSessionId,
            contactInfo,
            conversationPreview,
            analysis?.bookingIntent || sessionData.appointmentRequested || false,
            analysis
          );
          
          // AI-driven appointment creation: When AI confirms booking with complete info
          try {
            const lastUserMsg = messages[messages.length - 1]?.content || "";
            // Convert messages to orchestrator format
            const orchestratorMessages: OrchestratorChatMessage[] = messages.map(m => ({
              role: m.role as 'user' | 'assistant',
              content: m.content
            }));
            const bookingInfo = extractBookingInfoFromConversation(orchestratorMessages, cleanReply, lastUserMsg);
            
            if (bookingInfo && bookingInfo.isComplete) {
              // Check if we already created a booking for this session
              const existingAppointment = await storage.getAppointmentBySessionId(actualSessionId, clientId);
              
              if (!existingAppointment) {
                structuredLogger.info(`[Streaming] Creating AI-driven booking for session ${actualSessionId}`, {
                  clientId,
                  botId,
                  sessionId: actualSessionId,
                  bookingType: bookingInfo.bookingType,
                  name: bookingInfo.name,
                  hasPhone: !!bookingInfo.phone,
                  hasEmail: !!bookingInfo.email,
                });
                
                await storage.createAppointment(clientId, {
                  name: bookingInfo.name!,
                  contact: bookingInfo.phone!,
                  email: bookingInfo.email || null,
                  preferredTime: bookingInfo.preferredTime || 'To be confirmed',
                  scheduledAt: bookingInfo.scheduledAt ? new Date(bookingInfo.scheduledAt) : null,
                  appointmentType: bookingInfo.bookingType,
                  notes: bookingInfo.notes || null,
                  contactPreference: 'phone',
                  botId: botId,
                  sessionId: actualSessionId,
                });
                
                structuredLogger.info(`[Streaming] Booking created successfully: ${bookingInfo.bookingType} for ${bookingInfo.name}`);
              }
            }
          } catch (bookingErr) {
            structuredLogger.error('[Streaming] Error creating AI-driven booking:', bookingErr);
          }
        } catch (err) {
          structuredLogger.error('[AI Analysis] Streaming processing failed:', err);
        }
      })();

    } catch (error: any) {
      structuredLogger.error("Streaming chat error:", error);
      
      // Check for OpenAI rate limit error
      const isRateLimitError = error?.status === 429 || 
        error?.code === 'rate_limit_exceeded' ||
        error?.message?.includes('Rate limit') ||
        error?.message?.includes('rate_limit');
      
      if (isRateLimitError) {
        structuredLogger.error("[Streaming] OpenAI rate limit exceeded - providing fallback response");
        const fallbackMessage = "I apologize, but our AI service is currently experiencing high demand. Please try again in a few moments, or feel free to call us directly at the number listed on this page for immediate assistance.";
        
        if (!res.headersSent) {
          res.setHeader('Content-Type', 'text/event-stream');
          res.setHeader('Cache-Control', 'no-cache');
          res.setHeader('Connection', 'keep-alive');
          res.flushHeaders();
        }
        
        res.write(`data: ${JSON.stringify({ type: 'chunk', content: fallbackMessage })}\n\n`);
        res.write(`data: ${JSON.stringify({ 
          type: 'done', 
          suggestedReplies: ["When is a good time to call?", "What are your operating hours?"],
          meta: { clientId: req.params.clientId, botId: req.params.botId, sessionId: req.body?.sessionId || `session_${Date.now()}`, rateLimited: true }
        })}\n\n`);
        res.end();
        return;
      }
      
      if (!res.headersSent) {
        res.status(500).json({ error: "Failed to process chat message" });
      } else {
        res.write(`data: ${JSON.stringify({ type: 'error', message: 'Stream interrupted' })}\n\n`);
        res.end();
      }
    }
  });

  // Human handoff endpoint - marks session for human review
  app.post("/api/chat/:clientId/:botId/handoff", widgetCors, async (req, res) => {
    try {
      const paramsValidation = validateRequest(clientBotParamsSchema, req.params);
      if (!paramsValidation.success) {
        return res.status(400).json({ error: paramsValidation.error });
      }
      const { clientId, botId } = paramsValidation.data;
      
      const { sessionId, messages, contactInfo, reason, language } = req.body;
      
      if (!sessionId) {
        return res.status(400).json({ error: "Session ID is required" });
      }

      // Get bot configuration
      const botConfig = await getBotConfigAsync(clientId, botId);
      if (!botConfig) {
        return res.status(404).json({ error: "Bot not found" });
      }

      // Log analytics event for handoff request
      await storage.logAnalyticsEvent({
        clientId,
        botId,
        sessionId,
        eventType: 'human_handoff',
        actor: 'user',
        messageContent: reason || 'User requested to speak with a person',
        metadata: { 
          language,
          contactInfo: contactInfo || null,
          messageCount: messages?.length || 0
        } as any,
      });

      // Update session state to flag for human review
      await storage.updateSessionState(sessionId, clientId, {
        status: 'needs_attention',
        priority: 'high'
      });

      // Generate conversation summary for quick handoff context
      const lastMessages = (messages || []).slice(-5).map((m: any) => 
        `${m.role === 'user' ? 'User' : 'Bot'}: ${m.content.slice(0, 100)}...`
      ).join('\n');

      // Add note to session for staff
      await storage.createConversationNote({
        sessionId,
        clientId,
        botId,
        content: `Human handoff requested\nReason: ${reason || 'User clicked "Talk to a person"'}\nContact: ${contactInfo?.email || contactInfo?.phone || 'Not provided'}\n\nRecent conversation:\n${lastMessages}`,
        authorId: 'system',
        authorName: 'System',
        isPinned: true
      });

      // Get business contact info to show user
      const businessPhone = botConfig.businessProfile?.phone || null;
      const businessEmail = botConfig.businessProfile?.email || null;

      // Generate a ticket ID for tracking
      const ticketId = `HO-${Date.now().toString(36).toUpperCase()}`;

      res.json({
        success: true,
        ticketId,
        message: language === 'es' 
          ? 'Su solicitud ha sido recibida. Nuestro equipo se pondrá en contacto pronto.'
          : 'Your request has been received. Our team will reach out to you soon.',
        businessContact: {
          phone: businessPhone,
          email: businessEmail
        }
      });
    } catch (error) {
      structuredLogger.error("Human handoff error:", error);
      res.status(500).json({ error: "Failed to process handoff request" });
    }
  });
  
  // Helper function to categorize messages by topic for analytics
  function categorizeMessageTopic(content: string): string {
    const lower = content.toLowerCase();
    
    if (/pric|cost|fee|pay|afford|money|\$/i.test(lower)) return 'pricing';
    if (/hour|open|close|time|when|schedule/i.test(lower)) return 'hours';
    if (/locat|address|where|direct|find/i.test(lower)) return 'location';
    if (/service|offer|provide|do you|can you/i.test(lower)) return 'services';
    if (/appointment|book|reserve|schedule|meet/i.test(lower)) return 'appointments';
    if (/help|support|assist|question/i.test(lower)) return 'support';
    if (/contact|call|email|phone|reach/i.test(lower)) return 'contact';
    if (/thank|great|good|awesome/i.test(lower)) return 'feedback';
    
    return 'general';
  }

  // Helper function to extract contact info from messages for auto-lead capture
  interface ExtractedContactInfo {
    email: string | null;
    phone: string | null;
    name: string | null;
  }

  function extractContactInfo(messages: Array<{ role: string; content: string }>): ExtractedContactInfo {
    const result: ExtractedContactInfo = { email: null, phone: null, name: null };
    
    // Combine all user messages
    const userText = messages
      .filter(m => m.role === 'user')
      .map(m => m.content)
      .join(' ');
    
    // Email pattern
    const emailMatch = userText.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
    if (emailMatch) {
      result.email = emailMatch[0].toLowerCase();
    }
    
    // Phone pattern (various formats)
    const phoneMatch = userText.match(/(?:\+1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}/);
    if (phoneMatch) {
      // Clean up phone number
      result.phone = phoneMatch[0].replace(/[^\d+]/g, '');
    }
    
    // Try to extract name patterns like "my name is X", "I'm X", "I am X", "this is X"
    const namePatterns = [
      /(?:my name is|i'm|i am|this is|call me)\s+([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)?)/i,
      /^([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)?)\s+(?:here|speaking)/i,
    ];
    
    for (const pattern of namePatterns) {
      const nameMatch = userText.match(pattern);
      if (nameMatch && nameMatch[1]) {
        result.name = nameMatch[1].trim();
        break;
      }
    }
    
    return result;
  }

  // Auto-create or update lead from chat session with optional AI analysis
  async function autoCaptureLead(
    clientId: string,
    botId: string,
    sessionId: string,
    contactInfo: ExtractedContactInfo,
    conversationPreview: string,
    appointmentRequested: boolean,
    aiAnalysis?: ConversationAnalysis | null
  ): Promise<void> {
    try {
      // Use AI-derived booking intent if available, fallback to regex detection
      const hasBookingIntent = aiAnalysis?.bookingIntent || appointmentRequested;
      
      // CRITICAL: Only create leads when we have actual contact info (email or phone)
      // Booking intent alone is not sufficient - we need a way to contact the lead
      if (!contactInfo.email && !contactInfo.phone) {
        return; // No contact info to create lead - booking intent tracked in session
      }
      
      // Check if lead already exists for this session or email/phone
      // SECURITY: Always scope by clientId to prevent cross-tenant data access
      const existingLeads = await storage.getLeads(clientId, { limit: 100 });
      
      // Look for existing lead by session, email, or phone - ONLY within this client's leads
      const existingLead = existingLeads.leads.find(lead => 
        // SECURITY: Double-check clientId matches to enforce tenant isolation
        lead.clientId === clientId && (
          lead.sessionId === sessionId ||
          (contactInfo.email && lead.email === contactInfo.email) ||
          (contactInfo.phone && lead.phone === contactInfo.phone)
        )
      );
      
      // Determine priority from AI analysis or booking intent
      const determinePriority = (): string => {
        if (aiAnalysis?.leadQuality === 'hot') return 'high';
        if (aiAnalysis?.leadQuality === 'warm') return 'medium';
        if (hasBookingIntent) return 'high';
        return 'medium';
      };
      
      // Build metadata with AI insights
      const leadMetadata: Record<string, any> = {};
      if (aiAnalysis) {
        if (aiAnalysis.userIntent) leadMetadata.userIntent = aiAnalysis.userIntent;
        if (aiAnalysis.summary) leadMetadata.aiSummary = aiAnalysis.summary;
        if (aiAnalysis.leadQuality) leadMetadata.leadQuality = aiAnalysis.leadQuality;
        if (aiAnalysis.sentiment) leadMetadata.sentiment = aiAnalysis.sentiment;
      }
      
      if (existingLead) {
        // SECURITY: Verify lead belongs to this client before updating
        if (existingLead.clientId !== clientId) {
          structuredLogger.error(`[Auto-Lead] Security: Attempted to update lead ${existingLead.id} belonging to different client`);
          return;
        }
        
        // Update existing lead with new info
        const updates: Partial<typeof existingLead> = {
          sessionId, // Link to latest session
          conversationPreview: aiAnalysis?.summary || conversationPreview,
        };
        
        if (contactInfo.name && !existingLead.name) updates.name = contactInfo.name;
        if (contactInfo.email && !existingLead.email) updates.email = contactInfo.email;
        if (contactInfo.phone && !existingLead.phone) updates.phone = contactInfo.phone;
        
        // Update priority based on AI analysis or booking intent
        const newPriority = determinePriority();
        if (newPriority === 'high' && existingLead.priority !== 'high') {
          updates.priority = 'high';
        }
        
        // Merge AI metadata
        if (Object.keys(leadMetadata).length > 0) {
          updates.metadata = { ...(existingLead.metadata || {}), ...leadMetadata };
        }
        
        await storage.updateLead(clientId, existingLead.id, updates);
        structuredLogger.info(`[Auto-Lead] Updated existing lead ${existingLead.id} for session ${sessionId}`);
      } else {
        // Build tags array
        const tags: string[] = [];
        if (hasBookingIntent) tags.push('appointment_request');
        if (aiAnalysis?.leadQuality === 'hot') tags.push('hot_lead');
        
        // Create new lead - always use the provided clientId/botId
        const newLead = await storage.createLead({
          clientId,
          botId,
          sessionId,
          name: contactInfo.name,
          email: contactInfo.email,
          phone: contactInfo.phone,
          source: 'chat',
          status: 'new',
          priority: determinePriority(),
          notes: null,
          tags,
          metadata: Object.keys(leadMetadata).length > 0 ? leadMetadata : {},
          conversationPreview: aiAnalysis?.summary || conversationPreview,
          messageCount: null,
          lastContactedAt: null,
        });
        
        structuredLogger.info(`[Auto-Lead] Created new lead ${newLead.id} for session ${sessionId} (quality: ${aiAnalysis?.leadQuality || 'unknown'})`);
        
        // Increment lead counter
        await incrementLeadCount(clientId);
        
        // Fire webhook for new lead (async, non-blocking)
        sendLeadCreatedWebhook(clientId, {
          id: newLead.id,
          name: newLead.name || 'Unknown',
          email: newLead.email,
          phone: newLead.phone,
          source: newLead.source,
          status: newLead.status,
          createdAt: newLead.createdAt,
        }).catch(err => structuredLogger.error('[Webhook] Error sending lead webhook:', err));
      }
    } catch (error) {
      // Don't fail the chat request if lead capture fails
      structuredLogger.error('[Auto-Lead] Error capturing lead:', error);
    }
  }

  // =============================================
  // DEMO BOT ENDPOINTS
  // =============================================

  // Get all demo bots - fetches from database workspaces with is_demo=true
  app.get("/api/demos", async (req, res) => {
    try {
      // Fetch demo workspaces from database
      const demoWorkspaces = await db.select().from(workspaces).where(eq(workspaces.isDemo, true));
      
      // For each demo workspace, get its primary bot
      const demoBotPromises = demoWorkspaces.map(async (workspace) => {
        const [primaryBot] = await db.select().from(bots).where(eq(bots.workspaceId, workspace.id)).limit(1);
        if (!primaryBot) return null;
        
        // Get bot settings for additional info
        const [settings] = await db.select().from(botSettings).where(eq(botSettings.botId, primaryBot.botId)).limit(1);
        
        // Map demo routes based on workspace slug
        const demoRouteMap: Record<string, string> = {
          'faith_house_demo': '/demo/faith-house',
          'demo_paws_suds_grooming_demo': '/demo/paws-suds',
          'demo_coastline_auto': '/demo/auto-care',
          'demo_fade_factory': '/demo/barbershop',
          'demo_iron_coast_fitness': '/demo/fitness',
          'demo_tc_handyman': '/demo/handyman',
          'demo_radiance_medspa': '/demo/med-spa',
          'demo_premier_properties': '/demo/real-estate',
          'demo_coastal_breeze': '/demo/restaurant',
          'demo_ink_soul': '/demo/tattoo',
          'demo_new_horizons': '/demo/recovery-house',
        };
        let demoRoute = demoRouteMap[workspace.slug] || `/demo/${primaryBot.botId}`;
        
        return {
          botId: primaryBot.botId,
          clientId: workspace.slug,
          workspaceId: workspace.id,
          name: primaryBot.name,
          description: primaryBot.description || `AI Assistant for ${workspace.name}`,
          businessType: primaryBot.botType || 'general',
          businessName: workspace.name,
          isDemo: true,
          demoRoute,
        };
      });
      
      const botResults = await Promise.all(demoBotPromises);
      const botList = botResults.filter(Boolean);
      
      res.json({ bots: botList });
    } catch (error) {
      structuredLogger.error("Get demos error:", error);
      res.status(500).json({ error: "Failed to fetch demo bots" });
    }
  });

  // =============================================
  // DEMO PRE-FLIGHT CHECK (Super Admin Only)
  // One-click validation before demos
  // IMPORTANT: Must be before /api/demo/:botIdOrSlug to avoid route conflict
  // =============================================
  
  app.get("/api/demo/preflight", requireSuperAdmin, async (req, res) => {
    try {
      const checks: Record<string, { pass: boolean; message: string; details?: any }> = {};
      
      // 1. Health Check (DB + AI)
      try {
        const dbCheck = await storage.healthCheck?.() ?? { status: 'ok', latencyMs: 0 };
        const openaiKey = process.env.OPENAI_API_KEY || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
        const aiConfigured = !!(openaiKey && openaiKey.length > 10);
        
        checks.health = {
          pass: dbCheck.status === 'ok' && aiConfigured,
          message: dbCheck.status === 'ok' && aiConfigured ? "DB and AI healthy" : 
            (!aiConfigured ? "AI not configured" : "Database unhealthy"),
          details: { dbLatencyMs: dbCheck.latencyMs, aiConfigured }
        };
      } catch {
        checks.health = { pass: false, message: "Health check failed" };
      }
      
      // 2. Demo Workspaces Available
      try {
        const demoSlugs = getDemoSlugs();
        const demoBotsFound: string[] = [];
        for (const slug of demoSlugs) {
          const workspace = await getWorkspaceBySlug(slug);
          if (workspace) {
            demoBotsFound.push(slug);
          }
        }
        checks.demoWorkspaces = {
          pass: demoBotsFound.length > 0,
          message: demoBotsFound.length > 0 
            ? `${demoBotsFound.length} demo workspace(s) available` 
            : "No demo workspaces found",
          details: { available: demoBotsFound, expected: demoSlugs }
        };
      } catch {
        checks.demoWorkspaces = { pass: false, message: "Demo workspace check failed" };
      }
      
      // 3. Sample Chat Test (dry run)
      try {
        const demoSlugs = getDemoSlugs();
        if (demoSlugs.length > 0) {
          const testSlug = demoSlugs[0];
          const workspace = await getWorkspaceBySlug(testSlug);
          if (workspace) {
            const botConfigs = await getBotsByWorkspaceId(workspace.id);
            checks.sampleChatReady = {
              pass: botConfigs.length > 0,
              message: botConfigs.length > 0 
                ? `Demo bot "${botConfigs[0].name}" ready for chat` 
                : "No demo bots configured",
              details: { workspace: testSlug, botCount: botConfigs.length }
            };
          } else {
            checks.sampleChatReady = { pass: false, message: "Primary demo workspace missing" };
          }
        } else {
          checks.sampleChatReady = { pass: false, message: "No demo slugs configured" };
        }
      } catch {
        checks.sampleChatReady = { pass: false, message: "Sample chat check failed" };
      }
      
      // 4. Recent Errors Check
      try {
        const errorCount = await storage.getRecentErrorCount?.(15) ?? 0;
        checks.recentErrors = {
          pass: errorCount < 10,
          message: errorCount < 10 
            ? `${errorCount} errors in last 15 min (acceptable)` 
            : `${errorCount} errors in last 15 min (high)`,
          details: { count: errorCount }
        };
      } catch {
        checks.recentErrors = { pass: true, message: "Error count unavailable (assuming OK)" };
      }
      
      // Calculate overall status
      const allPassing = Object.values(checks).every(c => c.pass);
      const passingCount = Object.values(checks).filter(c => c.pass).length;
      const totalChecks = Object.keys(checks).length;
      
      res.json({
        ready: allPassing,
        summary: allPassing ? "All pre-flight checks passed" : `${passingCount}/${totalChecks} checks passing`,
        checks,
        recommendation: allPassing 
          ? "Demo environment is ready for presentations" 
          : "Please resolve failing checks before demo",
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      structuredLogger.error("Demo preflight error:", error);
      res.status(500).json({ error: "Failed to run preflight checks" });
    }
  });

  // Get specific bot config for demo UI
  // Accepts either botId directly OR workspace slug (will look up primary bot)
  app.get("/api/demo/:botIdOrSlug", async (req, res) => {
    try {
      const { botIdOrSlug } = req.params;
      
      // First try direct botId lookup
      let botConfig = await getBotConfigByBotIdAsync(botIdOrSlug);
      
      // If not found, try looking up by workspace slug and getting primary bot
      if (!botConfig) {
        const workspace = await db.select().from(workspaces).where(eq(workspaces.slug, botIdOrSlug)).limit(1);
        if (workspace.length > 0) {
          const [primaryBot] = await db.select().from(bots).where(eq(bots.workspaceId, workspace[0].id)).limit(1);
          if (primaryBot) {
            botConfig = await getBotConfigByBotIdAsync(primaryBot.botId);
          }
        }
      }
      
      if (!botConfig) {
        return res.status(404).json({ error: `Bot not found: ${botIdOrSlug}` });
      }
      
      // Return config without sensitive system prompt details
      // Ensure businessProfile includes the type from botType
      const businessProfile = {
        ...botConfig.businessProfile,
        type: botConfig.botType || botConfig.businessProfile?.type || 'general'
      };
      
      res.json({
        botId: botConfig.botId,
        clientId: botConfig.clientId,
        name: botConfig.name,
        description: botConfig.description,
        businessProfile,
        faqs: botConfig.faqs,
        isDemo: botConfig.metadata?.isDemo ?? (botConfig.clientId === 'demo')
      });
    } catch (error) {
      structuredLogger.error("Get demo bot error:", error);
      res.status(500).json({ error: "Failed to fetch demo bot" });
    }
  });

  // Get all clients and their bots (for admin panel)
  app.get("/api/platform/clients", (req, res) => {
    try {
      const clientsData = getClients();
      const allBots = getAllBotConfigs();
      
      const clientsWithBots = clientsData.clients.map(client => ({
        ...client,
        bots: allBots
          .filter(bot => bot.clientId === client.id)
          .map(bot => ({
            botId: bot.botId,
            name: bot.name,
            description: bot.description,
            businessType: bot.businessProfile.type,
            isDemo: bot.metadata?.isDemo ?? false
          }))
      }));
      
      res.json({ clients: clientsWithBots });
    } catch (error) {
      structuredLogger.error("Get platform clients error:", error);
      res.status(500).json({ error: "Failed to fetch clients" });
    }
  });

  // Get bot config (pretty-printed for admin view)
  app.get("/api/platform/bots/:clientId/:botId", (req, res) => {
    try {
      const { clientId, botId } = req.params;
      
      const botConfig = getBotConfig(clientId, botId);
      
      if (!botConfig) {
        return res.status(404).json({ error: `Bot not found: ${clientId}/${botId}` });
      }
      
      res.json(botConfig);
    } catch (error) {
      structuredLogger.error("Get bot config error:", error);
      res.status(500).json({ error: "Failed to fetch bot config" });
    }
  });

  // Get conversation logs for a client
  app.get("/api/platform/logs/:clientId", requireAuth, (req, res) => {
    try {
      const { clientId } = req.params;
      const { botId, date } = req.query;
      
      const logs = getConversationLogs(clientId, botId as string, date as string);
      const stats = getLogStats(clientId);
      
      res.json({ logs, stats });
    } catch (error) {
      structuredLogger.error("Get logs error:", error);
      res.status(500).json({ error: "Failed to fetch logs" });
    }
  });

  app.post("/api/appointment", async (req, res) => {
    try {
      const { sessionId, conversationHistory, clientId: bodyClientId, ...appointmentData } = req.body;
      const validatedData = insertAppointmentSchema.parse(appointmentData);
      
      // clientId is required for tenant isolation
      if (!bodyClientId) {
        return res.status(400).json({ error: "Client ID required" });
      }
      const effectiveClientId = bodyClientId;
      
      let conversationSummary = "No conversation history available.";
      
      // First try to get summary from logged analytics (actual chat messages)
      if (sessionId) {
        conversationSummary = await generateConversationSummary(sessionId, effectiveClientId);
      }
      
      // If no analytics found, try to generate summary from frontend conversation history
      if (conversationSummary === "No conversation history available." && 
          conversationHistory && Array.isArray(conversationHistory) && conversationHistory.length > 0 && openai) {
        try {
          const conversationText = conversationHistory
            .map((msg: { role: string; content: string }) => `${msg.role}: ${sanitizePII(msg.content)}`)
            .join("\n");
          
          const completion = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            messages: [
              {
                role: "system",
                content: "You are a helpful assistant that summarizes conversations between users and the HopeLine Assistant chatbot for a sober-living facility. Create a brief, professional summary (3-4 sentences) focusing on: their general situation, what they're seeking, their urgency level, and relevant context. DO NOT include specific personal details like names, phone numbers, or addresses in the summary."
              },
              {
                role: "user",
                content: `Summarize this conversation:\n\n${conversationText}`
              }
            ],
            max_completion_tokens: 200,
          });
          
          conversationSummary = completion.choices[0]?.message?.content || "Unable to generate summary.";
        } catch (error) {
          structuredLogger.error("Error generating summary from conversation history:", error);
        }
      }
      
      const appointment = await storage.createAppointment(effectiveClientId, {
        ...validatedData,
        conversationSummary
      } as any);
      
      // Trigger appointment_booked automations (async, non-blocking)
      const appointmentBotId = validatedData.botId || `${effectiveClientId}_assistant`;
      triggerWorkflowByEvent(appointmentBotId, 'appointment_booked', {
        clientId: effectiveClientId,
        appointmentId: appointment.id,
        name: appointment.name,
        phone: appointment.contact,
        appointmentType: appointment.appointmentType,
      }).catch(err => structuredLogger.error('[Automation] Error triggering appointment_booked:', err));
      
      const settings = await storage.getSettings(effectiveClientId);
      
      if (settings?.enableEmailNotifications && settings.notificationEmail) {
        const emailResult = await sendEmailNotification(
          settings.notificationEmail,
          appointment,
          conversationSummary,
          settings
        );
        if (!emailResult.success && emailResult.error !== "API key not configured") {
          structuredLogger.warn(`Email notification failed: ${emailResult.error}`);
        }
      } else if (settings) {
        structuredLogger.info("📧 Email notifications not enabled or no recipient configured");
      }
      
      if (settings?.enableSmsNotifications && settings.notificationPhone) {
        const appointmentTypeText = appointment.appointmentType === 'tour' 
          ? 'tour'
          : appointment.appointmentType === 'call'
          ? 'phone call'
          : 'family info call';
        
        const staffMessage = `New ${appointmentTypeText} request from ${appointment.name}. Contact: ${appointment.contact}. Preferred time: ${appointment.preferredTime}. Check admin dashboard for details.`;
        
        const smsResult = await sendSmsNotification(
          settings.notificationPhone,
          staffMessage,
          false
        );
        
        if (!smsResult.success && smsResult.error !== "Twilio not configured") {
          structuredLogger.warn(`SMS staff notification failed: ${smsResult.error}`);
        }
        
        if (appointment.contactPreference === 'text' && appointment.contact) {
          const clientMessage = `Thank you for your ${appointmentTypeText} request at ${settings.businessName}. We'll reach out to you soon at your preferred time: ${appointment.preferredTime}. If you need immediate assistance, please call us.`;
          
          const clientSmsResult = await sendSmsNotification(
            appointment.contact,
            clientMessage,
            true
          );
          
          if (!clientSmsResult.success && clientSmsResult.error !== "Twilio not configured") {
            structuredLogger.warn(`SMS client confirmation failed: ${clientSmsResult.error}`);
          }
        }
      }
      
      // Fire webhook for new appointment (async, non-blocking)
      sendAppointmentCreatedWebhook(effectiveClientId, {
        id: appointment.id as any,
        name: appointment.name,
        email: null, // appointment table doesn't have email column
        phone: appointment.contact,
        preferredDate: null,
        preferredTime: appointment.preferredTime,
        appointmentType: appointment.appointmentType,
        notes: appointment.notes,
        createdAt: appointment.createdAt,
      }).catch(err => structuredLogger.error('[Webhook] Error sending appointment webhook:', err));
      
      res.json({ success: true, appointment });
    } catch (error) {
      structuredLogger.error("Appointment error:", error);
      res.status(400).json({ error: "Failed to create appointment" });
    }
  });

  app.get("/api/appointments", requireClientAuth, async (req, res) => {
    try {
      const { status, startDate, endDate, search, limit, offset } = req.query;
      
      // SECURITY: Use effectiveClientId from middleware (session-based tenant isolation)
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      const filters: any = {};
      if (status) filters.status = status as string;
      if (startDate) filters.startDate = new Date(startDate as string);
      if (endDate) filters.endDate = new Date(endDate as string);
      if (search) filters.search = search as string;
      if (limit) filters.limit = parseInt(limit as string);
      if (offset) filters.offset = parseInt(offset as string);
      
      const result = await storage.getFilteredAppointments(clientId, filters);
      res.json(result);
    } catch (error) {
      structuredLogger.error("Get appointments error:", error);
      res.status(500).json({ error: "Failed to fetch appointments" });
    }
  });

  // =============================================
  // BOT REQUEST ENDPOINTS - Contact form submissions
  // =============================================

  // Submit a bot request from landing page (public endpoint)
  app.post("/api/bot-requests", async (req, res) => {
    try {
      const validatedData = insertBotRequestSchema.parse(req.body);
      
      // Honeypot check - if filled, it's a bot (real users don't see this field)
      if (validatedData.honeypot && validatedData.honeypot.trim() !== '') {
        structuredLogger.info(`[Bot Request] Honeypot triggered - rejecting bot submission from ${validatedData.email}`);
        // Return success to not tip off bots, but don't save
        return res.json({ success: true, message: "Request received! We'll be in touch within 24 hours." });
      }
      
      // Generate dedupe hash: email + phone + 'bot_request' + hour bucket
      // This prevents duplicate submissions within the same hour
      const hourBucket = Math.floor(Date.now() / 3600000); // Current hour as integer
      const dedupeInput = `${validatedData.email}${validatedData.phone || ''}bot_request${hourBucket}`;
      const dedupeHash = crypto.createHash('sha256').update(dedupeInput).digest('hex');
      
      try {
        const [newRequest] = await db.insert(botRequests).values({
          ...validatedData,
          source: "landing_page",
          dedupeHash,
          honeypot: undefined, // Don't store honeypot field
        }).returning();
        
        structuredLogger.info(`[Bot Request] New submission from ${validatedData.email}: ${validatedData.name}`);
      } catch (insertError: any) {
        // Check for unique constraint violation on dedupeHash (PostgreSQL error code 23505)
        if (insertError?.code === '23505' && insertError?.constraint?.includes('dedupe_hash')) {
          structuredLogger.info(`[Bot Request] Duplicate submission detected from ${validatedData.email} - returning success`);
          // Return success to user - they don't need to know it was a dupe
          return res.json({ success: true, message: "Request received! We'll be in touch within 24 hours." });
        }
        // Re-throw other errors
        throw insertError;
      }
      
      res.json({ success: true, message: "Request received! We'll be in touch within 24 hours." });
    } catch (error) {
      structuredLogger.error("Bot request submission error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid form data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to submit request" });
    }
  });

  // Get all bot requests (admin only)
  app.get("/api/bot-requests", requireSuperAdmin, async (req, res) => {
    try {
      const { status, limit = "50", offset = "0" } = req.query;
      
      let requests;
      
      if (status && status !== "all") {
        requests = await db.select().from(botRequests).where(eq(botRequests.status, status as string)).orderBy(sql`${botRequests.createdAt} DESC`).limit(parseInt(limit as string)).offset(parseInt(offset as string));
      } else {
        requests = await db.select().from(botRequests).orderBy(sql`${botRequests.createdAt} DESC`).limit(parseInt(limit as string)).offset(parseInt(offset as string));
      }
      
      // Get counts by status
      const counts = await db.select({
        status: botRequests.status,
        count: sql<number>`count(*)::int`,
      }).from(botRequests).groupBy(botRequests.status);
      
      const statusCounts = counts.reduce((acc, curr) => {
        acc[curr.status] = curr.count;
        return acc;
      }, {} as Record<string, number>);
      
      res.json({ 
        requests, 
        counts: statusCounts,
        total: Object.values(statusCounts).reduce((a, b) => a + b, 0)
      });
    } catch (error) {
      structuredLogger.error("Get bot requests error:", error);
      res.status(500).json({ error: "Failed to fetch requests" });
    }
  });

  // Validation schema for bot request updates
  const botRequestUpdateSchema = z.object({
    status: z.enum(["new", "contacted", "qualified", "converted", "declined"]).optional(),
    priority: z.enum(["low", "normal", "high", "urgent"]).optional(),
    adminNotes: z.string().max(10000, "Admin notes cannot exceed 10,000 characters").nullable().optional(),
    assignedTo: z.string().nullable().optional(),
  });

  // Update a bot request (admin only)
  app.patch("/api/bot-requests/:id", requireSuperAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      
      // Validate the update body
      const validationResult = botRequestUpdateSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.errors 
        });
      }
      
      const updates: Record<string, any> = { ...validationResult.data };
      
      // Handle status changes
      if (updates.status === "contacted" && !updates.contactedAt) {
        updates.contactedAt = new Date();
      }
      if (updates.status === "converted" && !updates.convertedAt) {
        updates.convertedAt = new Date();
      }
      updates.updatedAt = new Date();
      
      const [updated] = await db.update(botRequests)
        .set(updates)
        .where(eq(botRequests.id, id))
        .returning();
      
      if (!updated) {
        return res.status(404).json({ error: "Request not found" });
      }
      
      res.json({ success: true, request: updated });
    } catch (error) {
      structuredLogger.error("Update bot request error:", error);
      res.status(500).json({ error: "Failed to update request" });
    }
  });

  app.get("/api/appointments/:id", requireClientAuth, async (req, res) => {
    try {
      // SECURITY: Use effectiveClientId from middleware (session-based tenant isolation)
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      const appointment = await storage.getAppointmentById(clientId, req.params.id);
      if (!appointment) {
        return res.status(404).json({ error: "Appointment not found" });
      }
      res.json(appointment);
    } catch (error) {
      structuredLogger.error("Get appointment error:", error);
      res.status(500).json({ error: "Failed to fetch appointment" });
    }
  });

  app.patch("/api/appointments/:id", requireClientAuth, requireOperationalAccess, async (req, res) => {
    try {
      // Validate params
      const paramsValidation = validateRequest(idParamSchema, req.params);
      if (!paramsValidation.success) {
        return res.status(400).json({ error: paramsValidation.error });
      }
      
      // Validate body
      const bodyValidation = validateRequest(appointmentUpdateSchema, req.body);
      if (!bodyValidation.success) {
        return res.status(400).json({ error: bodyValidation.error });
      }
      
      const updates = bodyValidation.data;
      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ error: "No valid fields to update" });
      }
      
      // SECURITY: Use effectiveClientId from middleware (session-based tenant isolation)
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      const appointment = await storage.updateAppointment(clientId, paramsValidation.data.id, updates);
      res.json(appointment);
    } catch (error) {
      structuredLogger.error("Update appointment error:", error);
      res.status(500).json({ error: "Failed to update appointment" });
    }
  });

  app.patch("/api/appointments/:id/status", requireClientAuth, requireOperationalAccess, async (req, res) => {
    try {
      // Validate params and body
      const paramsValidation = validateRequest(idParamSchema, req.params);
      if (!paramsValidation.success) {
        return res.status(400).json({ error: paramsValidation.error });
      }
      
      const bodyValidation = validateRequest(appointmentStatusSchema, req.body);
      if (!bodyValidation.success) {
        return res.status(400).json({ error: bodyValidation.error });
      }
      
      // SECURITY: Use effectiveClientId from middleware (session-based tenant isolation)
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      await storage.updateAppointmentStatus(clientId, paramsValidation.data.id, bodyValidation.data.status);
      res.json({ success: true });
    } catch (error) {
      structuredLogger.error("Update appointment status error:", error);
      res.status(500).json({ error: "Failed to update status" });
    }
  });

  app.delete("/api/appointments/:id", requireClientAuth, requireAdminRole, async (req, res) => {
    try {
      const { id } = req.params;
      // SECURITY: Use effectiveClientId from middleware (session-based tenant isolation)
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      await storage.deleteAppointment(clientId, id);
      res.json({ success: true });
    } catch (error) {
      structuredLogger.error("Delete appointment error:", error);
      res.status(500).json({ error: "Failed to delete appointment" });
    }
  });

  app.get("/api/settings", requireClientAuth, async (req, res) => {
    try {
      // SECURITY: Use effectiveClientId from middleware (session-based tenant isolation)
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      const settings = await storage.getSettings(clientId);
      res.json(settings);
    } catch (error) {
      structuredLogger.error("Get settings error:", error);
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.patch("/api/settings", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      // SECURITY: Use effectiveClientId from middleware (session-based tenant isolation)
      // Ignore any clientId from request body - only use session-based client context
      const { clientId: _ignoredClientId, ...settingsData } = req.body;
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      const validatedData = insertClientSettingsSchema.partial().parse(settingsData);
      const settings = await storage.updateSettings(clientId, validatedData);
      res.json(settings);
    } catch (error) {
      structuredLogger.error("Update settings error:", error);
      res.status(400).json({ error: "Failed to update settings" });
    }
  });

  app.get("/api/analytics", requireClientAuth, async (req, res) => {
    try {
      // SECURITY: Use effectiveClientId from middleware (session-based tenant isolation)
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      const analytics = await storage.getAnalytics(clientId);
      res.json(analytics);
    } catch (error) {
      structuredLogger.error("Get analytics error:", error);
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  app.get("/api/analytics/summary", requireClientAuth, async (req, res) => {
    try {
      // Validate query params (only date range, clientId comes from session)
      const queryValidation = validateRequest(analyticsDateRangeQuerySchema, req.query);
      if (!queryValidation.success) {
        return res.status(400).json({ error: queryValidation.error });
      }
      
      // SECURITY: Use effectiveClientId from middleware (session-based tenant isolation)
      // Ignore any clientId from query params
      const { startDate, endDate } = queryValidation.data;
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      const start = startDate ? new Date(startDate) : undefined;
      const end = endDate ? new Date(endDate) : undefined;
      
      const summary = await storage.getAnalyticsSummary(clientId, start, end);
      res.json(summary);
    } catch (error) {
      structuredLogger.error("Get analytics summary error:", error);
      res.status(500).json({ error: "Failed to fetch analytics summary" });
    }
  });

  // CSV Export endpoint for analytics
  app.get("/api/analytics/export", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const queryValidation = validateRequest(analyticsDateRangeQuerySchema, req.query);
      if (!queryValidation.success) {
        return res.status(400).json({ error: queryValidation.error });
      }

      // Only allow date range from query; tenant scope comes from the session.
      const { startDate, endDate } = queryValidation.data;

      // SECURITY: Use effectiveClientId from middleware (session-based tenant isolation)
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }

      const start = startDate ? new Date(startDate) : undefined;
      const end = endDate ? new Date(endDate) : undefined;

      const summary = await storage.getAnalyticsSummary(clientId, start, end);

      // Build CSV content
      const headers = ["Date", "Conversations", "Appointments"];
      const rows = summary.dailyActivity.map((day) => [
        day.date,
        day.conversations.toString(),
        day.appointments.toString(),
      ]);

      const csvContent = [headers.join(","), ...rows.map((row) => row.join(","))].join("\n");

      // Add summary row
      const summaryRow =
        `\n\nSummary` +
        `\nTotal Conversations,${summary.totalConversations}` +
        `\nTotal Appointments,${summary.totalAppointments}` +
        `\nConversion Rate,${summary.conversionRate.toFixed(1)}%` +
        `\nCrisis Redirects,${summary.crisisRedirects}`;

      // Keep filename safe (even though dates are validated)
      const safe = (s: string) => s.replace(/[^a-zA-Z0-9._-]/g, "_");
      const fileName = safe(`analytics_${startDate || "all"}_to_${endDate || "now"}.csv`);

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
      res.send(csvContent + summaryRow);
    } catch (error) {
      structuredLogger.error("Export analytics error:", error);
      res.status(500).json({ error: "Failed to export analytics" });
    }
  });

  // Get notification service health status
  app.get("/api/notification-status", requireAdminRole, async (req, res) => {
    try {
      const clientId = req.session.clientId;
      const settings = clientId ? await storage.getSettings(clientId) : null;
      
      const resendConfigured = !!getResendApiKey();
      const twilioConfigured = !!getTwilioConfig();
      
      const emailRecipientsConfigured = !!(settings?.notificationEmail || 
        (settings?.notificationSettings?.staffEmails && settings.notificationSettings.staffEmails.length > 0));
      const smsRecipientsConfigured = !!(settings?.notificationPhone ||
        (settings?.notificationSettings?.staffPhones && settings.notificationSettings.staffPhones.length > 0));
      
      res.json({
        email: {
          serviceConfigured: resendConfigured,
          recipientsConfigured: emailRecipientsConfigured,
          enabled: settings?.enableEmailNotifications ?? false,
          ready: resendConfigured && emailRecipientsConfigured && (settings?.enableEmailNotifications ?? false),
        },
        sms: {
          serviceConfigured: twilioConfigured,
          recipientsConfigured: smsRecipientsConfigured,
          enabled: settings?.enableSmsNotifications ?? false,
          ready: twilioConfigured && smsRecipientsConfigured && (settings?.enableSmsNotifications ?? false),
        },
      });
    } catch (error) {
      structuredLogger.error("Notification status error:", error);
      res.status(500).json({ error: "Failed to get notification status" });
    }
  });

  app.post("/api/test-notification", requireAdminRole, async (req, res) => {
    try {
      const { clientId: bodyClientId, type = 'email' } = req.body;
      const clientId = bodyClientId || req.session.clientId;
      
      if (!clientId) {
        return res.status(400).json({ error: "Client ID required" });
      }
      
      const settings = await storage.getSettings(clientId);
      
      if (!settings) {
        return res.status(400).json({ error: "Settings not found" });
      }

      const testAppointment = {
        name: "Test User",
        contact: "test@example.com",
        preferredTime: new Date().toLocaleDateString(),
        appointmentType: "tour",
        notes: "This is a test notification",
        lookingFor: "self",
        sobrietyStatus: "30+ days sober",
        hasSupport: "Yes, family support",
        timeline: "Immediately"
      };

      const testSummary = "This is a test notification to verify your notification configuration is working correctly.";

      if (type === 'email') {
        if (!settings.notificationEmail) {
          return res.status(400).json({ 
            error: "No recipient email configured" 
          });
        }
        
        const emailResult = await sendEmailNotification(
          settings.notificationEmail,
          testAppointment,
          testSummary,
          settings
        );
        
        // Log the notification attempt
        await logNotification({
          clientId,
          type: 'email',
          recipient: settings.notificationEmail,
          status: emailResult.success ? 'sent' : 'failed',
          errorMessage: emailResult.error,
          metadata: { isTest: true, subject: `Test notification` },
        });
        
        if (emailResult.success) {
          return res.json({ 
            success: true, 
            message: `Test email sent successfully to ${settings.notificationEmail}` 
          });
        } else {
          return res.status(400).json({ 
            error: `Email failed: ${emailResult.error}` 
          });
        }
      } else if (type === 'sms') {
        if (!settings.notificationPhone) {
          return res.status(400).json({ 
            error: "No recipient phone configured" 
          });
        }
        
        const smsMessage = `[Test] New appointment request from Test User - ${new Date().toLocaleDateString()}`;
        const smsResult = await sendSmsNotification(settings.notificationPhone, smsMessage);
        
        // Log the notification attempt
        await logNotification({
          clientId,
          type: 'sms',
          recipient: settings.notificationPhone,
          status: smsResult.success ? 'sent' : 'failed',
          errorMessage: smsResult.error,
          metadata: { isTest: true },
        });
        
        if (smsResult.success) {
          return res.json({ 
            success: true, 
            message: `Test SMS sent successfully to ${settings.notificationPhone}` 
          });
        } else {
          return res.status(400).json({ 
            error: `SMS failed: ${smsResult.error}` 
          });
        }
      } else {
        return res.status(400).json({ error: "Invalid notification type" });
      }
    } catch (error) {
      structuredLogger.error("Test notification error:", error);
      res.status(500).json({ error: "Failed to send test notification" });
    }
  });
  
  // Get notification logs for a client
  app.get("/api/notification-logs", requireAdminRole, async (req, res) => {
    try {
      const clientId = req.session.clientId;
      if (!clientId) {
        return res.status(400).json({ error: "Client ID required" });
      }
      
      const { type, status, limit, offset } = req.query;
      
      const result = await storage.getNotificationLogs(clientId, {
        type: type as string | undefined,
        status: status as string | undefined,
        limit: limit ? parseInt(limit as string) : 20,
        offset: offset ? parseInt(offset as string) : 0,
      });
      
      res.json(result);
    } catch (error) {
      structuredLogger.error("Get notification logs error:", error);
      res.status(500).json({ error: "Failed to get notification logs" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      const { username, password } = validatedData;

      // Check if account is locked due to failed attempts
      const lockStatus = isAccountLocked(username);
      if (lockStatus.locked) {
        return res.status(429).json({ 
          error: `Too many login attempts. Please try again in ${lockStatus.remainingMinutes} minute(s).` 
        });
      }

      const user = await storage.findAdminByUsername(username);
      
      if (!user) {
        // Record failed attempt even for non-existent users (timing-safe)
        recordFailedLogin(username);
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Check if user is disabled
      if (user.disabled) {
        return res.status(401).json({ error: "Account disabled. Contact support." });
      }

      const isValid = await bcrypt.compare(password, user.passwordHash);
      
      if (!isValid) {
        // Record failed attempt
        const result = recordFailedLogin(username);
        
        // Audit log failed login
        const { ipAddress, userAgent } = extractRequestInfo(req);
        await logAuditEvent({
          userId: user.id,
          username: user.username,
          userRole: user.role,
          action: 'login_failed',
          resourceType: 'session',
          clientId: user.clientId || undefined,
          details: { reason: 'invalid_password', attemptsRemaining: result.locked ? 0 : undefined },
          ipAddress,
          userAgent,
        });
        
        if (result.locked) {
          return res.status(429).json({ 
            error: `Too many login attempts. Account locked for ${LOGIN_LOCKOUT_MINUTES} minutes.` 
          });
        }
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Successful login - clear any failed attempts
      clearFailedLogins(username);

      // Audit log successful login
      const loginReqInfo = extractRequestInfo(req);
      await logAuditEvent({
        userId: user.id,
        username: user.username,
        userRole: user.role,
        action: 'login',
        resourceType: 'session',
        clientId: user.clientId || undefined,
        details: { method: 'password' },
        ipAddress: loginReqInfo.ipAddress,
        userAgent: loginReqInfo.userAgent,
      });

      // Update lastLoginAt
      await db
        .update(adminUsers)
        .set({ lastLoginAt: new Date() })
        .where(eq(adminUsers.id, user.id));

      req.session.regenerate((err) => {
        if (err) {
          structuredLogger.error("Session regeneration error:", err);
          return res.status(500).json({ error: "Session creation failed" });
        }
        req.session.userId = user.id;
        req.session.userRole = (user.role as AdminRole) || "client_admin";
        req.session.clientId = user.clientId || null;
        req.session.lastSeenAt = Date.now(); // Initialize idle timeout tracking
        req.session.save((saveErr) => {
          if (saveErr) {
            structuredLogger.error("Session save error:", saveErr);
            return res.status(500).json({ error: "Session save failed" });
          }
          res.json({ 
            success: true, 
            forcePasswordChange: user.mustChangePassword ?? false,
            user: { 
              id: user.id, 
              username: user.username, 
              role: user.role, 
              clientId: user.clientId,
              mustChangePassword: user.mustChangePassword ?? false
            } 
          });
        });
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid username or password format" });
      }
      structuredLogger.error("Login error:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });

  // Change password endpoint - for forced password change flow
  const changePasswordSchema = z.object({
    newPassword: z.string().min(8, "Password must be at least 8 characters")
      .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
      .regex(/[a-z]/, "Password must contain at least one lowercase letter")
      .regex(/[0-9]/, "Password must contain at least one number"),
    confirmPassword: z.string(),
  }).refine(data => data.newPassword === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

  app.post("/api/auth/change-password", async (req, res) => {
    try {
      // Check if user is logged in
      if (!req.session.userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const validatedData = changePasswordSchema.parse(req.body);
      
      // Get current user
      const [user] = await db
        .select()
        .from(adminUsers)
        .where(eq(adminUsers.id, req.session.userId))
        .limit(1);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Hash new password
      const passwordHash = await bcrypt.hash(validatedData.newPassword, 10);

      // Update password and clear mustChangePassword flag
      await db
        .update(adminUsers)
        .set({
          passwordHash,
          mustChangePassword: false,
          lastLoginAt: new Date(),
        })
        .where(eq(adminUsers.id, user.id));

      // Audit log password change
      const pwdChangeReqInfo = extractRequestInfo(req);
      await logAuditEvent({
        userId: user.id,
        username: user.username,
        userRole: user.role,
        action: 'password_change',
        resourceType: 'user',
        resourceId: user.id,
        clientId: user.clientId || undefined,
        details: { forced: user.mustChangePassword },
        ipAddress: pwdChangeReqInfo.ipAddress,
        userAgent: pwdChangeReqInfo.userAgent,
      });

      // Session invalidation: destroy all other sessions for this user
      // The session table stores sess as JSON with userId inside
      const currentSessionId = req.sessionID;
      try {
        await db.execute(sql`
          DELETE FROM session 
          WHERE sid != ${currentSessionId} 
          AND (sess::json->>'userId')::int = ${user.id}
        `);
        structuredLogger.info(`Invalidated other sessions for user ${user.id} after password change`);
      } catch (sessionErr) {
        // Don't fail the password change if session cleanup fails
        structuredLogger.warn("Failed to invalidate other sessions:", sessionErr);
      }

      // Regenerate current session for security
      req.session.regenerate((regenErr) => {
        if (regenErr) {
          structuredLogger.warn("Session regeneration failed:", regenErr);
        }
        // Restore session data after regeneration
        req.session.userId = user.id;
        req.session.username = user.username;
        req.session.userRole = user.role as typeof req.session.userRole;
        req.session.clientId = user.clientId || null;
        req.session.lastSeenAt = Date.now(); // Reset idle timeout tracking
        
        req.session.save((saveErr) => {
          if (saveErr) {
            structuredLogger.warn("Session save after regeneration failed:", saveErr);
          }
          res.json({ 
            success: true, 
            message: "Password changed successfully",
            redirect: user.role === 'super_admin' ? '/super-admin' : '/client/dashboard'
          });
        });
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const firstError = error.errors[0];
        return res.status(400).json({ error: firstError.message });
      }
      structuredLogger.error("Change password error:", error);
      res.status(500).json({ error: "Failed to change password" });
    }
  });

  // Signup endpoint - Create new workspace and user
  const signupSchema = z.object({
    fullName: z.string().min(1, "Full name is required"),
    email: z.string().email("Invalid email address"),
    password: z.string().min(8, "Password must be at least 8 characters"),
    businessName: z.string().min(1, "Business name is required"),
    phone: z.string().optional(),
  });

  app.post("/api/auth/signup", async (req, res) => {
    try {
      const validatedData = signupSchema.parse(req.body);
      const { fullName, email, password, businessName, phone } = validatedData;

      // Check if email already exists (as username)
      const existingUser = await storage.findAdminByUsername(email);
      if (existingUser) {
        return res.status(400).json({ error: "This email is already registered" });
      }

      // Generate workspace slug from business name
      const baseSlug = businessName
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_|_$/g, '')
        .substring(0, 50);
      
      // Ensure unique slug by appending random suffix
      const uniqueSlug = `${baseSlug}_${Date.now().toString(36)}`;

      // Hash password
      const passwordHash = await bcrypt.hash(password, 10);

      // Create the user first
      const [newUser] = await db.insert(adminUsers).values({
        username: email,
        passwordHash,
        role: "client_admin",
        clientId: uniqueSlug, // Use workspace slug as clientId
      }).returning();

      // Create workspace
      const [newWorkspace] = await db.insert(workspaces).values({
        name: businessName,
        slug: uniqueSlug,
        ownerId: newUser.id,
        plan: "free",
        status: "active",
        settings: {
          brandColor: "#06b6d4",
          logoUrl: undefined,
          timezone: "America/New_York",
        } as any,
      }).returning();

      // Create workspace membership
      await db.insert(workspaceMemberships).values({
        workspaceId: newWorkspace.id,
        userId: newUser.id,
        role: "owner",
        status: "active",
        acceptedAt: new Date(),
      });

      // Create default bot for the workspace
      const defaultBotId = `${uniqueSlug}_bot`;
      await db.insert(bots).values({
        botId: defaultBotId,
        workspaceId: newWorkspace.id,
        name: `${businessName} Assistant`,
        botType: "generic",
        businessProfile: {
          businessName: businessName,
          type: "generic",
          location: "",
          phone: phone || "",
          email: email,
          website: "",
          hours: {},
        },
        systemPrompt: `You are a helpful AI assistant for ${businessName}. Be friendly, professional, and help visitors with their questions.`,
        theme: {
          primaryColor: "#06b6d4",
          welcomeMessage: `Welcome to ${businessName}! How can I help you today?`,
        },
        status: "active",
      });

      // Create default bot settings
      await db.insert(botSettings).values({
        botId: defaultBotId,
        faqs: [],
        rules: {},
        automations: {},
      });

      // Create client settings for the new workspace
      await db.insert(clientSettings).values({
        clientId: uniqueSlug,
        businessName: businessName,
        tagline: "Welcome to our business",
        primaryEmail: email,
        primaryPhone: phone || null,
        status: "active",
        knowledgeBase: {
          about: `Welcome to ${businessName}.`,
          requirements: "",
          pricing: "",
          application: "",
        },
        operatingHours: {
          enabled: false,
          timezone: "America/New_York",
          schedule: {
            monday: { open: "09:00", close: "17:00", enabled: true },
            tuesday: { open: "09:00", close: "17:00", enabled: true },
            wednesday: { open: "09:00", close: "17:00", enabled: true },
            thursday: { open: "09:00", close: "17:00", enabled: true },
            friday: { open: "09:00", close: "17:00", enabled: true },
            saturday: { open: "09:00", close: "17:00", enabled: false },
            sunday: { open: "09:00", close: "17:00", enabled: false },
          },
          afterHoursMessage: "We're currently closed. Please leave a message and we'll get back to you.",
        },
      });

      // Auto-login the new user
      req.session.regenerate((err) => {
        if (err) {
          structuredLogger.error("Session regeneration error:", err);
          return res.status(500).json({ error: "Account created but session failed. Please log in." });
        }
        req.session.userId = newUser.id;
        req.session.userRole = "client_admin";
        req.session.clientId = uniqueSlug;
        req.session.lastSeenAt = Date.now(); // Initialize idle timeout tracking
        req.session.save((saveErr) => {
          if (saveErr) {
            structuredLogger.error("Session save error:", saveErr);
            return res.status(500).json({ error: "Account created but session failed. Please log in." });
          }
          res.status(201).json({
            success: true,
            user: {
              id: newUser.id,
              username: newUser.username,
              role: newUser.role,
              clientId: uniqueSlug,
            },
            workspace: {
              id: newWorkspace.id,
              name: newWorkspace.name,
              slug: newWorkspace.slug,
            },
          });
        });
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const firstError = error.errors[0];
        return res.status(400).json({ error: firstError.message });
      }
      structuredLogger.error("Signup error:", error);
      res.status(500).json({ error: "Failed to create account. Please try again." });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.json({ success: true });
    });
  });

  app.get("/api/auth/check", (req, res) => {
    if (req.session.userId) {
      res.json({ authenticated: true });
    } else {
      res.json({ authenticated: false });
    }
  });

  app.get("/api/auth/me", requireAuth, async (req, res) => {
    try {
      const user = await db.select({
        id: adminUsers.id,
        username: adminUsers.username,
        role: adminUsers.role,
        clientId: adminUsers.clientId,
        mustChangePassword: adminUsers.mustChangePassword,
      }).from(adminUsers).where(eq(adminUsers.id, req.session.userId!)).limit(1);
      
      if (!user[0]) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Include impersonation state for super admins
      const isImpersonating = !!req.session.isImpersonating && !!req.session.effectiveClientId;
      const effectiveClientId = req.session.effectiveClientId || null;
      
      // Get workspace name if impersonating
      let impersonatedClientName: string | null = null;
      if (isImpersonating && effectiveClientId) {
        try {
          const workspace = await storage.getWorkspaceByClientId(effectiveClientId);
          impersonatedClientName = workspace?.name || effectiveClientId;
        } catch (e) {
          impersonatedClientName = effectiveClientId;
        }
      }
      
      res.json({
        ...user[0],
        isImpersonating,
        effectiveClientId,
        impersonatedClientName,
      });
    } catch (error) {
      structuredLogger.error("Get user error:", error);
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  // Security check endpoint - warns if using default admin credentials in production
  app.get("/api/auth/security-check", requireAuth, async (req, res) => {
    try {
      const user = await db.select({
        id: adminUsers.id,
        username: adminUsers.username,
        role: adminUsers.role,
        passwordHash: adminUsers.passwordHash,
      }).from(adminUsers).where(eq(adminUsers.id, req.session.userId!)).limit(1);
      
      if (!user[0] || user[0].role !== 'super_admin') {
        return res.json({ showDefaultCredentialsWarning: false });
      }
      
      // Check if using default username 'admin' and default password 'admin123'
      const isDefaultUsername = user[0].username === 'admin';
      const isDefaultPassword = await bcrypt.compare('admin123', user[0].passwordHash);
      const isProduction = process.env.NODE_ENV === 'production';
      
      res.json({
        showDefaultCredentialsWarning: isProduction && isDefaultUsername && isDefaultPassword,
        isProduction,
        isDefaultUsername,
        isDefaultPassword,
      });
    } catch (error) {
      structuredLogger.error("Security check error:", error);
      res.json({ showDefaultCredentialsWarning: false });
    }
  });

  // =============================================
  // PASSWORD RESET API ENDPOINTS
  // =============================================
  
  const PASSWORD_RESET_EXPIRY_MINUTES = 60;
  
  // Request password reset - accepts email, creates token, sends/logs reset link
  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email || typeof email !== 'string') {
        return res.status(400).json({ error: "Email is required" });
      }
      
      const normalizedEmail = email.toLowerCase().trim();
      
      // Find user by email (do NOT reveal if email exists)
      const [user] = await db.select({
        id: adminUsers.id,
        username: adminUsers.username,
        email: adminUsers.email,
      }).from(adminUsers).where(eq(adminUsers.email, normalizedEmail)).limit(1);
      
      // Always show success message to prevent email enumeration
      const successMessage = "If an account exists with that email, we've sent a password reset link.";
      
      if (!user) {
        // Log without exposing full email in production
        if (process.env.NODE_ENV !== 'production') {
          structuredLogger.info(`[PasswordReset] No user found for email: ${normalizedEmail}`);
        }
        return res.json({ success: true, message: successMessage });
      }
      
      // Generate cryptographically secure random token (32 bytes = 64 hex chars)
      const plainToken = crypto.randomBytes(32).toString('hex');
      
      // Hash the token for storage (never store plain token)
      const tokenHash = await bcrypt.hash(plainToken, 10);
      
      // Set expiration time
      const expiresAt = new Date(Date.now() + PASSWORD_RESET_EXPIRY_MINUTES * 60 * 1000);
      
      // Invalidate any existing tokens for this user
      await db.update(passwordResetTokens)
        .set({ usedAt: new Date() })
        .where(and(
          eq(passwordResetTokens.userId, user.id),
          sql`${passwordResetTokens.usedAt} IS NULL`
        ));
      
      // Store the new token
      await db.insert(passwordResetTokens).values({
        userId: user.id,
        tokenHash: tokenHash,
        expiresAt: expiresAt,
      });
      
      // Build reset URL
      const baseUrl = process.env.NODE_ENV === 'production' 
        ? `https://${req.get('host')}` 
        : `${req.protocol}://${req.get('host')}`;
      const resetUrl = `${baseUrl}/reset-password?token=${plainToken}`;
      
      // Send email (or log to console in dev mode)
      const emailResult = await emailService.sendPasswordResetEmail(
        normalizedEmail,
        resetUrl,
        user.username
      );
      
      if (!emailResult.success) {
        structuredLogger.error(`[PasswordReset] Failed to send reset email:`, emailResult.error);
        // Still return success to prevent enumeration
      } else if (process.env.NODE_ENV !== 'production') {
        structuredLogger.info(`[PasswordReset] Reset email sent/logged for user: ${user.username}`);
      }
      
      res.json({ success: true, message: successMessage });
    } catch (error) {
      structuredLogger.error("Forgot password error:", error);
      res.status(500).json({ error: "Failed to process password reset request" });
    }
  });
  
  // Validate reset token (for frontend to check before showing form)
  app.get("/api/auth/reset-password/:token", async (req, res) => {
    try {
      const { token } = req.params;
      
      if (!token || token.length < 32) {
        return res.status(400).json({ valid: false, error: "Invalid token format" });
      }
      
      // Find all unexpired, unused tokens
      const tokenRecords = await db.select()
        .from(passwordResetTokens)
        .where(and(
          sql`${passwordResetTokens.usedAt} IS NULL`,
          sql`${passwordResetTokens.expiresAt} > NOW()`
        ));
      
      // Check each token hash (since we can't query by hash directly)
      let validRecord = null;
      for (const record of tokenRecords) {
        const isMatch = await bcrypt.compare(token, record.tokenHash);
        if (isMatch) {
          validRecord = record;
          break;
        }
      }
      
      if (!validRecord) {
        return res.status(400).json({ 
          valid: false, 
          error: "This password reset link is invalid or has expired. Please request a new one." 
        });
      }
      
      res.json({ valid: true });
    } catch (error) {
      structuredLogger.error("Validate reset token error:", error);
      res.status(500).json({ valid: false, error: "Failed to validate token" });
    }
  });
  
  // Consume reset token and update password
  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { token, newPassword, confirmPassword } = req.body;
      
      // Validate inputs
      if (!token || typeof token !== 'string' || token.length < 32) {
        return res.status(400).json({ error: "Invalid token" });
      }
      
      if (!newPassword || typeof newPassword !== 'string') {
        return res.status(400).json({ error: "New password is required" });
      }
      
      if (newPassword !== confirmPassword) {
        return res.status(400).json({ error: "Passwords do not match" });
      }
      
      // Password strength validation (same rules as Create Login)
      const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
      if (!passwordRegex.test(newPassword)) {
        return res.status(400).json({ 
          error: "Password must be at least 8 characters with uppercase, lowercase, and a number" 
        });
      }
      
      // Find the token
      const tokenRecords = await db.select()
        .from(passwordResetTokens)
        .where(and(
          sql`${passwordResetTokens.usedAt} IS NULL`,
          sql`${passwordResetTokens.expiresAt} > NOW()`
        ));
      
      let validRecord = null;
      for (const record of tokenRecords) {
        const isMatch = await bcrypt.compare(token, record.tokenHash);
        if (isMatch) {
          validRecord = record;
          break;
        }
      }
      
      if (!validRecord) {
        return res.status(400).json({ 
          error: "This password reset link is invalid or has expired. Please request a new one." 
        });
      }
      
      // Hash new password
      const newPasswordHash = await bcrypt.hash(newPassword, 10);
      
      // Update user password
      await db.update(adminUsers)
        .set({ 
          passwordHash: newPasswordHash,
          mustChangePassword: false 
        })
        .where(eq(adminUsers.id, validRecord.userId));
      
      // Mark token as used
      await db.update(passwordResetTokens)
        .set({ usedAt: new Date() })
        .where(eq(passwordResetTokens.id, validRecord.id));
      
      // Invalidate any other outstanding tokens for this user
      await db.update(passwordResetTokens)
        .set({ usedAt: new Date() })
        .where(and(
          eq(passwordResetTokens.userId, validRecord.userId),
          sql`${passwordResetTokens.usedAt} IS NULL`
        ));
      
      // Invalidate all existing sessions for this user (security: force re-authentication)
      // Sessions are stored in "session" table by connect-pg-simple with userId in sess JSON
      try {
        await db.execute(
          sql`DELETE FROM session WHERE sess->>'userId' = ${validRecord.userId.toString()}`
        );
        structuredLogger.info(`[PasswordReset] Invalidated all sessions for user ID: ${validRecord.userId}`);
      } catch (sessionError) {
        // Non-fatal: log but continue - password was changed successfully
        structuredLogger.error(`[PasswordReset] Warning: Could not invalidate sessions for user ID: ${validRecord.userId}`, sessionError);
      }
      
      structuredLogger.info(`[PasswordReset] Password successfully reset for user ID: ${validRecord.userId}`);
      
      res.json({ 
        success: true, 
        message: "Your password has been reset. Please sign in with your new password." 
      });
    } catch (error) {
      structuredLogger.error("Reset password error:", error);
      res.status(500).json({ error: "Failed to reset password" });
    }
  });
  
  // Debug endpoint - view pending reset tokens (super admin only, dev environment)
  app.get("/api/auth/debug-reset-tokens", requireSuperAdmin, async (req, res) => {
    try {
      // Only allow in development
      if (process.env.NODE_ENV === 'production' && !process.env.ALLOW_DEBUG_ENDPOINTS) {
        return res.status(403).json({ error: "Debug endpoints disabled in production" });
      }
      
      const pendingTokens = getPendingResetTokens();
      const isEmailConfigured = emailService.isEmailConfigured();
      
      res.json({
        isEmailConfigured,
        note: isEmailConfigured 
          ? "Emails are being sent via SMTP" 
          : "Emails are logged to console. Set SMTP_HOST, SMTP_USER, SMTP_PASS to enable email.",
        pendingTokens: pendingTokens.map(t => ({
          email: t.email,
          resetUrl: t.resetUrl,
          expiresAt: t.expiresAt.toISOString(),
          createdAt: t.createdAt.toISOString(),
        })),
      });
    } catch (error) {
      structuredLogger.error("Debug reset tokens error:", error);
      res.status(500).json({ error: "Failed to fetch debug tokens" });
    }
  });
  
  // Clear debug tokens (super admin only, dev environment)
  app.delete("/api/auth/debug-reset-tokens", requireSuperAdmin, async (req, res) => {
    try {
      if (process.env.NODE_ENV === 'production' && !process.env.ALLOW_DEBUG_ENDPOINTS) {
        return res.status(403).json({ error: "Debug endpoints disabled in production" });
      }
      
      clearPendingResetTokens();
      res.json({ success: true, message: "Debug tokens cleared" });
    } catch (error) {
      structuredLogger.error("Clear debug tokens error:", error);
      res.status(500).json({ error: "Failed to clear debug tokens" });
    }
  });

  // =============================================
  // TEMPLATES API ENDPOINTS (Database-backed)
  // =============================================

  // Get all available bot templates
  app.get("/api/templates", async (req, res) => {
    try {
      const templates = await getAllTemplates();
      res.json(templates.map(t => ({
        id: t.id,
        templateId: t.templateId,
        name: t.name,
        description: t.description,
        botType: t.botType,
        icon: t.icon,
        previewImage: t.previewImage,
        isActive: t.isActive,
        displayOrder: t.displayOrder,
      })));
    } catch (error) {
      structuredLogger.error("Get templates error:", error);
      res.status(500).json({ error: "Failed to fetch templates" });
    }
  });

  // Get a specific template by ID
  // Protected: Template details require super admin access (contains bot config data)
  app.get("/api/templates/:templateId", requireSuperAdmin, async (req, res) => {
    try {
      const { templateId } = req.params;
      const template = await getTemplateById(templateId);
      
      if (!template) {
        return res.status(404).json({ error: `Template not found: ${templateId}` });
      }
      
      res.json(template);
    } catch (error) {
      structuredLogger.error("Get template error:", error);
      res.status(500).json({ error: "Failed to fetch template" });
    }
  });

  // =============================================
  // WORKSPACES API ENDPOINTS (Database-backed)
  // =============================================

  // Get all workspaces (admin only)
  app.get("/api/workspaces", requireSuperAdmin, async (req, res) => {
    try {
      const workspaceList = await getWorkspaces();
      res.json(workspaceList);
    } catch (error) {
      structuredLogger.error("Get workspaces error:", error);
      res.status(500).json({ error: "Failed to fetch workspaces" });
    }
  });

  // Get workspace by slug (super admin only until workspace membership is implemented)
  app.get("/api/workspaces/:slug", requireSuperAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      const workspace = await getWorkspaceBySlug(slug);
      
      if (!workspace) {
        return res.status(404).json({ error: `Workspace not found: ${slug}` });
      }
      
      res.json(workspace);
    } catch (error) {
      structuredLogger.error("Get workspace error:", error);
      res.status(500).json({ error: "Failed to fetch workspace" });
    }
  });

  // Get bots for a workspace (super admin only until workspace membership is implemented)
  app.get("/api/workspaces/:workspaceId/bots", requireSuperAdmin, async (req, res) => {
    try {
      const { workspaceId } = req.params;
      const botConfigs = await getBotsByWorkspaceId(workspaceId);
      
      res.json(botConfigs.map(bot => ({
        botId: bot.botId,
        name: bot.name,
        description: bot.description,
        botType: bot.botType,
        businessName: bot.businessProfile.businessName,
        status: bot.metadata?.isDemo ? 'demo' : 'active',
      })));
    } catch (error) {
      structuredLogger.error("Get workspace bots error:", error);
      res.status(500).json({ error: "Failed to fetch workspace bots" });
    }
  });

  // =============================================
  // WORKSPACE DIAGNOSTICS (Super Admin Only)
  // One-click PASS/FAIL setup verification
  // =============================================
  
  app.get("/api/admin/workspaces/:workspaceId/diagnostics", requireSuperAdmin, async (req, res) => {
    try {
      const { workspaceId } = req.params;
      
      // Find workspace by ID or slug
      let workspace = await getWorkspaceBySlug(workspaceId);
      if (!workspace) {
        const [ws] = await db.select().from(workspaces).where(eq(workspaces.id, workspaceId)).limit(1);
        workspace = ws;
      }
      
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      const clientId = workspace.slug;
      const diagnostics: Record<string, { pass: boolean; message: string; details?: any }> = {};
      
      // 1. Widget Configuration Check
      try {
        const settings = await storage.getSettings(clientId);
        const hasBusinessName = !!(settings?.businessName && settings.businessName !== "The Faith House");
        const hasBrandColor = !!(settings?.primaryColor);
        diagnostics.widgetConfig = {
          pass: hasBusinessName && hasBrandColor,
          message: hasBusinessName && hasBrandColor ? "Widget configured" : "Missing business name or brand color",
          details: { hasBusinessName, hasBrandColor }
        };
      } catch {
        diagnostics.widgetConfig = { pass: false, message: "Failed to check widget config" };
      }
      
      // 2. Token Generation Check
      try {
        const botConfigs = await getBotsByWorkspaceId(workspace.id);
        if (botConfigs.length > 0) {
          const testToken = generateWidgetToken(clientId, botConfigs[0].botId);
          const verified = verifyWidgetToken(testToken);
          diagnostics.tokenGeneration = {
            pass: verified.valid,
            message: verified.valid ? "Token generation working" : "Token verification failed",
          };
        } else {
          diagnostics.tokenGeneration = { pass: false, message: "No bots configured for workspace" };
        }
      } catch {
        diagnostics.tokenGeneration = { pass: false, message: "Token generation error" };
      }
      
      // 3. AI Configuration Check
      const openaiKey = process.env.OPENAI_API_KEY || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
      diagnostics.aiConfig = {
        pass: !!(openaiKey && openaiKey.length > 10),
        message: openaiKey ? "OpenAI API configured" : "OpenAI API key missing"
      };
      
      // 4. Database Connectivity Check
      try {
        const dbCheck = await storage.healthCheck?.() ?? { status: 'ok' };
        diagnostics.database = {
          pass: dbCheck.status === 'ok',
          message: dbCheck.status === 'ok' ? `Database healthy (${dbCheck.latencyMs}ms)` : "Database unhealthy",
          details: { latencyMs: dbCheck.latencyMs }
        };
      } catch {
        diagnostics.database = { pass: false, message: "Database check failed" };
      }
      
      // 5. Knowledge Base Check
      try {
        const settings = await storage.getSettings(clientId);
        const kb = settings?.knowledgeBase;
        const hasAbout = !!(kb?.about && kb.about.length > 50);
        const hasFaqs = (settings?.faqEntries?.length || 0) > 0;
        diagnostics.knowledgeBase = {
          pass: hasAbout || hasFaqs,
          message: hasAbout || hasFaqs ? "Knowledge base configured" : "No knowledge base content",
          details: { hasAbout, faqCount: settings?.faqEntries?.length || 0 }
        };
      } catch {
        diagnostics.knowledgeBase = { pass: false, message: "Knowledge base check failed" };
      }
      
      // 6. Booking URL Check (if external mode)
      try {
        const settings = await storage.getSettings(clientId);
        const isExternalMode = settings?.bookingMode === 'external';
        const hasBookingUrl = !!(settings?.externalBookingUrl);
        diagnostics.bookingConfig = {
          pass: !isExternalMode || hasBookingUrl,
          message: isExternalMode 
            ? (hasBookingUrl ? "External booking URL configured" : "Missing external booking URL")
            : "Using internal booking (no URL needed)",
          details: { mode: settings?.bookingMode, hasUrl: hasBookingUrl }
        };
      } catch {
        diagnostics.bookingConfig = { pass: false, message: "Booking config check failed" };
      }
      
      // Calculate overall status
      const allPassing = Object.values(diagnostics).every(d => d.pass);
      const passingCount = Object.values(diagnostics).filter(d => d.pass).length;
      const totalChecks = Object.keys(diagnostics).length;
      
      res.json({
        workspaceId: workspace.id,
        workspaceSlug: workspace.slug,
        overall: allPassing ? "PASS" : "FAIL",
        summary: `${passingCount}/${totalChecks} checks passing`,
        diagnostics,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      structuredLogger.error("Workspace diagnostics error:", error);
      res.status(500).json({ error: "Failed to run diagnostics" });
    }
  });

  // =============================================
  // ADMIN PLATFORM ERRORS (Super Admin Only)
  // Quick view of recent platform errors
  // =============================================
  
  app.get("/api/admin/platform-errors", requireSuperAdmin, async (req, res) => {
    try {
      const { limit = "50", level = "error", clientId } = req.query;
      
      const filters: any = {
        limit: Math.min(parseInt(String(limit), 10), 200),
        level: String(level),
      };
      
      // Tenant-safe: optionally filter by clientId
      if (clientId) {
        filters.clientId = String(clientId);
      }
      
      const result = await storage.getSystemLogs(filters);
      
      // Get error category breakdown
      const categories: Record<string, number> = {};
      for (const log of result.logs) {
        const src = (log.source || 'other').toLowerCase();
        let cat = 'other';
        if (src.includes('chat') || src.includes('orchestrator')) cat = 'chat';
        else if (src.includes('widget')) cat = 'widget';
        else if (src.includes('lead')) cat = 'lead';
        else if (src.includes('booking') || src.includes('appointment')) cat = 'booking';
        else if (src.includes('auth') || src.includes('login')) cat = 'auth';
        else if (src.includes('db') || src.includes('database')) cat = 'db';
        categories[cat] = (categories[cat] || 0) + 1;
      }
      
      res.json({
        total: result.total,
        returned: result.logs.length,
        categories,
        errors: result.logs.map(log => ({
          id: log.id,
          level: log.level,
          source: log.source,
          message: log.message,
          clientId: log.clientId,
          isResolved: log.isResolved,
          createdAt: log.createdAt,
        })),
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      structuredLogger.error("Get platform errors error:", error);
      res.status(500).json({ error: "Failed to fetch platform errors" });
    }
  });

  // =============================================
  // AUDIT LOGS (Super Admin + Workspace Admins)
  // =============================================
  
  app.get("/api/admin/audit-logs", requireAdminRole, async (req, res) => {
    try {
      const { 
        clientId, 
        workspaceId, 
        userId, 
        action, 
        resourceType,
        startDate,
        endDate,
        limit = "100",
        offset = "0"
      } = req.query;
      
      // Tenant-safe: non-super-admins can only see their own workspace's logs
      let filterClientId = clientId as string | undefined;
      let filterWorkspaceId = workspaceId as string | undefined;
      
      if (req.session.userRole !== 'super_admin') {
        filterClientId = req.session.clientId || undefined;
      }
      
      const filters: any = {
        limit: Math.min(parseInt(String(limit), 10), 500),
        offset: parseInt(String(offset), 10),
      };
      
      if (filterClientId) filters.clientId = filterClientId;
      if (filterWorkspaceId) filters.workspaceId = filterWorkspaceId;
      if (userId) filters.userId = String(userId);
      if (action) filters.action = String(action);
      if (resourceType) filters.resourceType = String(resourceType);
      if (startDate) filters.startDate = new Date(String(startDate));
      if (endDate) filters.endDate = new Date(String(endDate));
      
      const result = await getAuditLogs(filters);
      
      res.json({
        logs: result.logs,
        total: result.total,
        limit: filters.limit,
        offset: filters.offset
      });
    } catch (error) {
      structuredLogger.error("Get audit logs error:", error);
      res.status(500).json({ error: "Failed to fetch audit logs" });
    }
  });
  
  // Get audit log action types for filter dropdown
  app.get("/api/admin/audit-logs/actions", requireAdminRole, async (req, res) => {
    const { AUDIT_ACTIONS, AUDIT_RESOURCE_TYPES } = await import("@shared/schema");
    res.json({
      actions: AUDIT_ACTIONS,
      resourceTypes: AUDIT_RESOURCE_TYPES
    });
  });

  // =============================================
  // CLIENT USER MANAGEMENT (Super Admin Only)
  // =============================================

  const createClientUserSchema = z.object({
    email: z.string().email("Invalid email address"),
    password: z.string().min(8, "Password must be at least 8 characters")
      .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
      .regex(/[a-z]/, "Password must contain at least one lowercase letter")
      .regex(/[0-9]/, "Password must contain at least one number"),
    name: z.string().optional(),
  });

  const resetPasswordSchema = z.object({
    newPassword: z.string().min(8, "Password must be at least 8 characters")
      .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
      .regex(/[a-z]/, "Password must contain at least one lowercase letter")
      .regex(/[0-9]/, "Password must contain at least one number"),
  });

  // Get client users for a workspace
  app.get("/api/super-admin/workspaces/:workspaceId/users", requireSuperAdmin, async (req, res) => {
    try {
      const { workspaceId } = req.params;
      
      // Get workspace to find its slug (clientId) - check both by ID and by slug
      let [workspace] = await db
        .select()
        .from(workspaces)
        .where(eq(workspaces.id, workspaceId))
        .limit(1);
      
      // If not found by ID, try finding by slug
      if (!workspace) {
        [workspace] = await db
          .select()
          .from(workspaces)
          .where(eq(workspaces.slug, workspaceId))
          .limit(1);
      }
      
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Find users associated with this workspace's slug as clientId
      const users = await db
        .select({
          id: adminUsers.id,
          username: adminUsers.username,
          email: adminUsers.username,
          role: adminUsers.role,
          clientId: adminUsers.clientId,
          createdAt: adminUsers.createdAt,
          disabled: adminUsers.disabled,
          mustChangePassword: adminUsers.mustChangePassword,
          lastLoginAt: adminUsers.lastLoginAt,
        })
        .from(adminUsers)
        .where(and(
          eq(adminUsers.clientId, workspace.slug),
          eq(adminUsers.role, "client_admin")
        ))
        .orderBy(desc(adminUsers.createdAt));
      
      res.json(users);
    } catch (error) {
      structuredLogger.error("Get workspace users error:", error);
      res.status(500).json({ error: "Failed to fetch workspace users" });
    }
  });

  // Create a client user for a workspace
  app.post("/api/super-admin/workspaces/:workspaceId/users", requireSuperAdmin, async (req, res) => {
    try {
      const { workspaceId } = req.params;
      const validatedData = createClientUserSchema.parse(req.body);
      
      // Get workspace to find its slug
      const [workspace] = await db
        .select()
        .from(workspaces)
        .where(eq(workspaces.id, workspaceId))
        .limit(1);
      
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Check if email already exists
      const existingUser = await storage.findAdminByUsername(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ error: "This email is already in use" });
      }
      
      // Hash password
      const passwordHash = await bcrypt.hash(validatedData.password, 10);
      
      // Create client user
      const [newUser] = await db.insert(adminUsers).values({
        username: validatedData.email,
        passwordHash,
        role: "client_admin",
        clientId: workspace.slug,
        mustChangePassword: true,
        disabled: false,
      }).returning();
      
      res.status(201).json({
        success: true,
        user: {
          id: newUser.id,
          email: newUser.username,
          role: newUser.role,
          createdAt: newUser.createdAt,
          disabled: newUser.disabled,
          mustChangePassword: newUser.mustChangePassword,
        }
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      structuredLogger.error("Create client user error:", error);
      res.status(500).json({ error: "Failed to create client user" });
    }
  });

  // Reset a client user's password
  app.post("/api/super-admin/workspaces/:workspaceId/users/:userId/reset-password", requireSuperAdmin, async (req, res) => {
    try {
      const { workspaceId, userId } = req.params;
      const validatedData = resetPasswordSchema.parse(req.body);
      
      // Get workspace to verify it exists
      const [workspace] = await db
        .select()
        .from(workspaces)
        .where(eq(workspaces.id, workspaceId))
        .limit(1);
      
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Get user and verify they belong to this workspace
      const [user] = await db
        .select()
        .from(adminUsers)
        .where(and(
          eq(adminUsers.id, userId),
          eq(adminUsers.clientId, workspace.slug),
          eq(adminUsers.role, "client_admin")
        ))
        .limit(1);
      
      if (!user) {
        return res.status(404).json({ error: "User not found in this workspace" });
      }
      
      // Hash new password
      const passwordHash = await bcrypt.hash(validatedData.newPassword, 10);
      
      // Update password and set mustChangePassword to true
      await db
        .update(adminUsers)
        .set({
          passwordHash,
          mustChangePassword: true,
        })
        .where(eq(adminUsers.id, userId));
      
      res.json({ success: true, message: "Password reset successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      structuredLogger.error("Reset password error:", error);
      res.status(500).json({ error: "Failed to reset password" });
    }
  });

  // Disable a client user
  app.post("/api/super-admin/workspaces/:workspaceId/users/:userId/disable", requireSuperAdmin, async (req, res) => {
    try {
      const { workspaceId, userId } = req.params;
      
      // Get workspace to verify it exists
      const [workspace] = await db
        .select()
        .from(workspaces)
        .where(eq(workspaces.id, workspaceId))
        .limit(1);
      
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Get user and verify they belong to this workspace
      const [user] = await db
        .select()
        .from(adminUsers)
        .where(and(
          eq(adminUsers.id, userId),
          eq(adminUsers.clientId, workspace.slug),
          eq(adminUsers.role, "client_admin")
        ))
        .limit(1);
      
      if (!user) {
        return res.status(404).json({ error: "User not found in this workspace" });
      }
      
      // Disable the user
      await db
        .update(adminUsers)
        .set({ disabled: true })
        .where(eq(adminUsers.id, userId));
      
      res.json({ success: true, message: "User disabled successfully" });
    } catch (error) {
      structuredLogger.error("Disable user error:", error);
      res.status(500).json({ error: "Failed to disable user" });
    }
  });

  // Enable a client user (reverse disable)
  app.post("/api/super-admin/workspaces/:workspaceId/users/:userId/enable", requireSuperAdmin, async (req, res) => {
    try {
      const { workspaceId, userId } = req.params;
      
      // Get workspace to verify it exists
      const [workspace] = await db
        .select()
        .from(workspaces)
        .where(eq(workspaces.id, workspaceId))
        .limit(1);
      
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Get user and verify they belong to this workspace
      const [user] = await db
        .select()
        .from(adminUsers)
        .where(and(
          eq(adminUsers.id, userId),
          eq(adminUsers.clientId, workspace.slug),
          eq(adminUsers.role, "client_admin")
        ))
        .limit(1);
      
      if (!user) {
        return res.status(404).json({ error: "User not found in this workspace" });
      }
      
      // Enable the user
      await db
        .update(adminUsers)
        .set({ disabled: false })
        .where(eq(adminUsers.id, userId));
      
      res.json({ success: true, message: "User enabled successfully" });
    } catch (error) {
      structuredLogger.error("Enable user error:", error);
      res.status(500).json({ error: "Failed to enable user" });
    }
  });

  // =============================================
  // SECURE SUPER ADMIN IMPERSONATION
  // =============================================
  
  // Rate limiter for impersonation endpoints (prevents spam-clicking during demos)
  const impersonationLimiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 20, // 20 requests per minute per session/IP
    keyGenerator: (req) => req.session?.userId?.toString() || 'unknown',
    message: { error: "Too many impersonation requests", message: "Please wait a moment before switching clients again." },
    standardHeaders: true,
    legacyHeaders: false,
  });
  
  // Schema for impersonation request
  const impersonateClientSchema = z.object({
    clientId: z.string().min(1, "clientId is required").regex(/^[a-zA-Z0-9_-]+$/, "Invalid clientId format"),
  });

  // Start impersonating a client (sets session-based effectiveClientId)
  app.post("/api/super-admin/impersonate", requireSuperAdmin, csrfProtection, impersonationLimiter, async (req, res) => {
    try {
      const validation = impersonateClientSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Invalid request", 
          details: validation.error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ')
        });
      }
      
      const { clientId } = validation.data;
      
      // SECURITY: Use database as the canonical source of truth (not bot JSON cache)
      // This prevents false positives from stale cached configs or deleted workspaces
      const workspace = await storage.getWorkspaceByClientId(clientId);
      
      if (!workspace) {
        return res.status(404).json({ error: "Client not found" });
      }
      
      // Validate tenant status before allowing impersonation
      const workspaceStatus = (workspace as any).status || 'active';
      if (workspaceStatus === 'deleted' || workspaceStatus === 'disabled') {
        return res.status(403).json({ 
          error: "Cannot impersonate disabled client", 
          message: "This client has been disabled or deleted and cannot be accessed." 
        });
      }
      
      // Track if workspace is paused for warning message
      const isPaused = workspaceStatus === 'paused' || workspaceStatus === 'suspended';
      
      // Set the effectiveClientId in session (secure server-side storage)
      req.session.effectiveClientId = clientId;
      req.session.isImpersonating = true;
      req.session.lastSeenAt = Date.now(); // Reset idle timeout on impersonation
      
      // Save session explicitly
      await new Promise<void>((resolve, reject) => {
        req.session.save((err) => {
          if (err) reject(err);
          else resolve();
        });
      });
      
      // Respond immediately for snappy UX
      structuredLogger.info(`Super admin ${req.session.userId} started impersonating client: ${clientId}`);
      res.json({ 
        success: true, 
        message: isPaused 
          ? `Now viewing as client: ${clientId} (Warning: This client is currently ${workspaceStatus})`
          : `Now viewing as client: ${clientId}`,
        effectiveClientId: clientId,
        warning: isPaused ? `This client is currently ${workspaceStatus}` : undefined
      });
      
      // Fire-and-forget audit logging (non-blocking)
      logAuditEvent({
        userId: req.session.userId || 'unknown',
        username: req.session.username || 'super_admin',
        userRole: 'super_admin',
        action: 'IMPERSONATION_START',
        resourceType: 'client',
        resourceId: clientId,
        ipAddress: req.ip || req.socket.remoteAddress,
        userAgent: req.headers['user-agent'],
        details: { targetClientId: clientId },
      }).catch(err => structuredLogger.error("Failed to log impersonation audit event:", err));
    } catch (error) {
      structuredLogger.error("Impersonation error:", error);
      res.status(500).json({ error: "Failed to start impersonation" });
    }
  });

  // Stop impersonating (clears effectiveClientId from session)
  // Primary endpoint: /api/super-admin/impersonate/stop
  // Legacy alias: /api/super-admin/stop-impersonate
  const stopImpersonationHandler = async (req: Request, res: Response) => {
    try {
      const previousClientId = req.session.effectiveClientId;
      
      // Handle "not impersonating" case explicitly (cleaner for demos)
      // Returns same shape as successful stop for trivial frontend logic
      if (!previousClientId || !req.session.isImpersonating) {
        return res.json({ 
          success: true, 
          message: "Already not impersonating",
          previousClientId: null,
          isImpersonating: false,
          effectiveClientId: null
        });
      }
      
      // Clear impersonation from session
      req.session.effectiveClientId = null;
      req.session.isImpersonating = false;
      req.session.lastSeenAt = Date.now(); // Reset idle timeout on stop impersonation
      
      // Save session explicitly - CRITICAL for multi-tab and demo consistency
      await new Promise<void>((resolve, reject) => {
        req.session.save((err) => {
          if (err) reject(err);
          else resolve();
        });
      });
      
      // Respond immediately for snappy UX
      structuredLogger.info(`Super admin ${req.session.userId} stopped impersonating client: ${previousClientId}`);
      res.json({ 
        success: true, 
        message: "Stopped impersonation, returned to super admin view",
        previousClientId,
        isImpersonating: false,
        effectiveClientId: null
      });
      
      // Fire-and-forget audit logging (non-blocking)
      logAuditEvent({
        userId: req.session.userId || 'unknown',
        username: req.session.username || 'super_admin',
        userRole: 'super_admin',
        action: 'IMPERSONATION_STOP',
        resourceType: 'client',
        resourceId: previousClientId || 'none',
        ipAddress: req.ip || req.socket.remoteAddress,
        userAgent: req.headers['user-agent'],
        details: { previousClientId },
      }).catch(err => structuredLogger.error("Failed to log impersonation audit event:", err));
    } catch (error) {
      structuredLogger.error("Stop impersonation error:", error);
      res.status(500).json({ error: "Failed to stop impersonation" });
    }
  };
  
  // Primary endpoint (with rate limiting + CSRF)
  app.post("/api/super-admin/impersonate/stop", requireSuperAdmin, csrfProtection, impersonationLimiter, stopImpersonationHandler);
  
  // Legacy alias for backward compatibility - delegates to the same handler (with rate limiting + CSRF)
  app.post("/api/super-admin/stop-impersonate", requireSuperAdmin, csrfProtection, impersonationLimiter, stopImpersonationHandler);

  // Get current impersonation status
  app.get("/api/super-admin/impersonation-status", requireSuperAdmin, async (req, res) => {
    res.json({
      isImpersonating: req.session.isImpersonating || false,
      effectiveClientId: req.session.effectiveClientId || null
    });
  });

  // =============================================
  // SUPER ADMIN API ENDPOINTS
  // =============================================

  // Get list of clients with their bots (includes all from JSON configs)
  app.get("/api/super-admin/clients", requireSuperAdmin, async (req, res) => {
    try {
      // Get clients from JSON config
      const clientsData = getClients();
      const allBots = getAllBotConfigs();
      
      // Build client list with bots
      const clientsWithBots = clientsData.clients.map(client => ({
        id: client.id,
        name: client.name,
        status: client.status || 'active',
        type: client.type,
        bots: allBots
          .filter(bot => bot.clientId === client.id)
          .map(bot => ({
            botId: bot.botId,
            name: bot.name,
            description: bot.description,
            businessType: bot.businessProfile.type,
            businessName: bot.businessProfile.businessName,
            isDemo: bot.metadata?.isDemo ?? false
          }))
      }));
      
      res.json(clientsWithBots);
    } catch (error) {
      structuredLogger.error("Get clients error:", error);
      res.status(500).json({ error: "Failed to fetch clients" });
    }
  });

  // Update client status (Active / Paused / Demo)
  app.put("/api/super-admin/clients/:clientId/status", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const { status } = req.body;
      
      if (!['active', 'paused', 'demo'].includes(status)) {
        return res.status(400).json({ error: "Status must be 'active', 'paused', or 'demo'" });
      }
      
      const result = updateClientStatus(clientId, status);
      
      if (result.success) {
        res.json({ 
          success: true, 
          client: result.client,
          message: `Client status updated to ${status}`
        });
      } else {
        res.status(404).json({ error: result.error || "Failed to update client status" });
      }
    } catch (error) {
      structuredLogger.error("Update client status error:", error);
      res.status(500).json({ error: "Failed to update client status" });
    }
  });

  // Get all bots as a flat list for individual editing (includes full config with FAQs)
  app.get("/api/super-admin/bots", requireSuperAdmin, async (req, res) => {
    try {
      // Use async version to ensure database bots are loaded (not just JSON files)
      const allBots = await getAllBotConfigsAsync();
      
      // Return full bot configs including FAQs, rules, etc.
      const botList = allBots.map(bot => ({
        botId: bot.botId,
        clientId: bot.clientId,
        name: bot.name,
        description: bot.description,
        businessProfile: bot.businessProfile,
        businessType: bot.businessProfile?.type,
        businessName: bot.businessProfile?.businessName,
        isDemo: bot.metadata?.isDemo ?? false,
        systemPrompt: bot.systemPrompt,
        faqs: bot.faqs || [],
        rules: bot.rules || {},
        automations: bot.automations || {},
        personality: bot.personality || {},
        quickActions: bot.quickActions || [],
        metadata: bot.metadata
      }));
      
      res.json(botList);
    } catch (error) {
      structuredLogger.error("Get bots error:", error);
      res.status(500).json({ error: "Failed to fetch bots" });
    }
  });

  // Get individual bot config for editing
  app.get("/api/super-admin/bots/:botId", requireSuperAdmin, async (req, res) => {
    try {
      const { botId } = req.params;
      // Use async version to ensure database bots are loaded
      const botConfig = await getBotConfigByBotIdAsync(botId);
      
      if (!botConfig) {
        return res.status(404).json({ error: `Bot not found: ${botId}` });
      }
      
      res.json(botConfig);
    } catch (error) {
      structuredLogger.error("Get bot config error:", error);
      res.status(500).json({ error: "Failed to fetch bot config" });
    }
  });

  // Update individual bot config
  app.put("/api/super-admin/bots/:botId", requireSuperAdmin, async (req, res) => {
    try {
      const { botId } = req.params;
      const updates = req.body;
      
      const existingConfig = getBotConfigByBotId(botId);
      if (!existingConfig) {
        return res.status(404).json({ error: `Bot not found: ${botId}` });
      }
      
      const updatedConfig: BotConfig = {
        ...existingConfig,
        ...updates,
        botId: existingConfig.botId,
        clientId: existingConfig.clientId,
      };
      
      // Use async version which handles both database and JSON file storage
      const success = await saveBotConfigAsync(botId, updatedConfig);
      
      if (success) {
        res.json({ success: true, config: updatedConfig });
      } else {
        res.status(500).json({ error: "Failed to save bot config" });
      }
    } catch (error) {
      structuredLogger.error("Update bot config error:", error);
      res.status(500).json({ error: "Failed to update bot config" });
    }
  });

  // Duplicate bot - create a copy of an existing bot
  app.post("/api/super-admin/bots/:botId/duplicate", requireSuperAdmin, (req, res) => {
    try {
      const { botId } = req.params;
      const existingConfig = getBotConfigByBotId(botId);
      
      if (!existingConfig) {
        return res.status(404).json({ error: `Bot not found: ${botId}` });
      }
      
      // Generate new bot ID
      const timestamp = Date.now().toString(36);
      const random = Math.random().toString(36).substring(2, 8);
      const newBotId = `bot_${timestamp}_${random}`;
      
      // Create duplicate config with new ID
      const duplicatedConfig: BotConfig = {
        ...existingConfig,
        botId: newBotId,
        name: `${existingConfig.name || existingConfig.businessProfile?.businessName || 'Bot'} (Copy)`,
        metadata: {
          ...existingConfig.metadata,
          clonedFrom: botId,
          createdAt: new Date().toISOString(),
        } as any,
        status: 'paused', // Start duplicates as paused
      };
      
      const success = createBotConfig(duplicatedConfig);
      
      if (success) {
        res.json(duplicatedConfig);
      } else {
        res.status(500).json({ error: "Failed to duplicate bot" });
      }
    } catch (error) {
      structuredLogger.error("Duplicate bot error:", error);
      res.status(500).json({ error: "Failed to duplicate bot" });
    }
  });

  // Create bot from template for existing client
  app.post("/api/super-admin/bots/from-template", requireSuperAdmin, (req, res) => {
    try {
      const { templateBotId, clientId, name } = req.body;
      
      if (!templateBotId || !clientId || !name) {
        return res.status(400).json({ error: "templateBotId, clientId, and name are required" });
      }
      
      // Check if client exists
      const client = getClientById(clientId);
      if (!client) {
        return res.status(404).json({ error: `Client not found: ${clientId}` });
      }
      
      // Get template config from real templates only
      let templateConfig = getBotConfigByBotId(templateBotId);
      
      // Reject legacy starter templates - enforce INDUSTRY_TEMPLATES as the only valid source
      if (!templateConfig && templateBotId.startsWith('starter-')) {
        return res.status(400).json({ 
          error: "Legacy starter templates are not supported. Use a valid templateId from INDUSTRY_TEMPLATES." 
        });
      }
      
      if (!templateConfig) {
        return res.status(404).json({ error: `Template not found: ${templateBotId}` });
      }
      
      // Generate new bot ID
      const timestamp = Date.now().toString(36);
      const random = Math.random().toString(36).substring(2, 8);
      const newBotId = `bot_${timestamp}_${random}`;
      
      // Create new bot config from template
      const newConfig: BotConfig = {
        ...templateConfig,
        botId: newBotId,
        clientId: clientId,
        name: name,
        description: templateConfig.description || `AI assistant for ${name}`,
        businessProfile: {
          ...templateConfig.businessProfile,
          businessName: name,
        },
        metadata: {
          isDemo: false,
          isTemplate: false,
          clonedFrom: templateBotId,
          createdAt: new Date().toISOString(),
          version: '1.0',
        },
        status: 'active',
      };
      
      const success = createBotConfig(newConfig);
      
      if (success) {
        // Add bot to client's bot list
        if (client.bots && !client.bots.includes(newBotId)) {
          client.bots.push(newBotId);
        }
        res.json(newConfig);
      } else {
        res.status(500).json({ error: "Failed to create bot from template" });
      }
    } catch (error) {
      structuredLogger.error("Create bot from template error:", error);
      res.status(500).json({ error: "Failed to create bot from template" });
    }
  });

  // Update bot status (pause/activate)
  app.patch("/api/super-admin/bots/:botId/status", requireSuperAdmin, async (req, res) => {
    try {
      const { botId } = req.params;
      const { status } = req.body;
      
      if (!['active', 'paused'].includes(status)) {
        return res.status(400).json({ error: "Invalid status. Must be 'active' or 'paused'." });
      }
      
      const existingConfig = getBotConfigByBotId(botId);
      if (!existingConfig) {
        return res.status(404).json({ error: `Bot not found: ${botId}` });
      }
      
      const updatedConfig: BotConfig = {
        ...existingConfig,
        status: status,
      };
      
      // Use async version which handles both database and JSON file storage
      const success = await saveBotConfigAsync(botId, updatedConfig);
      
      if (success) {
        res.json({ success: true, botId, status });
      } else {
        res.status(500).json({ error: "Failed to update bot status" });
      }
    } catch (error) {
      structuredLogger.error("Update bot status error:", error);
      res.status(500).json({ error: "Failed to update bot status" });
    }
  });

  // =============================================
  // PHASE 3: WEBSITE SCRAPER ROUTES
  // =============================================

  const scrapeUrlSchema = z.object({
    url: z.string().url("Invalid URL format"),
    botId: z.string().optional(),
  });

  app.post("/api/admin/scrape", requireSuperAdmin, async (req, res) => {
    try {
      const validation = scrapeUrlSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ error: validation.error.errors[0].message });
      }

      const { url, botId } = validation.data;
      const workspaceId = "default";

      const result = await scrapeWebsite(url, workspaceId, botId);

      if (result.success) {
        const scrape = await storage.getScrapedWebsiteById(result.scrapeId);
        res.json({ success: true, scrape });
      } else {
        res.status(500).json({ success: false, error: result.error, scrapeId: result.scrapeId });
      }
    } catch (error) {
      structuredLogger.error("Scrape error:", error);
      res.status(500).json({ error: "Failed to scrape website" });
    }
  });

  app.get("/api/admin/scraped-websites", requireSuperAdmin, async (req, res) => {
    try {
      const { botId } = req.query;
      const workspaceId = "default";

      const scrapes = await storage.getScrapedWebsites(
        workspaceId,
        botId as string | undefined
      );

      res.json(scrapes);
    } catch (error) {
      structuredLogger.error("Get scraped websites error:", error);
      res.status(500).json({ error: "Failed to fetch scraped websites" });
    }
  });

  app.get("/api/admin/scraped-websites/:id", requireSuperAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const scrape = await storage.getScrapedWebsiteById(id);

      if (!scrape) {
        return res.status(404).json({ error: "Scrape not found" });
      }

      res.json(scrape);
    } catch (error) {
      structuredLogger.error("Get scraped website error:", error);
      res.status(500).json({ error: "Failed to fetch scraped website" });
    }
  });

  app.put("/api/admin/scraped-websites/:id", requireSuperAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;

      const scrape = await storage.updateScrapedWebsite(id, updates);
      res.json(scrape);
    } catch (error) {
      structuredLogger.error("Update scraped website error:", error);
      res.status(500).json({ error: "Failed to update scraped website" });
    }
  });

  app.post("/api/admin/scraped-websites/:id/apply", requireSuperAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { botId } = req.body;
      const user = req.user;

      if (!botId) {
        return res.status(400).json({ error: "botId is required" });
      }

      const result = await applyScrapedDataToBot(id, botId, String(user?.id ?? "admin"));

      if (result.success) {
        const scrape = await storage.getScrapedWebsiteById(id);
        res.json({ success: true, scrape });
      } else {
        res.status(400).json({ success: false, error: result.error });
      }
    } catch (error) {
      structuredLogger.error("Apply scraped data error:", error);
      res.status(500).json({ error: "Failed to apply scraped data" });
    }
  });

  app.delete("/api/admin/scraped-websites/:id", requireSuperAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteScrapedWebsite(id);
      res.json({ success: true });
    } catch (error) {
      structuredLogger.error("Delete scraped website error:", error);
      res.status(500).json({ error: "Failed to delete scraped website" });
    }
  });

  // Website Import - Multi-page crawl with structured suggestions
  app.post("/api/admin/website-import", requireSuperAdmin, async (req, res) => {
    try {
      const { url, maxPages, maxDepth } = req.body;
      
      if (!url || typeof url !== 'string') {
        return res.status(400).json({ error: "URL is required" });
      }

      // Validate URL format
      const urlPattern = /^https?:\/\/.+/i;
      let normalizedUrl = url.trim();
      if (!urlPattern.test(normalizedUrl)) {
        normalizedUrl = `https://${normalizedUrl}`;
      }

      structuredLogger.info(`[Website Import] Starting import for: ${normalizedUrl}`);
      
      const options: { maxPages?: number; maxDepth?: number } = {};
      if (typeof maxPages === 'number' && maxPages > 0 && maxPages <= 20) {
        options.maxPages = maxPages;
      }
      if (typeof maxDepth === 'number' && maxDepth >= 0 && maxDepth <= 3) {
        options.maxDepth = maxDepth;
      }

      const suggestions = await importWebsite(normalizedUrl, options);
      
      structuredLogger.info(`[Website Import] Completed: ${suggestions.pagesScanned} pages, ${suggestions.services.length} services, ${suggestions.faqs.length} FAQs`);
      
      res.json({
        success: true,
        suggestions,
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      structuredLogger.error("[Website Import] Error:", errorMessage);
      res.status(500).json({ 
        success: false,
        error: `Failed to import website: ${errorMessage}` 
      });
    }
  });

  // =============================================
  // PREVIEW LINK GENERATION - 24-hour sales preview links
  // =============================================
  
  // Generate a preview link for a workspace/bot (super_admin only)
  app.post("/api/admin/preview-link", requireSuperAdmin, async (req, res) => {
    try {
      const { workspaceSlug, botId, ttl } = req.body;
      
      if (!workspaceSlug || typeof workspaceSlug !== 'string') {
        return res.status(400).json({ error: "workspaceSlug is required" });
      }
      
      if (!botId || typeof botId !== 'string') {
        return res.status(400).json({ error: "botId is required" });
      }
      
      // Verify workspace exists
      const workspace = await getWorkspaceBySlug(workspaceSlug);
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Verify bot exists and belongs to this workspace
      const botConfig = await getBotConfigByBotIdAsync(botId) || getBotConfigByBotId(botId);
      if (!botConfig) {
        return res.status(404).json({ error: "Bot not found" });
      }
      
      // Generate preview token (default 24 hours)
      const tokenTtl = typeof ttl === 'number' && ttl > 0 ? Math.min(ttl, 86400 * 7) : 86400;
      const tokenResult = generatePreviewToken(workspaceSlug, botId, tokenTtl);
      
      // Build the preview URL
      const baseUrl = process.env.REPLIT_DEV_DOMAIN 
        ? `https://${process.env.REPLIT_DEV_DOMAIN}`
        : process.env.BASE_URL || 'http://localhost:5000';
      const previewUrl = `${baseUrl}/preview/${workspaceSlug}?t=${tokenResult.token}`;
      
      structuredLogger.info(`[Preview Link] Generated for ${workspaceSlug}/${botId}, expires: ${tokenResult.expiresAt.toISOString()}`);
      
      res.json({
        success: true,
        previewUrl,
        token: tokenResult.token,
        expiresAt: tokenResult.expiresAt.toISOString(),
        expiresIn: tokenResult.expiresIn,
        workspaceSlug,
        botId,
      });
    } catch (error) {
      structuredLogger.error("[Preview Link] Error generating preview link:", error);
      res.status(500).json({ error: "Failed to generate preview link" });
    }
  });

  // Rebuild Knowledge - Re-scrape a bot's website and update knowledge base
  app.post("/api/super-admin/bots/:botId/rebuild-knowledge", requireSuperAdmin, async (req, res) => {
    try {
      const { botId } = req.params;
      const user = req.user;
      
      // Get bot config to find website URL
      const botConfig = await getBotConfigByBotIdAsync(botId) || getBotConfigByBotId(botId);
      if (!botConfig) {
        return res.status(404).json({ error: "Bot not found" });
      }

      const websiteUrl = botConfig.businessProfile?.website;
      if (!websiteUrl) {
        return res.status(400).json({ error: "Bot has no website URL configured. Please add a website URL in the bot settings first." });
      }

      // Use the bot's workspace/client ID for proper scoping
      const workspaceId = (botConfig as any).workspaceId || botConfig.clientId || "default";
      
      // Trigger re-scrape of the website
      structuredLogger.info(`[Rebuild Knowledge] Starting re-scrape for bot ${botId}, URL: ${websiteUrl}`);
      const scrapeResult = await scrapeWebsite(websiteUrl, workspaceId, botId);

      if (!scrapeResult.success) {
        return res.status(500).json({ 
          success: false, 
          error: scrapeResult.error || "Failed to scrape website" 
        });
      }

      // Apply the scraped data to the bot
      const applyResult = await applyScrapedDataToBot(scrapeResult.scrapeId, botId, String(user?.id ?? "admin"));
      
      if (!applyResult.success) {
        return res.status(500).json({ 
          success: false, 
          error: applyResult.error || "Failed to apply scraped data to bot" 
        });
      }

      structuredLogger.info(`[Rebuild Knowledge] Successfully rebuilt knowledge for bot ${botId}`);
      
      res.json({ 
        success: true, 
        message: "Knowledge base rebuilt successfully",
        scrapeId: scrapeResult.scrapeId
      });
    } catch (error) {
      structuredLogger.error("[Rebuild Knowledge] Error:", error);
      res.status(500).json({ error: "Failed to rebuild knowledge base" });
    }
  });

  // Get bot stats for admin dashboard
  app.get("/api/admin/bot-stats", requireSuperAdmin, async (req, res) => {
    try {
      const { botId } = req.query;
      if (!botId || typeof botId !== 'string') {
        return res.status(400).json({ error: "botId is required" });
      }

      // Get bot config to find clientId using DB-aware lookup
      const botConfig = await getBotConfigByBotIdAsync(botId) || getBotConfigByBotId(botId);
      if (!botConfig) {
        return res.status(404).json({ error: `Bot not found: ${botId}` });
      }
      const clientId = botConfig.clientId;

      // Get analytics summary for this bot (already scoped by botId)
      const analytics = await storage.getClientAnalyticsSummary(clientId, botId);
      
      // Get leads count for this bot using direct DB query for accurate count
      let leadsCount = 0;
      let appointmentsCount = 0;
      
      try {
        const leadsResult = await db
          .select({ count: sql<number>`count(*)::int` })
          .from(leads)
          .where(and(
            eq(leads.clientId, clientId),
            eq(leads.botId, botId)
          ));
        leadsCount = leadsResult[0]?.count || 0;
      } catch (e) {
        structuredLogger.error("Error counting leads:", e);
      }
      
      try {
        const appointmentsResult = await db
          .select({ count: sql<number>`count(*)::int` })
          .from(appointments)
          .where(and(
            eq(appointments.clientId, clientId),
            eq(appointments.botId, botId)
          ));
        appointmentsCount = appointmentsResult[0]?.count || 0;
      } catch (e) {
        structuredLogger.error("Error counting appointments:", e);
      }
      
      res.json({
        totalConversations: analytics.totalConversations || 0,
        totalMessages: analytics.totalMessages || 0,
        leadsCollected: leadsCount,
        bookingsInitiated: appointmentsCount,
        avgResponseTime: analytics.avgResponseTimeMs || 0,
      });
    } catch (error) {
      structuredLogger.error("Get bot stats error:", error);
      res.status(500).json({ error: "Failed to get bot stats" });
    }
  });

  // Create a new bot
  app.post("/api/super-admin/bots", requireSuperAdmin, async (req, res) => {
    try {
      // Validate request body
      const validation = validateRequest(createBotBodySchema, req.body);
      if (!validation.success) {
        return res.status(400).json({ error: validation.error });
      }
      const { 
        botId, 
        clientId, 
        name, 
        description, 
        businessProfile, 
        systemPrompt, 
        faqs, 
        rules,
        templateBotId 
      } = validation.data;
      
      // Check if botId already exists
      const existingBot = getBotConfigByBotId(botId);
      if (existingBot) {
        return res.status(409).json({ error: `Bot with ID '${botId}' already exists` });
      }
      
      // If cloning from a template, get the template config from database
      let newConfig: BotConfig;
      
      if (templateBotId) {
        // First try to get template from database (bot_templates table)
        const dbTemplate = await getTemplateById(templateBotId);
        
        // Fall back to bot config file if not in database
        const templateConfig = dbTemplate?.defaultConfig || getBotConfigByBotId(templateBotId);
        
        if (!templateConfig && !dbTemplate) {
          return res.status(404).json({ error: `Template bot not found: ${templateBotId}` });
        }
        
        // Use template data from database or config file
        const templateBusinessProfile = dbTemplate?.defaultConfig?.businessProfile || templateConfig?.businessProfile || {};
        const templateSystemPrompt = dbTemplate?.defaultConfig?.systemPrompt || templateConfig?.systemPrompt;
        const templateFaqs = dbTemplate?.defaultConfig?.faqs || templateConfig?.faqs;
        const templateRules = dbTemplate?.defaultConfig?.rules || templateConfig?.rules;
        const templateName = dbTemplate?.name || templateConfig?.name;
        
        // Clone template - merge businessProfile, inherit systemPrompt/FAQs/rules unless explicitly provided
        const mergedBusinessProfile = {
          ...templateBusinessProfile,
          ...businessProfile,
          businessName: businessProfile?.businessName || name || templateBusinessProfile?.businessName,
          type: businessProfile?.type || dbTemplate?.botType || templateBusinessProfile?.type,
          hours: businessProfile?.hours || templateBusinessProfile?.hours,
          services: (businessProfile?.services?.length ?? 0) > 0 ? businessProfile!.services : templateBusinessProfile?.services,
        };
        
        newConfig = {
          botId,
          clientId,
          name: name || templateName || 'New Bot',
          description: description || `AI assistant based on ${templateName}`,
          businessProfile: mergedBusinessProfile,
          systemPrompt: systemPrompt || templateSystemPrompt || `You are a helpful assistant for ${name}.`,
          faqs: faqs || templateFaqs || [],
          rules: (rules || templateRules || {}) as any,
        };
      } else {
        // Create from scratch with provided values
        const defaultBusinessProfile = {
          businessName: name,
          type: businessProfile?.type || "general",
          location: businessProfile?.location || "",
          phone: businessProfile?.phone || "",
          email: businessProfile?.email || "",
          website: businessProfile?.website || "",
          hours: businessProfile?.hours || { officeHours: "Mon-Fri 9am-5pm" },
          services: businessProfile?.services || [],
        };
        
        const defaultRules = {
          allowedTopics: ["general information", "services", "pricing", "contact methods", "hours of operation"],
          forbiddenTopics: ["medical advice", "legal advice", "financial advice"],
          crisisHandling: {
            onCrisisKeywords: ["emergency", "help me", "urgent"],
            responseTemplate: "If this is an emergency, please call 911 or your local emergency services immediately."
          }
        };
        
        const defaultSystemPrompt = `You are a helpful assistant for ${name}. Provide clear, friendly information about the business, its services, and how customers can get in touch. Be professional and helpful.`;
        
        newConfig = {
          botId,
          clientId,
          name,
          description: description || `AI assistant for ${name}`,
          businessProfile: { ...defaultBusinessProfile, ...businessProfile },
          systemPrompt: systemPrompt || defaultSystemPrompt,
          faqs: faqs || [],
          rules: (rules || defaultRules) as any,
        };
      }
      
      // Create the new bot config (use createBotConfig for new bots)
      const success = createBotConfig(newConfig);
      
      if (success) {
        // Create log directory for the new client
        const logDir = path.join(process.cwd(), 'logs', clientId);
        if (!fs.existsSync(logDir)) {
          fs.mkdirSync(logDir, { recursive: true });
        }
        
        // Automatically register the client if they don't exist
        const clientName = newConfig.businessProfile?.businessName || name;
        const businessType = newConfig.businessProfile?.type || 'general';
        const clientResult = registerClient(clientId, clientName, businessType, botId, 'active');
        
        if (!clientResult.success) {
          structuredLogger.warn(`Warning: Bot created but client registration failed: ${clientResult.error}`);
        }
        
        res.status(201).json({ 
          success: true, 
          config: newConfig,
          client: clientResult.client || null,
          clientRegistered: clientResult.success
        });
      } else {
        res.status(500).json({ error: "Failed to save bot config" });
      }
    } catch (error) {
      structuredLogger.error("Create bot error:", error);
      res.status(500).json({ error: "Failed to create bot" });
    }
  });

  // Get templates from database (for client onboarding wizard)
  app.get("/api/super-admin/templates", requireSuperAdmin, async (req, res) => {
    try {
      const templates = await getAllTemplates();
      res.json(templates.map(t => ({
        id: t.id,
        templateId: t.templateId,
        name: t.name,
        description: t.description,
        botType: t.botType,
        icon: t.icon,
        previewImage: t.previewImage,
        isActive: t.isActive,
        displayOrder: t.displayOrder,
        defaultConfig: t.defaultConfig,
      })));
    } catch (error) {
      structuredLogger.error("Get templates error:", error);
      res.status(500).json({ error: "Failed to fetch templates" });
    }
  });

  // Create client from template (full workflow) - uses DB templates via buildClientFromTemplate
  app.post("/api/super-admin/clients/from-template", requireSuperAdmin, async (req, res) => {
    try {
      // Validate request body with Zod schema
      const validation = validateRequest(createFromTemplateSchema, req.body);
      if (!validation.success) {
        return res.status(400).json({ error: validation.error });
      }
      
      const { templateId, clientId, clientName, type, businessProfile, contact, billing, customFaqs, externalBookingUrl, behaviorPreset, timezone } = validation.data;
      
      // Check if clientId already exists
      const existingClient = getClientById(clientId);
      if (existingClient) {
        return res.status(409).json({ error: `Client with ID '${clientId}' already exists` });
      }
      
      // Get template from database
      const templateRow = await getTemplateById(templateId);
      if (!templateRow) {
        return res.status(404).json({ error: `Template not found: ${templateId}` });
      }
      
      // Validate template has required fields
      const templateValidation = validateTemplateForProvisioning(templateRow);
      if (!templateValidation.valid) {
        return res.status(400).json({ 
          error: "Template validation failed", 
          details: templateValidation.errors 
        });
      }
      
      // Check if bot already exists
      const newBotId = `${clientId}_main`;
      const existingBot = getBotConfigByBotId(newBotId);
      if (existingBot) {
        return res.status(409).json({ error: `Bot with ID '${newBotId}' already exists` });
      }
      
      // Build client configuration using centralized helper
      const overrides: TemplateOverrides = {
        clientId,
        clientName,
        businessProfile: {
          ...businessProfile,
          type: type || businessProfile?.type,
        },
        contact,
        customFaqs,
        plan: billing?.plan,
        externalBookingUrl: externalBookingUrl || undefined,
        behaviorPreset: behaviorPreset || 'support_lead_focused',
        timezone: timezone || 'America/New_York',
      };
      
      const buildResult = buildClientFromTemplate(templateRow, overrides);
      
      if (!buildResult.success) {
        return res.status(400).json({ error: buildResult.error, code: buildResult.code });
      }
      
      const { botConfig, clientSettingsSeed } = buildResult.data;
      
      // Create the new bot config
      const saveSuccess = createBotConfig(botConfig);
      if (!saveSuccess) {
        return res.status(500).json({ error: "Failed to save bot config" });
      }
      
      // Create log directory
      const logDir = path.join(process.cwd(), 'logs', clientId);
      if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
      }
      
      // Register the new client
      const clientResult = registerClient(
        clientId, 
        clientName, 
        clientSettingsSeed.businessType, 
        newBotId, 
        'active'
      );
      
      if (!clientResult.success) {
        return res.status(500).json({ error: clientResult.error || "Failed to register client" });
      }
      
      res.status(201).json({ 
        success: true,
        clientId: clientId,
        client: clientResult.client,
        botId: newBotId,
        config: botConfig,
        seeds: {
          clientSettings: clientSettingsSeed,
          widgetSettings: buildResult.data.widgetSettingsSeed,
          bookingProfile: buildResult.data.bookingProfileSeed,
        },
      });
    } catch (error) {
      structuredLogger.error("Create client from template error:", error);
      res.status(500).json({ error: "Failed to create client from template" });
    }
  });

  // Get client general settings
  app.get("/api/super-admin/clients/:clientId/general", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const settings = await storage.getSettings(clientId);
      res.json({
        businessName: settings?.businessName || '',
        tagline: settings?.tagline || '',
        businessType: settings?.businessType || 'Sober Living',
        primaryPhone: settings?.primaryPhone || '',
        primaryEmail: settings?.primaryEmail || '',
        websiteUrl: settings?.websiteUrl || '',
        city: settings?.city || '',
        state: settings?.state || '',
        timezone: settings?.timezone || 'America/New_York',
        defaultContactMethod: settings?.defaultContactMethod || 'phone',
        internalNotes: settings?.internalNotes || '',
        status: settings?.status || 'active'
      });
    } catch (error) {
      structuredLogger.error("Get general settings error:", error);
      res.status(500).json({ error: "Failed to fetch general settings" });
    }
  });

  // Update client general settings
  app.put("/api/super-admin/clients/:clientId/general", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const { businessName, tagline, businessType, primaryPhone, primaryEmail, 
              websiteUrl, city, state, timezone, defaultContactMethod, internalNotes, status } = req.body;
      
      const settings = await storage.updateSettings(clientId, {
        businessName,
        tagline,
        businessType,
        primaryPhone,
        primaryEmail,
        websiteUrl,
        city,
        state,
        timezone,
        defaultContactMethod,
        internalNotes,
        status
      });
      res.json(settings);
    } catch (error) {
      structuredLogger.error("Update general settings error:", error);
      res.status(400).json({ error: "Failed to update general settings" });
    }
  });

  // Get client knowledge (FAQ entries + long-form sections)
  app.get("/api/super-admin/clients/:clientId/knowledge", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const settings = await storage.getSettings(clientId);
      res.json({
        faqEntries: settings?.faqEntries || [],
        longFormKnowledge: settings?.longFormKnowledge || {
          aboutProgram: '',
          houseRules: '',
          whoItsFor: '',
          paymentInfo: ''
        }
      });
    } catch (error) {
      structuredLogger.error("Get knowledge error:", error);
      res.status(500).json({ error: "Failed to fetch knowledge" });
    }
  });

  // Add FAQ entry
  app.post("/api/super-admin/clients/:clientId/knowledge", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const { category, question, answer, active = true } = req.body;
      
      if (!category || !question || !answer) {
        return res.status(400).json({ error: "Category, question, and answer are required" });
      }
      
      const settings = await storage.getSettings(clientId);
      const faqEntries = settings?.faqEntries || [];
      
      const newEntry = {
        id: `faq-${Date.now()}`,
        category,
        question,
        answer,
        active
      };
      
      const updatedEntries = [...faqEntries, newEntry];
      await storage.updateSettings(clientId, { faqEntries: updatedEntries });
      
      res.json(newEntry);
    } catch (error) {
      structuredLogger.error("Add FAQ error:", error);
      res.status(400).json({ error: "Failed to add FAQ" });
    }
  });

  // Update FAQ entry
  app.put("/api/super-admin/clients/:clientId/knowledge/:faqId", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const settings = await storage.getSettings(clientId);
      const faqEntries = settings?.faqEntries || [];
      
      const faqIndex = faqEntries.findIndex((f: any) => f.id === req.params.faqId);
      if (faqIndex === -1) {
        return res.status(404).json({ error: "FAQ not found" });
      }
      
      const updatedEntry = { ...faqEntries[faqIndex], ...req.body, id: req.params.faqId };
      faqEntries[faqIndex] = updatedEntry;
      
      await storage.updateSettings(clientId, { faqEntries });
      res.json(updatedEntry);
    } catch (error) {
      structuredLogger.error("Update FAQ error:", error);
      res.status(400).json({ error: "Failed to update FAQ" });
    }
  });

  // Delete FAQ entry
  app.delete("/api/super-admin/clients/:clientId/knowledge/:faqId", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const settings = await storage.getSettings(clientId);
      const faqEntries = settings?.faqEntries || [];
      
      const updatedEntries = faqEntries.filter((f: any) => f.id !== req.params.faqId);
      await storage.updateSettings(clientId, { faqEntries: updatedEntries });
      
      res.json({ success: true });
    } catch (error) {
      structuredLogger.error("Delete FAQ error:", error);
      res.status(400).json({ error: "Failed to delete FAQ" });
    }
  });

  // Update long-form knowledge
  app.put("/api/super-admin/clients/:clientId/knowledge/long-form", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const { aboutProgram, houseRules, whoItsFor, paymentInfo } = req.body;
      const settings = await storage.getSettings(clientId);
      
      const longFormKnowledge = {
        aboutProgram: aboutProgram ?? settings?.longFormKnowledge?.aboutProgram ?? '',
        houseRules: houseRules ?? settings?.longFormKnowledge?.houseRules ?? '',
        whoItsFor: whoItsFor ?? settings?.longFormKnowledge?.whoItsFor ?? '',
        paymentInfo: paymentInfo ?? settings?.longFormKnowledge?.paymentInfo ?? ''
      };
      
      await storage.updateSettings(clientId, { longFormKnowledge });
      res.json(longFormKnowledge);
    } catch (error) {
      structuredLogger.error("Update long-form knowledge error:", error);
      res.status(400).json({ error: "Failed to update long-form knowledge" });
    }
  });

  // Get appointment types config
  app.get("/api/super-admin/clients/:clientId/appointment-types", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const settings = await storage.getSettings(clientId);
      res.json(settings?.appointmentTypesConfig || []);
    } catch (error) {
      structuredLogger.error("Get appointment types error:", error);
      res.status(500).json({ error: "Failed to fetch appointment types" });
    }
  });

  // Update appointment types config (batch)
  app.put("/api/super-admin/clients/:clientId/appointment-types", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const appointmentTypesConfig = req.body;
      
      if (!Array.isArray(appointmentTypesConfig)) {
        return res.status(400).json({ error: "Appointment types must be an array" });
      }
      
      await storage.updateSettings(req.params.clientId, { appointmentTypesConfig });
      res.json(appointmentTypesConfig);
    } catch (error) {
      structuredLogger.error("Update appointment types error:", error);
      res.status(400).json({ error: "Failed to update appointment types" });
    }
  });

  // Get pre-intake config
  app.get("/api/super-admin/clients/:clientId/pre-intake", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const settings = await storage.getSettings(clientId);
      res.json(settings?.preIntakeConfig || []);
    } catch (error) {
      structuredLogger.error("Get pre-intake config error:", error);
      res.status(500).json({ error: "Failed to fetch pre-intake config" });
    }
  });

  // Update pre-intake config
  app.put("/api/super-admin/clients/:clientId/pre-intake", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const preIntakeConfig = req.body;
      
      if (!Array.isArray(preIntakeConfig)) {
        return res.status(400).json({ error: "Pre-intake config must be an array" });
      }
      
      await storage.updateSettings(clientId, { preIntakeConfig });
      res.json(preIntakeConfig);
    } catch (error) {
      structuredLogger.error("Update pre-intake config error:", error);
      res.status(400).json({ error: "Failed to update pre-intake config" });
    }
  });

  // Get notification settings
  app.get("/api/super-admin/clients/:clientId/notifications", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const settings = await storage.getSettings(clientId);
      res.json(settings?.notificationSettings || {
        staffEmails: [],
        staffPhones: [],
        staffChannelPreference: 'email_only',
        eventToggles: {
          newAppointmentEmail: true,
          newAppointmentSms: false,
          newPreIntakeEmail: false,
          sameDayReminder: false,
        },
        templates: {
          staffEmailSubject: 'New Appointment Request from {{leadName}}',
          staffEmailBody: 'A new {{appointmentType}} appointment has been requested by {{leadName}} for {{preferredTime}}.',
        },
      });
    } catch (error) {
      structuredLogger.error("Get notification settings error:", error);
      res.status(500).json({ error: "Failed to fetch notification settings" });
    }
  });

  // Update notification settings
  app.put("/api/super-admin/clients/:clientId/notifications", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const notificationSettings = req.body;
      await storage.updateSettings(clientId, { notificationSettings });
      res.json(notificationSettings);
    } catch (error) {
      structuredLogger.error("Update notification settings error:", error);
      res.status(400).json({ error: "Failed to update notification settings" });
    }
  });

  // ============================================
  // CLIENT DASHBOARD ENDPOINTS
  // ============================================

  // Get current client user's profile and business info
  app.get("/api/client/me", requireClientAuth, async (req, res) => {
    try {
      const user = await db.select({
        id: adminUsers.id,
        username: adminUsers.username,
        role: adminUsers.role,
        clientId: adminUsers.clientId,
      }).from(adminUsers).where(eq(adminUsers.id, req.session.userId!)).limit(1);
      
      if (!user[0]) {
        return res.status(404).json({ error: "User not found" });
      }

      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      let botConfig = null;
      let businessInfo = null;

      if (clientId) {
        // Try to find bot config for this client
        const allBots = getAllBotConfigs();
        botConfig = allBots.find(bot => bot.clientId === clientId);
        
        if (botConfig) {
          businessInfo = {
            name: botConfig.businessProfile?.businessName,
            type: botConfig.businessProfile?.type,
            location: botConfig.businessProfile?.location,
            phone: botConfig.businessProfile?.phone,
            hours: botConfig.businessProfile?.hours,
          };
        }
      }

      res.json({
        user: user[0],
        clientId,
        businessInfo,
        botId: botConfig?.botId,
      });
    } catch (error) {
      structuredLogger.error("Get client profile error:", error);
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  // Update client settings (limited fields: phone, hours, location)
  app.patch("/api/client/settings", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { phone, hours, location } = req.body;
      
      // For now, we just log and acknowledge - actual bot config updates would require file writes
      // In a production system, this would update the database or config storage
      structuredLogger.info(`Client ${clientId} settings update request:`, { phone, hours, location });
      
      // Return success - in production this would persist the changes
      res.json({
        success: true,
        message: "Settings update request received",
        updates: { phone, hours, location },
      });
    } catch (error) {
      structuredLogger.error("Update client settings error:", error);
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  // =============================================
  // WEBHOOK SETTINGS ENDPOINTS
  // =============================================

  const webhookSettingsSchema = z.object({
    webhookUrl: z.string().url().nullable().optional(),
    webhookSecret: z.string().min(16).nullable().optional(),
    webhookEnabled: z.boolean().optional(),
    webhookEvents: z.object({
      newLead: z.boolean().optional(),
      newAppointment: z.boolean().optional(),
      chatSessionStart: z.boolean().optional(),
      chatSessionEnd: z.boolean().optional(),
      leadStatusChange: z.boolean().optional(),
    }).optional(),
    externalBookingUrl: z.string().url().nullable().optional(),
    externalPaymentUrl: z.string().url().nullable().optional(),
  });

  // Get webhook settings
  app.get("/api/client/webhooks", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const settings = await storage.getSettings(clientId);
      
      if (!settings) {
        return res.json({
          webhookUrl: null,
          webhookSecret: null,
          webhookEnabled: false,
          webhookEvents: {
            newLead: true,
            newAppointment: true,
            chatSessionStart: false,
            chatSessionEnd: false,
            leadStatusChange: false,
          },
          externalBookingUrl: null,
          externalPaymentUrl: null,
        });
      }
      
      res.json({
        webhookUrl: settings.webhookUrl,
        webhookSecret: settings.webhookSecret ? '********' : null, // Mask the secret
        webhookEnabled: settings.webhookEnabled,
        webhookEvents: settings.webhookEvents ?? {
          newLead: true,
          newAppointment: true,
          chatSessionStart: false,
          chatSessionEnd: false,
          leadStatusChange: false,
        },
        externalBookingUrl: settings.externalBookingUrl,
        externalPaymentUrl: settings.externalPaymentUrl,
      });
    } catch (error) {
      structuredLogger.error("Get webhook settings error:", error);
      res.status(500).json({ error: "Failed to fetch webhook settings" });
    }
  });

  // Update webhook settings
  app.patch("/api/client/webhooks", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      const validation = validateRequest(webhookSettingsSchema, req.body);
      if (!validation.success) {
        return res.status(400).json({ error: validation.error });
      }
      
      const updates: Record<string, any> = {};
      
      if (validation.data.webhookUrl !== undefined) {
        updates.webhookUrl = validation.data.webhookUrl;
      }
      if (validation.data.webhookSecret !== undefined) {
        updates.webhookSecret = validation.data.webhookSecret;
      }
      if (validation.data.webhookEnabled !== undefined) {
        updates.webhookEnabled = validation.data.webhookEnabled;
      }
      if (validation.data.webhookEvents !== undefined) {
        // Merge with existing events
        const currentSettings = await storage.getSettings(clientId);
        const currentEvents = currentSettings?.webhookEvents ?? {
          newLead: true,
          newAppointment: true,
          chatSessionStart: false,
          chatSessionEnd: false,
          leadStatusChange: false,
        };
        updates.webhookEvents = { ...currentEvents, ...validation.data.webhookEvents };
      }
      if (validation.data.externalBookingUrl !== undefined) {
        // Validate booking URL using comprehensive validator (blocks http://, javascript:, payment URLs, etc.)
        if (validation.data.externalBookingUrl && validation.data.externalBookingUrl.trim()) {
          const urlValidation = validateBookingUrl(validation.data.externalBookingUrl);
          if (!urlValidation.valid) {
            return res.status(400).json({ error: `Invalid booking URL: ${urlValidation.error}` });
          }
          updates.externalBookingUrl = urlValidation.url; // Use normalized URL
        } else {
          updates.externalBookingUrl = validation.data.externalBookingUrl;
        }
      }
      if (validation.data.externalPaymentUrl !== undefined) {
        // Basic validation for payment URL - require HTTPS
        if (validation.data.externalPaymentUrl && validation.data.externalPaymentUrl.trim()) {
          try {
            const parsed = new URL(validation.data.externalPaymentUrl);
            if (parsed.protocol !== 'https:') {
              return res.status(400).json({ error: "Payment URL must use HTTPS" });
            }
          } catch {
            return res.status(400).json({ error: "Invalid payment URL format" });
          }
        }
        updates.externalPaymentUrl = validation.data.externalPaymentUrl;
      }
      
      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ error: "No valid updates provided" });
      }
      
      // Ensure client_settings record exists
      let settings = await storage.getSettings(clientId);
      if (!settings) {
        // Create default settings first
        await db.insert(clientSettings).values({
          clientId,
          businessName: 'My Business',
          tagline: 'Welcome!',
          knowledgeBase: { about: '', requirements: '', pricing: '', application: '' },
          operatingHours: {
            enabled: false,
            timezone: 'America/New_York',
            schedule: {
              monday: { open: '09:00', close: '17:00', enabled: true },
              tuesday: { open: '09:00', close: '17:00', enabled: true },
              wednesday: { open: '09:00', close: '17:00', enabled: true },
              thursday: { open: '09:00', close: '17:00', enabled: true },
              friday: { open: '09:00', close: '17:00', enabled: true },
              saturday: { open: '10:00', close: '14:00', enabled: false },
              sunday: { open: '10:00', close: '14:00', enabled: false },
            },
            afterHoursMessage: 'We are currently closed. Please leave a message.'
          },
        });
      }
      
      const updated = await storage.updateSettings(clientId, updates as any);
      
      res.json({
        success: true,
        webhookUrl: updated.webhookUrl,
        webhookSecret: updated.webhookSecret ? '********' : null,
        webhookEnabled: updated.webhookEnabled,
        webhookEvents: updated.webhookEvents,
        externalBookingUrl: updated.externalBookingUrl,
        externalPaymentUrl: updated.externalPaymentUrl,
      });
    } catch (error) {
      structuredLogger.error("Update webhook settings error:", error);
      res.status(500).json({ error: "Failed to update webhook settings" });
    }
  });

  // Test webhook endpoint
  app.post("/api/client/webhooks/test", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const result = await testWebhook(clientId);
      
      if (result.success) {
        res.json({
          success: true,
          message: `Test webhook delivered successfully (HTTP ${result.statusCode})`,
          statusCode: result.statusCode,
        });
      } else {
        res.status(400).json({
          success: false,
          error: result.error,
          statusCode: result.statusCode,
        });
      }
    } catch (error) {
      structuredLogger.error("Test webhook error:", error);
      res.status(500).json({ error: "Failed to test webhook" });
    }
  });

  // Generate new webhook secret
  app.post("/api/client/webhooks/generate-secret", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const newSecret = crypto.randomBytes(32).toString('hex');
      
      await storage.updateSettings(clientId, { webhookSecret: newSecret } as any);
      
      res.json({
        success: true,
        webhookSecret: newSecret,
        message: "New webhook secret generated. Save this value - it will only be shown once.",
      });
    } catch (error) {
      structuredLogger.error("Generate webhook secret error:", error);
      res.status(500).json({ error: "Failed to generate webhook secret" });
    }
  });

  // Get client dashboard stats
  app.get("/api/client/stats", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      // Parse optional days parameter (7, 30, or all)
      const daysParam = req.query.days as string | undefined;
      const days = daysParam === '7' ? 7 : daysParam === '30' ? 30 : null;
      
      // Get bot config for this client (use async to include database-only bots)
      const allBots = await getAllBotConfigsAsync();
      const botConfig = allBots.find(bot => bot.clientId === clientId);
      
      if (!botConfig) {
        return res.status(404).json({ error: "No bot found for this client" });
      }

      // Get conversation stats from file-based logs
      const logStats = getLogStats(clientId);
      
      // Get database stats using the CORRECT tables (chatSessions, not conversation_analytics)
      const appointments = await storage.getAllAppointments(clientId);
      const leadsData = await storage.getLeads(clientId);
      const leads = leadsData?.leads || [];
      
      const now = new Date();
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const weekAgo = new Date(todayStart.getTime() - 7 * 24 * 60 * 60 * 1000);
      const cutoffDate = days ? new Date(todayStart.getTime() - days * 24 * 60 * 60 * 1000) : null;
      const previousPeriodStart = days ? new Date(cutoffDate!.getTime() - days * 24 * 60 * 60 * 1000) : null;
      
      // Use proper AGGREGATED analytics from chatSessions table (no limit truncation)
      // All-time summary
      const analyticsSummary = await storage.getClientAnalyticsSummary(clientId, botConfig.botId);
      // Weekly summary for weekly stats
      const weeklySummary = await storage.getClientAnalyticsSummary(clientId, botConfig.botId, weekAgo);
      // Period-specific summaries for range stats
      const currentPeriodSummary = cutoffDate 
        ? await storage.getClientAnalyticsSummary(clientId, botConfig.botId, cutoffDate) 
        : null;
      const previousPeriodSummary = previousPeriodStart && cutoffDate
        ? await storage.getClientAnalyticsSummary(clientId, botConfig.botId, previousPeriodStart, cutoffDate)
        : null;
      
      // Get recent sessions for last activity and peak hours (sample, not totals)
      const recentSessions = await storage.getClientRecentSessions(clientId, botConfig.botId, 100);
      const dailyTrends = await storage.getClientDailyTrends(clientId, botConfig.botId, 30);
      
      // Get client settings for notification email
      const settings = await storage.getSettings(clientId);
      
      // Calculate filtered stats based on date range
      const filterByDate = (items: any[], dateField: string = 'createdAt') => {
        if (!cutoffDate) return items;
        return items.filter((item: any) => {
          const itemDate = item[dateField] ? new Date(item[dateField]) : null;
          return itemDate && itemDate >= cutoffDate;
        });
      };
      
      // Filter for previous period (for trend calculation)
      const filterByPreviousPeriod = (items: any[], dateField: string = 'createdAt') => {
        if (!previousPeriodStart || !cutoffDate) return [];
        return items.filter((item: any) => {
          const itemDate = item[dateField] ? new Date(item[dateField]) : null;
          return itemDate && itemDate >= previousPeriodStart && itemDate < cutoffDate;
        });
      };
      
      const filteredAppointments = filterByDate(appointments);
      const filteredLeads = filterByDate(leads);
      
      // Previous period data for trends (leads and appointments only - sessions use aggregates)
      const prevAppointments = filterByPreviousPeriod(appointments);
      const prevLeads = filterByPreviousPeriod(leads);
      
      // Calculate peak hours from recent sessions (sample-based, acceptable for peak hours)
      const hourCounts: Record<number, number> = {};
      recentSessions.forEach((session: any) => {
        const hour = new Date(session.startedAt).getHours();
        hourCounts[hour] = (hourCounts[hour] || 0) + 1;
      });
      const peakHoursData = Object.entries(hourCounts)
        .map(([hour, count]) => ({ hour: parseInt(hour), count }))
        .sort((a, b) => b.count - a.count);
      
      // Lead status breakdown
      const leadStatusBreakdown = {
        new: leads.filter((l: any) => l.status === 'new').length,
        contacted: leads.filter((l: any) => l.status === 'contacted').length,
        qualified: leads.filter((l: any) => l.status === 'qualified').length,
        converted: leads.filter((l: any) => l.status === 'converted').length,
        lost: leads.filter((l: any) => l.status === 'lost').length,
      };
      
      // Find last activity timestamp from sessions
      const lastSession = recentSessions.length > 0 ? recentSessions[0] : null;
      const lastAppointment = appointments.length > 0
        ? appointments.reduce((latest: any, curr: any) =>
            new Date(curr.createdAt) > new Date(latest.createdAt) ? curr : latest
          )
        : null;
      const lastLead = leads.length > 0
        ? leads.reduce((latest: any, curr: any) =>
            new Date(curr.createdAt) > new Date(latest.createdAt) ? curr : latest
          )
        : null;
      
      const lastActivityDates = [
        lastSession?.startedAt,
        lastAppointment?.createdAt,
        lastLead?.createdAt,
      ].filter(d => d != null).map(d => new Date(d as any));
      
      const lastActivity = lastActivityDates.length > 0
        ? new Date(Math.max(...lastActivityDates.map(d => d.getTime()))).toISOString()
        : null;
      
      // All-time stats using AGGREGATED data (no truncation)
      const dbStats = {
        totalAppointments: appointments.length,
        pendingAppointments: appointments.filter((a: any) => a.status === "new" || a.status === "pending").length,
        completedAppointments: appointments.filter((a: any) => a.status === "confirmed" || a.status === "completed").length,
        totalConversations: analyticsSummary.totalConversations,
        totalMessages: analyticsSummary.totalMessages,
        weeklyConversations: weeklySummary.totalConversations,
        totalLeads: leads.length,
        newLeads: leads.filter((l: any) => l.status === 'new').length,
        crisisEvents: analyticsSummary.crisisEvents,
        appointmentRequests: analyticsSummary.appointmentRequests,
        avgResponseTimeMs: analyticsSummary.avgResponseTimeMs,
      };
      
      // Current period stats using aggregated summaries (not truncated arrays)
      const currentConversations = currentPeriodSummary?.totalConversations || 0;
      const currentLeads = filteredLeads.length;
      const currentBookings = filteredAppointments.length;
      
      // Previous period stats for trend calculation
      const prevConversations = previousPeriodSummary?.totalConversations || 0;
      const prevLeadsCount = prevLeads.length;
      const prevBookingsCount = prevAppointments.length;
      
      // Calculate trend percentages
      const calcTrend = (current: number, previous: number): number => {
        if (previous === 0) return current > 0 ? 100 : 0;
        return Math.round(((current - previous) / previous) * 100);
      };
      
      // Range-filtered stats (null if no range specified)
      const rangeStats = cutoffDate ? {
        days,
        conversations: currentConversations,
        leads: currentLeads,
        newLeads: filteredLeads.filter((l: any) => l.status === 'new').length,
        bookings: currentBookings,
        pendingBookings: filteredAppointments.filter((a: any) => a.status === "new" || a.status === "pending").length,
        completedBookings: filteredAppointments.filter((a: any) => a.status === "confirmed" || a.status === "completed").length,
        // Trend data
        conversationsTrend: calcTrend(currentConversations, prevConversations),
        leadsTrend: calcTrend(currentLeads, prevLeadsCount),
        bookingsTrend: calcTrend(currentBookings, prevBookingsCount),
      } : null;
      
      // Topic breakdown from analytics summary
      const topTopics = Object.entries(analyticsSummary.topicBreakdown)
        .map(([topic, count]) => ({ topic, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);
      
      // Fetch workspace info including isDemo flag
      const [workspaceInfo] = await db.select({
        id: workspaces.id,
        name: workspaces.name,
        slug: workspaces.slug,
        isDemo: workspaces.isDemo,
        status: workspaces.status,
      })
        .from(workspaces)
        .where(eq(workspaces.slug, clientId))
        .limit(1);
      
      // Calculate overview stats for 7-day and 30-day periods (always included)
      const thirtyDaysAgo = new Date(todayStart.getTime() - 30 * 24 * 60 * 60 * 1000);
      const sevenDaysAgo = new Date(todayStart.getTime() - 7 * 24 * 60 * 60 * 1000);
      
      // Get summaries for both periods
      const sevenDaySummary = await storage.getClientAnalyticsSummary(clientId, botConfig.botId, sevenDaysAgo);
      const thirtyDaySummary = await storage.getClientAnalyticsSummary(clientId, botConfig.botId, thirtyDaysAgo);
      
      // Filter leads and bookings for each period
      const leads7Days = leads.filter((l: any) => {
        const d = l.createdAt ? new Date(l.createdAt) : null;
        return d && d >= sevenDaysAgo;
      }).length;
      const leads30Days = leads.filter((l: any) => {
        const d = l.createdAt ? new Date(l.createdAt) : null;
        return d && d >= thirtyDaysAgo;
      }).length;
      const bookings7Days = appointments.filter((a: any) => {
        const d = a.createdAt ? new Date(a.createdAt) : null;
        return d && d >= sevenDaysAgo;
      }).length;
      const bookings30Days = appointments.filter((a: any) => {
        const d = a.createdAt ? new Date(a.createdAt) : null;
        return d && d >= thirtyDaysAgo;
      }).length;
      
      const overview = {
        conversations7Days: sevenDaySummary.totalConversations,
        conversations30Days: thirtyDaySummary.totalConversations,
        leads7Days,
        leads30Days,
        bookings7Days,
        bookings30Days,
        // Additional breakdown
        newLeads7Days: leads.filter((l: any) => {
          const d = l.createdAt ? new Date(l.createdAt) : null;
          return d && d >= sevenDaysAgo && l.status === 'new';
        }).length,
        pendingBookings7Days: appointments.filter((a: any) => {
          const d = a.createdAt ? new Date(a.createdAt) : null;
          return d && d >= sevenDaysAgo && (a.status === 'new' || a.status === 'pending');
        }).length,
      };

      res.json({
        clientId,
        botId: botConfig.botId,
        businessName: botConfig.businessProfile?.businessName,
        businessType: botConfig.businessProfile?.type,
        logStats,
        dbStats,
        rangeStats,
        // Additional dashboard data
        peakHours: peakHoursData.slice(0, 5), // Top 5 peak hours
        leadStatusBreakdown,
        lastActivity,
        notificationEmail: settings?.notificationEmail || null,
        topTopics,
        dailyTrends: dailyTrends.map(d => ({
          date: d.date,
          conversations: d.totalConversations,
          messages: d.totalMessages,
          appointmentRequests: d.appointmentRequests,
        })),
        // Workspace metadata for demo/live distinction
        workspace: workspaceInfo ? {
          id: workspaceInfo.id,
          name: workspaceInfo.name,
          isDemo: workspaceInfo.isDemo ?? false,
          status: workspaceInfo.status,
        } : null,
        // Overview metrics for dashboard cards
        overview,
      });
    } catch (error) {
      structuredLogger.error("Get client stats error:", error);
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // Get client's conversation logs
  app.get("/api/client/conversations", requireClientAuth, async (req, res) => {
    try {
      // Validate query params
      const queryValidation = validateRequest(conversationsQuerySchema, req.query);
      if (!queryValidation.success) {
        return res.status(400).json({ error: queryValidation.error });
      }
      
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { limit, offset } = queryValidation.data;
      
      // Get bot config for this client
      const allBots = getAllBotConfigs();
      const botConfig = allBots.find(bot => bot.clientId === clientId);
      
      if (!botConfig) {
        return res.status(404).json({ error: "No bot found for this client" });
      }

      // Get conversations from file-based logs
      const logs = getConversationLogs(clientId, botConfig.botId);
      
      // Get database analytics for any valid client
      const analytics = await storage.getAnalytics(clientId);
      
      // Group by sessionId to create conversation threads
      const sessionMap = new Map<string, any[]>();
      analytics.forEach(msg => {
        if (!sessionMap.has(msg.sessionId)) {
          sessionMap.set(msg.sessionId, []);
        }
        sessionMap.get(msg.sessionId)!.push(msg);
      });
      
      const dbConversations = Array.from(sessionMap.entries())
        .map(([sessionId, messages]) => ({
          sessionId,
          messageCount: messages.length,
          firstMessage: messages[0]?.createdAt,
          lastMessage: messages[messages.length - 1]?.createdAt,
          preview: messages[0]?.content?.substring(0, 100),
        }))
        .sort((a, b) => new Date(b.lastMessage).getTime() - new Date(a.lastMessage).getTime())
        .slice(offset as number, (offset as number) + (limit as number));

      res.json({
        clientId,
        botId: botConfig.botId,
        fileLogs: logs,
        dbConversations,
      });
    } catch (error) {
      structuredLogger.error("Get client conversations error:", error);
      res.status(500).json({ error: "Failed to fetch conversations" });
    }
  });

  // Get client's appointments (for business types that support them)
  app.get("/api/client/appointments", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      // Get appointments for any valid client
      const appointments = await storage.getAllAppointments(clientId);
      
      // Sort by creation date, most recent first
      const sortedAppointments = appointments.sort(
        (a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );

      res.json({
        clientId,
        appointments: sortedAppointments,
        total: appointments.length,
      });
    } catch (error) {
      structuredLogger.error("Get client appointments error:", error);
      res.status(500).json({ error: "Failed to fetch appointments" });
    }
  });

  // Get bot configuration for the client (read-only view)
  app.get("/api/client/bot-config", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      const allBots = getAllBotConfigs();
      const botConfig = allBots.find(bot => bot.clientId === clientId);
      
      if (!botConfig) {
        return res.status(404).json({ error: "No bot found for this client" });
      }

      // Return a safe subset of the config (no internal prompts)
      res.json({
        botId: botConfig.botId,
        clientId: botConfig.clientId,
        businessName: botConfig.businessProfile?.businessName,
        businessType: botConfig.businessProfile?.type,
        businessProfile: botConfig.businessProfile,
        metadata: botConfig.metadata,
        faqs: botConfig.faqs,
      });
    } catch (error) {
      structuredLogger.error("Get client bot config error:", error);
      res.status(500).json({ error: "Failed to fetch bot configuration" });
    }
  });

  // =============================================
  // CLIENT ANALYTICS ENDPOINTS
  // =============================================

  // Get analytics summary for client's bot
  app.get("/api/client/analytics/summary", requireClientAuth, async (req, res) => {
    try {
      // Validate query params
      const querySchema = z.object({
        botId: z.string().optional(),
        startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be YYYY-MM-DD format").optional(),
        endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be YYYY-MM-DD format").optional(),
      });
      const queryValidation = validateRequest(querySchema, req.query);
      if (!queryValidation.success) {
        return res.status(400).json({ error: queryValidation.error });
      }
      
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { botId, startDate, endDate } = queryValidation.data;
      const start = startDate ? new Date(startDate) : undefined;
      const end = endDate ? new Date(endDate) : undefined;
      
      const summary = await storage.getClientAnalyticsSummary(clientId, botId, start, end);
      
      // Get leads and appointments counts for last 7 days
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      
      const { leads } = await storage.getLeads(clientId, { limit: 10000 });
      const allAppointments = await storage.getAllAppointments(clientId);
      
      // Count items from last 7 days
      const leadsLast7d = leads.filter((l: any) => {
        const created = new Date(l.createdAt);
        return created >= sevenDaysAgo;
      }).length;
      
      const bookingsLast7d = allAppointments.filter((a: any) => {
        const created = new Date(a.createdAt);
        return created >= sevenDaysAgo;
      }).length;
      
      // Count messages from conversations in last 7 days
      const messagesLast7d = summary.totalMessages;
      
      res.json({
        clientId,
        botId: botId || 'all',
        ...summary,
        leadsLast7d,
        bookingsLast7d,
        messagesLast7d,
      });
    } catch (error) {
      structuredLogger.error("Get client analytics summary error:", error);
      res.status(500).json({ error: "Failed to fetch analytics summary" });
    }
  });

  // Get daily analytics trends for client
  app.get("/api/client/analytics/trends", requireClientAuth, async (req, res) => {
    try {
      // Validate query params
      const queryValidation = validateRequest(analyticsTrendsQuerySchema, req.query);
      if (!queryValidation.success) {
        return res.status(400).json({ error: queryValidation.error });
      }
      
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { botId, days } = queryValidation.data as { botId?: string; days: number };
      
      const trends = await storage.getClientDailyTrends(clientId, botId, days);
      
      // Fill in missing days with zeros
      const now = new Date();
      const filledTrends: any[] = [];
      for (let i = days - 1; i >= 0; i--) {
        const date = new Date(now);
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        
        const existing = trends.find(t => t.date === dateStr);
        if (existing) {
          filledTrends.push(existing);
        } else {
          filledTrends.push({
            date: dateStr,
            clientId,
            botId: botId || 'all',
            totalConversations: 0,
            totalMessages: 0,
            userMessages: 0,
            botMessages: 0,
            avgResponseTimeMs: 0,
            crisisEvents: 0,
            appointmentRequests: 0,
          });
        }
      }
      
      res.json({
        clientId,
        botId: botId || 'all',
        days,
        trends: filledTrends,
      });
    } catch (error) {
      structuredLogger.error("Get client analytics trends error:", error);
      res.status(500).json({ error: "Failed to fetch analytics trends" });
    }
  });

  // Get recent chat sessions for client
  app.get("/api/client/analytics/sessions", requireClientAuth, async (req, res) => {
    try {
      // Validate query params
      const queryValidation = validateRequest(analyticsSessionsQuerySchema, req.query);
      if (!queryValidation.success) {
        return res.status(400).json({ error: queryValidation.error });
      }
      
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { botId, limit } = queryValidation.data as { botId?: string; limit: number };
      
      const sessions = await storage.getClientRecentSessions(clientId, botId, limit);
      
      res.json({
        clientId,
        botId: botId || 'all',
        sessions,
        total: sessions.length,
      });
    } catch (error) {
      structuredLogger.error("Get client analytics sessions error:", error);
      res.status(500).json({ error: "Failed to fetch chat sessions" });
    }
  });

  // Get top questions/topics for client - analyzes conversation themes
  app.get("/api/client/analytics/top-questions", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const days = parseInt(req.query.days as string) || 30;
      const limit = parseInt(req.query.limit as string) || 10;
      
      // Get bot for this client
      const allBots = getAllBotConfigs();
      const botConfig = allBots.find(bot => bot.clientId === clientId);
      const botId = botConfig?.botId;
      
      // Get recent sessions with their topics
      const cutoffDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
      const allSessions = await storage.getClientRecentSessions(clientId, botId, 500);
      
      // Filter sessions by the cutoff date
      const sessions = allSessions.filter(session => {
        const sessionDate = new Date(session.startedAt);
        return sessionDate >= cutoffDate;
      });
      
      // Aggregate topic frequencies
      const topicCounts: Record<string, number> = {};
      
      sessions.forEach(session => {
        // Get topics from session topics array
        const topics = (session.topics as string[]) || [];
        topics.forEach(topic => {
          if (topic && topic.trim()) {
            const normalizedTopic = topic.toLowerCase().trim();
            topicCounts[normalizedTopic] = (topicCounts[normalizedTopic] || 0) + 1;
          }
        });
        
        // Also check metadata for keyTopics if available
        const metadata = session.metadata as any;
        if (metadata?.keyTopics) {
          const keyTopics = Array.isArray(metadata.keyTopics) ? metadata.keyTopics : [];
          keyTopics.forEach((topic: string) => {
            if (topic && topic.trim()) {
              const normalizedTopic = topic.toLowerCase().trim();
              topicCounts[normalizedTopic] = (topicCounts[normalizedTopic] || 0) + 1;
            }
          });
        }
        
        // Also count user intent if available
        if (metadata?.userIntent && metadata.userIntent.trim()) {
          const normalizedIntent = metadata.userIntent.toLowerCase().trim();
          topicCounts[normalizedIntent] = (topicCounts[normalizedIntent] || 0) + 1;
        }
      });
      
      // Sort by frequency and take top N
      const topQuestions = Object.entries(topicCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, limit)
        .map(([topic, count]) => ({
          topic: topic.charAt(0).toUpperCase() + topic.slice(1),
          count,
          percentage: Math.round((count / sessions.length) * 100) || 0,
        }));
      
      res.json({
        clientId,
        days,
        totalSessions: sessions.length,
        topQuestions,
      });
    } catch (error) {
      structuredLogger.error("Get client top questions error:", error);
      res.status(500).json({ error: "Failed to fetch top questions" });
    }
  });

  // =============================================
  // CLIENT ANALYTICS EXPORT ENDPOINTS
  // =============================================

  // Export client analytics trends to CSV
  app.get("/api/client/analytics/export", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const queryValidation = validateRequest(analyticsTrendsQuerySchema, req.query);
      if (!queryValidation.success) {
        return res.status(400).json({ error: queryValidation.error });
      }
      
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { botId, days } = queryValidation.data as { botId?: string; days: number };
      
      const trends = await storage.getClientDailyTrends(clientId, botId, days);
      const summary = await storage.getClientAnalyticsSummary(clientId, botId);
      
      // Build CSV content
      const headers = ['Date', 'Conversations', 'Messages', 'User Messages', 'Bot Messages', 'Crisis Events', 'Appointments'];
      const rows = trends.map(day => [
        day.date,
        day.totalConversations.toString(),
        day.totalMessages.toString(),
        day.userMessages.toString(),
        day.botMessages.toString(),
        day.crisisEvents.toString(),
        day.appointmentRequests.toString()
      ]);

      const csvContent = [
        headers.join(','),
        ...rows.map(row => row.join(','))
      ].join('\n');

      // Add summary
      const summarySection = `\n\nSummary\nTotal Conversations,${summary.totalConversations}\nTotal Messages,${summary.totalMessages}\nUser Messages,${summary.userMessages}\nBot Messages,${summary.botMessages}\nAvg Response Time (ms),${summary.avgResponseTimeMs}\nCrisis Events,${summary.crisisEvents}\nAppointment Requests,${summary.appointmentRequests}`;

      const fileName = `analytics_${clientId}_last${days}days.csv`;
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.send(csvContent + summarySection);
    } catch (error) {
      structuredLogger.error("Export client analytics error:", error);
      res.status(500).json({ error: "Failed to export analytics" });
    }
  });

  // Export leads to CSV
  app.get("/api/client/leads/export", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { leads } = await storage.getLeads(clientId, { limit: 10000 });
      
      // Build CSV content
      const headers = ['Name', 'Email', 'Phone', 'Status', 'Priority', 'Source', 'Created At', 'Last Contacted'];
      const rows = leads.map(lead => [
        `"${(lead.name || '').replace(/"/g, '""')}"`,
        lead.email || '',
        lead.phone || '',
        lead.status,
        lead.priority,
        lead.source,
        lead.createdAt ? new Date(lead.createdAt).toISOString() : '',
        lead.lastContactedAt ? new Date(lead.lastContactedAt).toISOString() : ''
      ]);

      const csvContent = [
        headers.join(','),
        ...rows.map(row => row.join(','))
      ].join('\n');

      const fileName = `leads_${clientId}_${new Date().toISOString().split('T')[0]}.csv`;
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.send(csvContent);
    } catch (error) {
      structuredLogger.error("Export leads error:", error);
      res.status(500).json({ error: "Failed to export leads" });
    }
  });

  // Export sessions to CSV
  app.get("/api/client/analytics/sessions/export", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const queryValidation = validateRequest(analyticsSessionsQuerySchema, req.query);
      if (!queryValidation.success) {
        return res.status(400).json({ error: queryValidation.error });
      }
      
      const { botId, limit } = queryValidation.data as { botId?: string; limit: number };
      const sessions = await storage.getClientRecentSessions(clientId, botId, limit);
      
      // Build CSV content
      const headers = ['Session ID', 'Bot ID', 'Started At', 'User Messages', 'Bot Messages', 'Crisis Detected', 'Appointment Requested', 'Topics'];
      const rows = sessions.map(session => [
        session.sessionId,
        session.botId,
        session.startedAt ? new Date(session.startedAt).toISOString() : '',
        session.userMessageCount.toString(),
        session.botMessageCount.toString(),
        session.crisisDetected ? 'Yes' : 'No',
        session.appointmentRequested ? 'Yes' : 'No',
        `"${(session.topics as string[] || []).join(', ')}"`
      ]);

      const csvContent = [
        headers.join(','),
        ...rows.map(row => row.join(','))
      ].join('\n');

      const fileName = `sessions_${clientId}_${new Date().toISOString().split('T')[0]}.csv`;
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.send(csvContent);
    } catch (error) {
      structuredLogger.error("Export sessions error:", error);
      res.status(500).json({ error: "Failed to export sessions" });
    }
  });

  // =============================================
  // CLIENT INBOX ENDPOINTS
  // =============================================

  // Get messages for a specific session
  app.get("/api/client/inbox/sessions/:sessionId", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { sessionId } = req.params;
      
      const rawMessages = await storage.getSessionMessages(sessionId, clientId);
      
      // Return messages with properties that frontend expects (ChatAnalyticsEvent interface)
      const messages = rawMessages.map((msg) => ({
        id: msg.id,
        sessionId: msg.sessionId,
        botId: msg.botId,
        actor: msg.actor,
        messageContent: msg.messageContent || '',
        createdAt: msg.createdAt,
      }));
      
      res.json({
        clientId,
        sessionId,
        messages,
        total: messages.length,
      });
    } catch (error) {
      structuredLogger.error("Get session messages error:", error);
      res.status(500).json({ error: "Failed to fetch session messages" });
    }
  });

  // =============================================
  // CONVERSATION NOTES ENDPOINTS
  // =============================================

  const createNoteSchema = z.object({
    sessionId: z.string().min(1),
    botId: z.string().min(1),
    content: z.string().min(1),
    isPinned: z.boolean().optional(),
  });

  // Get notes for a session
  app.get("/api/client/inbox/sessions/:sessionId/notes", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { sessionId } = req.params;
      
      const notes = await storage.getConversationNotes(sessionId, clientId);
      res.json({ notes });
    } catch (error) {
      structuredLogger.error("Get notes error:", error);
      res.status(500).json({ error: "Failed to fetch notes" });
    }
  });

  // Create a note
  app.post("/api/client/inbox/sessions/:sessionId/notes", requireClientAuth, requireOperationalAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { sessionId } = req.params;
      const user = req.user;
      
      const bodyValidation = validateRequest(createNoteSchema, { ...req.body, sessionId });
      if (!bodyValidation.success) {
        return res.status(400).json({ error: bodyValidation.error });
      }
      
      const note = await storage.createConversationNote({
        sessionId,
        clientId,
        botId: bodyValidation.data.botId,
        content: bodyValidation.data.content,
        authorId: String(user?.id ?? 'unknown'),
        authorName: user?.username || 'Unknown User',
        isPinned: bodyValidation.data.isPinned || false,
      });
      
      res.status(201).json(note);
    } catch (error) {
      structuredLogger.error("Create note error:", error);
      res.status(500).json({ error: "Failed to create note" });
    }
  });

  // Update a note
  app.patch("/api/client/inbox/notes/:noteId", requireClientAuth, requireOperationalAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { noteId } = req.params;
      const { content, isPinned } = req.body;
      
      const updates: any = {};
      if (content !== undefined) updates.content = content;
      if (isPinned !== undefined) updates.isPinned = isPinned;
      
      // Pass clientId for tenant verification
      const note = await storage.updateConversationNote(noteId, clientId, updates);
      res.json(note);
    } catch (error: any) {
      if (error.message === 'Note not found or access denied') {
        return res.status(404).json({ error: "Note not found" });
      }
      structuredLogger.error("Update note error:", error);
      res.status(500).json({ error: "Failed to update note" });
    }
  });

  // Delete a note
  app.delete("/api/client/inbox/notes/:noteId", requireClientAuth, requireDestructiveAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      // Pass clientId for tenant verification
      await storage.deleteConversationNote(req.params.noteId, clientId);
      res.status(204).send();
    } catch (error: any) {
      if (error.message === 'Note not found or access denied') {
        return res.status(404).json({ error: "Note not found" });
      }
      structuredLogger.error("Delete note error:", error);
      res.status(500).json({ error: "Failed to delete note" });
    }
  });

  // =============================================
  // SESSION STATE ENDPOINTS
  // =============================================

  // Get or create session state
  app.get("/api/client/inbox/sessions/:sessionId/state", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { sessionId } = req.params;
      const { botId } = req.query;
      
      const state = await storage.getOrCreateSessionState(
        sessionId, 
        clientId, 
        (botId as string) || 'unknown'
      );
      res.json(state);
    } catch (error) {
      structuredLogger.error("Get session state error:", error);
      res.status(500).json({ error: "Failed to fetch session state" });
    }
  });

  // Update session state (mark as read, change status, etc.)
  app.patch("/api/client/inbox/sessions/:sessionId/state", requireClientAuth, requireOperationalAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { sessionId } = req.params;
      const user = req.user;
      const { status, isRead, priority, assignedToUserId, tags } = req.body;
      
      const updates: any = {};
      if (status !== undefined) updates.status = status;
      if (isRead !== undefined) {
        updates.isRead = isRead;
        if (isRead) {
          updates.readAt = new Date();
          updates.readByUserId = user?.id;
        }
      }
      if (priority !== undefined) updates.priority = priority;
      if (assignedToUserId !== undefined) {
        updates.assignedToUserId = assignedToUserId;
        updates.assignedAt = new Date();
      }
      if (tags !== undefined) updates.tags = tags;
      
      // Pass clientId for tenant verification
      const state = await storage.updateSessionState(sessionId, clientId, updates);
      res.json(state);
    } catch (error: any) {
      if (error.message === 'Session state not found or access denied') {
        return res.status(404).json({ error: "Session not found" });
      }
      structuredLogger.error("Update session state error:", error);
      res.status(500).json({ error: "Failed to update session state" });
    }
  });

  // Get all session states for filtering
  app.get("/api/client/inbox/states", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { status, isRead, assignedToUserId } = req.query;
      
      const states = await storage.getSessionStates(clientId, {
        status: status as string | undefined,
        isRead: isRead === 'true' ? true : isRead === 'false' ? false : undefined,
        assignedToUserId: assignedToUserId as string | undefined,
      });
      
      res.json({ states });
    } catch (error) {
      structuredLogger.error("Get session states error:", error);
      res.status(500).json({ error: "Failed to fetch session states" });
    }
  });

  // Get client usage summary (plan limits and current usage)
  app.get("/api/client/usage", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const usageSummary = await getUsageSummary(clientId);
      
      res.json({
        clientId,
        ...usageSummary,
      });
    } catch (error) {
      structuredLogger.error("Get client usage error:", error);
      res.status(500).json({ error: "Failed to fetch usage summary" });
    }
  });

  // =============================================
  // CLIENT ACCOUNT SETTINGS ENDPOINTS
  // =============================================

  // Zod schemas for account settings
  const passwordChangeSchema = z.object({
    currentPassword: z.string().min(1, "Current password is required"),
    newPassword: strongPasswordSchema,
  });

  const notificationUpdateSchema = z.object({
    notificationEmail: z.string().email().nullable().optional(),
    notificationPhone: z.string().nullable().optional(),
    enableEmailNotifications: z.boolean().optional(),
    enableSmsNotifications: z.boolean().optional(),
    notificationSettings: z.object({
      staffEmails: z.array(z.string().email()).optional(),
      staffPhones: z.array(z.string()).optional(),
      staffChannelPreference: z.enum(['email_only', 'sms_only', 'email_and_sms']).optional(),
      eventToggles: z.object({
        newAppointmentEmail: z.boolean().optional(),
        newAppointmentSms: z.boolean().optional(),
        newPreIntakeEmail: z.boolean().optional(),
        sameDayReminder: z.boolean().optional(),
      }).optional(),
    }).optional(),
  });

  // Change password (self-service)
  app.post("/api/client/account/password", requireClientAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      
      // Validate request body
      const bodyValidation = validateRequest(passwordChangeSchema, req.body);
      if (!bodyValidation.success) {
        return res.status(400).json({ error: bodyValidation.error });
      }
      
      const { currentPassword, newPassword } = bodyValidation.data;

      // Get current user
      const [user] = await db.select().from(adminUsers).where(eq(adminUsers.id, userId!)).limit(1);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Verify current password
      const isValid = await bcrypt.compare(currentPassword, user.passwordHash);
      if (!isValid) {
        return res.status(401).json({ error: "Current password is incorrect" });
      }

      // Hash and update new password
      const newPasswordHash = await bcrypt.hash(newPassword, 10);
      await db.update(adminUsers)
        .set({ passwordHash: newPasswordHash })
        .where(eq(adminUsers.id, userId!));

      res.json({ success: true, message: "Password updated successfully" });
    } catch (error) {
      structuredLogger.error("Change password error:", error);
      res.status(500).json({ error: "Failed to change password" });
    }
  });

  // Get notification preferences
  app.get("/api/client/notifications", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }

      const [settings] = await db.select().from(clientSettings).where(eq(clientSettings.clientId, clientId)).limit(1);
      if (!settings) {
        return res.json({
          clientId,
          notificationEmail: null,
          notificationPhone: null,
          enableEmailNotifications: false,
          enableSmsNotifications: false,
          notificationSettings: {
            staffEmails: [],
            staffPhones: [],
            staffChannelPreference: 'email_only',
            eventToggles: {
              newAppointmentEmail: true,
              newAppointmentSms: false,
              newPreIntakeEmail: false,
              sameDayReminder: false,
            },
          },
        });
      }

      res.json({
        clientId,
        notificationEmail: settings.notificationEmail,
        notificationPhone: settings.notificationPhone,
        enableEmailNotifications: settings.enableEmailNotifications,
        enableSmsNotifications: settings.enableSmsNotifications,
        notificationSettings: settings.notificationSettings,
      });
    } catch (error) {
      structuredLogger.error("Get notification preferences error:", error);
      res.status(500).json({ error: "Failed to fetch notification preferences" });
    }
  });

  // Update notification preferences
  app.patch("/api/client/notifications", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      // Validate request body
      const bodyValidation = validateRequest(notificationUpdateSchema, req.body);
      if (!bodyValidation.success) {
        return res.status(400).json({ error: bodyValidation.error });
      }
      
      const { 
        notificationEmail, 
        notificationPhone, 
        enableEmailNotifications, 
        enableSmsNotifications,
        notificationSettings
      } = bodyValidation.data;

      // First get existing settings to merge with
      const [existingSettings] = await db.select().from(clientSettings).where(eq(clientSettings.clientId, clientId)).limit(1);
      if (!existingSettings) {
        return res.status(404).json({ error: "Client settings not found" });
      }

      const updateData: Record<string, any> = {};

      if (notificationEmail !== undefined) updateData.notificationEmail = notificationEmail;
      if (notificationPhone !== undefined) updateData.notificationPhone = notificationPhone;
      if (enableEmailNotifications !== undefined) updateData.enableEmailNotifications = enableEmailNotifications;
      if (enableSmsNotifications !== undefined) updateData.enableSmsNotifications = enableSmsNotifications;
      
      // Merge notificationSettings to preserve existing values
      if (notificationSettings !== undefined) {
        const existingNotifSettings = existingSettings.notificationSettings || {
          staffEmails: [],
          staffPhones: [],
          staffChannelPreference: 'email_only',
          eventToggles: {
            newAppointmentEmail: true,
            newAppointmentSms: false,
            newPreIntakeEmail: false,
            sameDayReminder: false,
          },
        };
        
        updateData.notificationSettings = {
          ...existingNotifSettings,
          ...notificationSettings,
          eventToggles: notificationSettings.eventToggles 
            ? { ...existingNotifSettings.eventToggles, ...notificationSettings.eventToggles }
            : existingNotifSettings.eventToggles,
        };
      }

      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ error: "No valid fields to update" });
      }

      updateData.updatedAt = new Date();

      const [updated] = await db.update(clientSettings)
        .set(updateData)
        .where(eq(clientSettings.clientId, clientId))
        .returning();

      res.json({
        success: true,
        notificationEmail: updated.notificationEmail,
        notificationPhone: updated.notificationPhone,
        enableEmailNotifications: updated.enableEmailNotifications,
        enableSmsNotifications: updated.enableSmsNotifications,
        notificationSettings: updated.notificationSettings,
      });
    } catch (error) {
      structuredLogger.error("Update notification preferences error:", error);
      res.status(500).json({ error: "Failed to update notification preferences" });
    }
  });

  // =============================================
  // CLIENT LEADS ENDPOINTS
  // =============================================

  // Get all leads for client
  app.get("/api/client/leads", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { status, priority, search, limit, offset } = req.query;
      
      const result = await storage.getLeads(clientId, {
        status: status as string | undefined,
        priority: priority as string | undefined,
        search: search as string | undefined,
        limit: limit ? parseInt(limit as string) : 50,
        offset: offset ? parseInt(offset as string) : 0,
      });
      
      res.json({
        clientId,
        ...result,
      });
    } catch (error) {
      structuredLogger.error("Get client leads error:", error);
      res.status(500).json({ error: "Failed to fetch leads" });
    }
  });

  // Get single lead by ID
  app.get("/api/client/leads/:id", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const lead = await storage.getLeadById(clientId, req.params.id);
      
      if (!lead) {
        return res.status(404).json({ error: "Lead not found" });
      }
      
      res.json(lead);
    } catch (error) {
      structuredLogger.error("Get lead error:", error);
      res.status(500).json({ error: "Failed to fetch lead" });
    }
  });

  // Create a new lead
  app.post("/api/client/leads", requireClientAuth, requireOperationalAccess, async (req, res) => {
    try {
      // Validate body
      const bodyValidation = validateRequest(createLeadSchema, req.body);
      if (!bodyValidation.success) {
        return res.status(400).json({ error: bodyValidation.error });
      }
      
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      // If botId not provided, try to get default bot for this client
      let botId = bodyValidation.data.botId;
      if (!botId) {
        const clientBots = getBotsByClientId(clientId);
        if (clientBots.length > 0) {
          botId = clientBots[0].botId;
        } else {
          botId = `${clientId}_default`;
        }
      }
      
      const leadData = {
        ...bodyValidation.data,
        clientId,
        botId,
        source: bodyValidation.data.source || 'manual',
      };
      
      const lead = await storage.createLead(leadData as any);
      
      // Increment monthly leads count
      const currentMonth = new Date().toISOString().slice(0, 7);
      await storage.incrementMonthlyUsage(clientId, currentMonth, 'leads');
      
      // Trigger lead_captured automations (async, non-blocking)
      triggerWorkflowByEvent(botId, 'lead_captured', {
        clientId,
        leadId: lead.id,
        name: lead.name,
        email: lead.email,
        phone: lead.phone,
      }).catch(err => structuredLogger.error('[Automation] Error triggering lead_captured:', err));
      
      // Fire webhook for new lead (async, non-blocking)
      sendLeadCreatedWebhook(clientId, {
        id: lead.id,
        name: lead.name || 'Unknown',
        email: lead.email,
        phone: lead.phone,
        source: lead.source,
        status: lead.status,
        createdAt: lead.createdAt,
      }).catch(err => structuredLogger.error('[Webhook] Error sending lead webhook:', err));
      
      res.status(201).json(lead);
    } catch (error) {
      structuredLogger.error("Create lead error:", error);
      res.status(500).json({ error: "Failed to create lead" });
    }
  });

  // Update a lead
  app.patch("/api/client/leads/:id", requireClientAuth, requireOperationalAccess, async (req, res) => {
    try {
      // Validate params
      const paramsValidation = validateRequest(idParamSchema, req.params);
      if (!paramsValidation.success) {
        return res.status(400).json({ error: paramsValidation.error });
      }
      
      // Validate body
      const bodyValidation = validateRequest(updateLeadSchema, req.body);
      if (!bodyValidation.success) {
        return res.status(400).json({ error: bodyValidation.error });
      }
      
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const lead = await storage.getLeadById(clientId, paramsValidation.data.id);
      
      if (!lead) {
        return res.status(404).json({ error: "Lead not found" });
      }
      
      const previousStatus = lead.status;
      const updated = await storage.updateLead(clientId, paramsValidation.data.id, bodyValidation.data as any);
      
      // Fire webhook if status changed (async, non-blocking)
      if (updated && bodyValidation.data.status && bodyValidation.data.status !== previousStatus) {
        sendLeadUpdatedWebhook(clientId, {
          id: updated.id,
          name: updated.name || 'Unknown',
          status: updated.status,
          previousStatus,
        }).catch(err => structuredLogger.error('[Webhook] Error sending lead update webhook:', err));
      }
      
      res.json(updated);
    } catch (error) {
      structuredLogger.error("Update lead error:", error);
      res.status(500).json({ error: "Failed to update lead" });
    }
  });

  // Delete a lead
  app.delete("/api/client/leads/:id", requireClientAuth, requireDestructiveAccess, async (req, res) => {
    try {
      // Validate params
      const paramsValidation = validateRequest(idParamSchema, req.params);
      if (!paramsValidation.success) {
        return res.status(400).json({ error: paramsValidation.error });
      }
      
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const lead = await storage.getLeadById(clientId, paramsValidation.data.id);
      
      if (!lead) {
        return res.status(404).json({ error: "Lead not found" });
      }
      
      await storage.deleteLead(clientId, paramsValidation.data.id);
      res.status(204).send();
    } catch (error) {
      structuredLogger.error("Delete lead error:", error);
      res.status(500).json({ error: "Failed to delete lead" });
    }
  });

  // =============================================
  // BULK LEAD ACTIONS
  // =============================================

  const bulkLeadActionSchema = z.object({
    leadIds: z.array(z.string()).min(1, "At least one lead ID required"),
    action: z.enum(['update_status', 'delete']),
    status: z.string().optional(),
    priority: z.string().optional(),
  });

  // Bulk update leads
  app.post("/api/client/leads/bulk", requireClientAuth, requireDestructiveAccess, async (req, res) => {
    try {
      const bodyValidation = validateRequest(bulkLeadActionSchema, req.body);
      if (!bodyValidation.success) {
        return res.status(400).json({ error: bodyValidation.error });
      }
      
      const { leadIds, action, status, priority } = bodyValidation.data;
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      // SECURITY: Pre-validate ALL leads belong to this client before processing any
      const validationErrors: string[] = [];
      const validatedLeads: Array<{ id: string }> = [];
      
      for (const leadId of leadIds) {
        // Tenant-scoped lookup - automatically rejects leads from other tenants
        const lead = await storage.getLeadById(clientId, leadId);
        
        if (!lead) {
          validationErrors.push(`Lead ${leadId} not found`);
          continue;
        }
        
        validatedLeads.push({ id: leadId });
      }
      
      // If any leads not found, report but continue with valid ones
      if (validationErrors.length > 0 && validatedLeads.length === 0) {
        return res.status(404).json({
          error: "No valid leads found",
          success: false,
          successCount: 0,
          errorCount: validationErrors.length,
          errors: validationErrors.slice(0, 10)
        });
      }
      
      // Process validated leads
      let successCount = 0;
      let errorCount = validationErrors.length;
      const errors: string[] = [...validationErrors];
      
      for (const lead of validatedLeads) {
        try {
          if (action === 'delete') {
            await storage.deleteLead(clientId, lead.id);
          } else if (action === 'update_status') {
            const updates: any = {};
            if (status) updates.status = status;
            if (priority) updates.priority = priority;
            await storage.updateLead(clientId, lead.id, updates);
          }
          
          successCount++;
        } catch (err) {
          errorCount++;
          errors.push(`Failed to process lead ${lead.id}`);
        }
      }
      
      res.json({
        success: errorCount === 0,
        successCount,
        errorCount,
        errors: errors.slice(0, 10), // Limit error messages
      });
    } catch (error) {
      structuredLogger.error("Bulk lead action error:", error);
      res.status(500).json({ error: "Failed to perform bulk action" });
    }
  });

  // =============================================
  // CLIENT BOOKING ENDPOINTS (VIEW-ONLY)
  // =============================================

  // Get booking leads for client (view-only)
  app.get("/api/client/bookings", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { status, search, limit, offset } = req.query;
      
      const result = await storage.getBookingLeads(clientId, {
        status: status as string | undefined,
        search: search as string | undefined,
        limit: limit ? parseInt(limit as string) : 50,
        offset: offset ? parseInt(offset as string) : 0,
      });
      
      res.json(result);
    } catch (error) {
      structuredLogger.error("Get booking leads error:", error);
      res.status(500).json({ error: "Failed to fetch booking leads" });
    }
  });

  // Update booking status (PATCH)
  const updateBookingStatusSchema = z.object({
    status: z.enum(['new', 'pending', 'confirmed', 'completed', 'cancelled', 'no_show']).optional(),
    notes: z.string().optional(),
  });

  app.patch("/api/client/bookings/:id", requireClientAuth, requireOperationalAccess, async (req, res) => {
    try {
      const { id } = req.params;
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      
      // Validate body
      const bodyValidation = validateRequest(updateBookingStatusSchema, req.body);
      if (!bodyValidation.success) {
        return res.status(400).json({ error: bodyValidation.error });
      }
      
      // Get the appointment to verify ownership
      const clientAppointments = await storage.getAllAppointments(clientId);
      const appointment = clientAppointments.find((a: any) => a.id.toString() === id);
      
      if (!appointment) {
        return res.status(404).json({ error: "Booking not found" });
      }
      
      // Update the appointment
      const updates: Record<string, any> = {};
      if (bodyValidation.data.status) updates.status = bodyValidation.data.status;
      if (bodyValidation.data.notes !== undefined) updates.notes = bodyValidation.data.notes;
      
      // Use the appointments table for update
      const [updated] = await (db.update(appointments) as any)
        .set(updates)
        .where(eq(appointments.id, id))
        .returning();
      
      res.json(updated);
    } catch (error) {
      structuredLogger.error("Update booking status error:", error);
      res.status(500).json({ error: "Failed to update booking" });
    }
  });

  // Get booking analytics for client (view-only)
  app.get("/api/client/bookings/analytics", requireClientAuth, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { startDate, endDate } = req.query;
      
      const analytics = await storage.getBookingAnalytics(
        clientId,
        startDate ? new Date(startDate as string) : undefined,
        endDate ? new Date(endDate as string) : undefined
      );
      
      res.json(analytics);
    } catch (error) {
      structuredLogger.error("Get booking analytics error:", error);
      res.status(500).json({ error: "Failed to fetch booking analytics" });
    }
  });

  // Track booking link click (called from widget when user clicks booking URL)
  app.post("/api/bookings/link-click", async (req, res) => {
    try {
      const { clientId, botId, sessionId, leadId, bookingUrl } = req.body;
      
      if (!clientId || !botId || !sessionId || !bookingUrl) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      
      // Log the click event
      await storage.logBookingLinkClickEvent({
        clientId,
        botId,
        sessionId,
        leadId,
        bookingUrl
      });
      
      // Update lead status if leadId provided
      if (leadId) {
        try {
          await storage.updateLead(clientId, leadId, {
            bookingStatus: 'redirected',
            bookingUrlUsed: bookingUrl
          });
        } catch (e) {
          structuredLogger.warn("Failed to update lead status after link click:", e);
        }
      }
      
      res.json({ success: true });
    } catch (error) {
      structuredLogger.error("Track booking link click error:", error);
      res.status(500).json({ error: "Failed to track link click" });
    }
  });

  // =============================================
  // SUPER-ADMIN BOOKING URL MANAGEMENT
  // =============================================

  // Get client booking settings (super-admin only)
  app.get("/api/super-admin/clients/:clientId/booking", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const settings = await storage.getSettings(clientId);
      
      res.json({
        externalBookingUrl: settings?.externalBookingUrl || null,
        externalPaymentUrl: settings?.externalPaymentUrl || null,
      });
    } catch (error) {
      structuredLogger.error("Get client booking settings error:", error);
      res.status(500).json({ error: "Failed to fetch booking settings" });
    }
  });

  // Update client booking settings (super-admin only)
  app.patch("/api/super-admin/clients/:clientId/booking", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const { externalBookingUrl, externalPaymentUrl } = req.body;
      
      // Validate booking URL using comprehensive validator (blocks http://, javascript:, payment URLs, etc.)
      if (externalBookingUrl && typeof externalBookingUrl === 'string') {
        const urlValidation = validateBookingUrl(externalBookingUrl);
        if (!urlValidation.valid) {
          return res.status(400).json({ error: `Invalid booking URL: ${urlValidation.error}` });
        }
      }
      
      // Basic URL validation for payment URL (payment URLs blocked in booking URL validator)
      if (externalPaymentUrl && typeof externalPaymentUrl === 'string') {
        try {
          const parsed = new URL(externalPaymentUrl);
          if (parsed.protocol !== 'https:') {
            return res.status(400).json({ error: "Payment URL must use HTTPS" });
          }
        } catch {
          return res.status(400).json({ error: "Invalid payment URL format" });
        }
      }
      
      const updates: any = {};
      if (externalBookingUrl !== undefined) {
        updates.externalBookingUrl = externalBookingUrl || null;
      }
      if (externalPaymentUrl !== undefined) {
        updates.externalPaymentUrl = externalPaymentUrl || null;
      }
      
      const updated = await storage.updateSettings(clientId, updates);
      
      res.json({
        success: true,
        externalBookingUrl: updated.externalBookingUrl,
        externalPaymentUrl: updated.externalPaymentUrl,
      });
    } catch (error) {
      structuredLogger.error("Update client booking settings error:", error);
      res.status(500).json({ error: "Failed to update booking settings" });
    }
  });

  // =============================================
  // SUPER-ADMIN BEHAVIOR SETTINGS
  // =============================================

  // Get client behavior settings (super-admin only)
  app.get("/api/super-admin/clients/:clientId/behavior", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const settings = await storage.getSettings(clientId);
      
      res.json({
        behaviorPreset: settings?.behaviorPreset || 'support_lead_focused',
        leadCaptureEnabled: settings?.leadCaptureEnabled ?? true,
        leadDetectionSensitivity: settings?.leadDetectionSensitivity || 'medium',
        fallbackLeadCaptureEnabled: settings?.fallbackLeadCaptureEnabled ?? true,
      });
    } catch (error) {
      structuredLogger.error("Get client behavior settings error:", error);
      res.status(500).json({ error: "Failed to fetch behavior settings" });
    }
  });

  // Update client behavior settings (super-admin only)
  app.patch("/api/super-admin/clients/:clientId/behavior", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const { behaviorPreset, leadCaptureEnabled, leadDetectionSensitivity, fallbackLeadCaptureEnabled } = req.body;
      
      // Validate behaviorPreset if provided
      const validPresets = ['support_lead_focused', 'sales_focused_soft', 'support_only', 'compliance_strict', 'sales_heavy'];
      if (behaviorPreset && !validPresets.includes(behaviorPreset)) {
        return res.status(400).json({ error: "Invalid behavior preset" });
      }
      
      // Validate leadDetectionSensitivity if provided
      const validSensitivities = ['low', 'medium', 'high'];
      if (leadDetectionSensitivity && !validSensitivities.includes(leadDetectionSensitivity)) {
        return res.status(400).json({ error: "Invalid lead detection sensitivity" });
      }
      
      const updates: any = {};
      if (behaviorPreset !== undefined) updates.behaviorPreset = behaviorPreset;
      if (leadCaptureEnabled !== undefined) updates.leadCaptureEnabled = leadCaptureEnabled;
      if (leadDetectionSensitivity !== undefined) updates.leadDetectionSensitivity = leadDetectionSensitivity;
      if (fallbackLeadCaptureEnabled !== undefined) updates.fallbackLeadCaptureEnabled = fallbackLeadCaptureEnabled;
      
      const updated = await storage.updateSettings(clientId, updates);
      
      res.json({
        success: true,
        behaviorPreset: updated.behaviorPreset,
        leadCaptureEnabled: updated.leadCaptureEnabled,
        leadDetectionSensitivity: updated.leadDetectionSensitivity,
        fallbackLeadCaptureEnabled: updated.fallbackLeadCaptureEnabled,
      });
    } catch (error) {
      structuredLogger.error("Update client behavior settings error:", error);
      res.status(500).json({ error: "Failed to update behavior settings" });
    }
  });

  // Get booking leads for admin (super-admin access to any client)
  app.get("/api/super-admin/clients/:clientId/bookings", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const { status, search, limit, offset } = req.query;
      
      const result = await storage.getBookingLeads(clientId, {
        status: status as string | undefined,
        search: search as string | undefined,
        limit: limit ? parseInt(limit as string) : 50,
        offset: offset ? parseInt(offset as string) : 0,
      });
      
      res.json(result);
    } catch (error) {
      structuredLogger.error("Get admin booking leads error:", error);
      res.status(500).json({ error: "Failed to fetch booking leads" });
    }
  });

  // Get booking analytics for admin (super-admin access to any client)
  app.get("/api/super-admin/clients/:clientId/bookings/analytics", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const { startDate, endDate } = req.query;
      
      const analytics = await storage.getBookingAnalytics(
        clientId,
        startDate ? new Date(startDate as string) : undefined,
        endDate ? new Date(endDate as string) : undefined
      );
      
      res.json(analytics);
    } catch (error) {
      structuredLogger.error("Get admin booking analytics error:", error);
      res.status(500).json({ error: "Failed to fetch booking analytics" });
    }
  });

  // =============================================
  // SUPER-ADMIN ANALYTICS OVERVIEW
  // =============================================

  // Get platform-wide analytics overview
  app.get("/api/super-admin/analytics/overview", requireSuperAdmin, async (req, res) => {
    try {
      // Validate query params
      const queryValidation = validateRequest(superAdminOverviewQuerySchema, req.query);
      if (!queryValidation.success) {
        return res.status(400).json({ error: queryValidation.error });
      }
      
      const { days } = queryValidation.data;
      const allBots = getAllBotConfigs();
      
      const overview: any[] = [];
      
      for (const bot of allBots) {
        const summary = await storage.getClientAnalyticsSummary(bot.clientId, bot.botId);
        overview.push({
          clientId: bot.clientId,
          botId: bot.botId,
          businessName: bot.businessProfile?.businessName || bot.name,
          businessType: bot.businessProfile?.type || 'general',
          ...summary,
        });
      }
      
      // Calculate totals
      const totals = overview.reduce((acc, curr) => ({
        totalConversations: acc.totalConversations + curr.totalConversations,
        totalMessages: acc.totalMessages + curr.totalMessages,
        userMessages: acc.userMessages + curr.userMessages,
        botMessages: acc.botMessages + curr.botMessages,
        crisisEvents: acc.crisisEvents + curr.crisisEvents,
        appointmentRequests: acc.appointmentRequests + curr.appointmentRequests,
      }), {
        totalConversations: 0,
        totalMessages: 0,
        userMessages: 0,
        botMessages: 0,
        crisisEvents: 0,
        appointmentRequests: 0,
      });
      
      res.json({
        totals,
        bots: overview,
        totalBots: allBots.length,
      });
    } catch (error) {
      structuredLogger.error("Get super-admin analytics overview error:", error);
      res.status(500).json({ error: "Failed to fetch analytics overview" });
    }
  });

  // =============================================
  // SUPER-ADMIN: SYSTEM LOGS & STATUS
  // =============================================

  // Get system status (operational, degraded, incident)
  app.get("/api/super-admin/system/status", requireSuperAdmin, async (req, res) => {
    try {
      const status = await storage.getSystemStatus();
      res.json(status);
    } catch (error) {
      structuredLogger.error("Get system status error:", error);
      res.status(500).json({ error: "Failed to fetch system status" });
    }
  });

  // Get integrations status (OpenAI, Database, etc)
  app.get("/api/super-admin/integrations/status", requireSuperAdmin, async (req, res) => {
    try {
      const { getOpenAIConfig } = await import("./env");
      const openAIConfig = getOpenAIConfig();
      
      // Check database health
      const dbCheck = await storage.healthCheck?.() ?? { status: 'ok' };
      
      // Verify OpenAI key with a lightweight API call
      let openaiStatus: 'connected' | 'error' | 'not_configured' = 'not_configured';
      if (openAIConfig?.apiKey) {
        try {
          const OpenAI = (await import("openai")).default;
          const openai = new OpenAI({ apiKey: openAIConfig.apiKey, baseURL: openAIConfig.baseURL });
          
          // Check if using Replit's localhost proxy (doesn't support models.list)
          const isReplitProxy = openAIConfig.baseURL?.includes('localhost') || openAIConfig.baseURL?.includes('127.0.0.1');
          
          if (isReplitProxy) {
            // For Replit proxy, just verify we can reach it with a minimal chat request
            await openai.chat.completions.create({
              model: "gpt-4o-mini",
              messages: [{ role: "user", content: "hi" }],
              max_tokens: 1,
            });
            openaiStatus = 'connected';
          } else {
            // For direct OpenAI API, use models.list
            await openai.models.list();
            openaiStatus = 'connected';
          }
        } catch (e: any) {
          // Key exists but is invalid or service unavailable
          openaiStatus = 'error';
          structuredLogger.info("OpenAI status check failed:", e.message);
        }
      }
      
      res.json({
        openai: {
          configured: !!openAIConfig?.apiKey,
          baseUrl: openAIConfig?.baseURL || null,
          status: openaiStatus,
        },
        database: {
          configured: !!process.env.DATABASE_URL,
          status: dbCheck.status === 'ok' ? 'connected' : 'error',
          latencyMs: dbCheck.latencyMs,
        },
        email: {
          configured: false, // Placeholder for future email integration
          status: 'not_configured',
        },
        sms: {
          configured: false, // Placeholder for future SMS integration  
          status: 'not_configured',
        },
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      structuredLogger.error("Get integrations status error:", error);
      res.status(500).json({ error: "Failed to fetch integrations status" });
    }
  });

  // Test integration connection
  app.post("/api/super-admin/integrations/test/:integration", requireSuperAdmin, async (req, res) => {
    try {
      const { integration } = req.params;
      const startTime = Date.now();
      
      switch (integration) {
        case 'openai': {
          const { getOpenAIConfig } = await import("./env");
          const config = getOpenAIConfig();
          
          // Guard against missing API key
          if (!config || !config.apiKey) {
            return res.json({ 
              success: false, 
              error: 'OpenAI API key not configured. Please add OPENAI_API_KEY to secrets.', 
              latencyMs: 0 
            });
          }
          
          // Test with a lightweight API call (models.list)
          try {
            const OpenAI = (await import("openai")).default;
            const openai = new OpenAI({ apiKey: config.apiKey, baseURL: config.baseURL });
            await openai.models.list();
            return res.json({ success: true, latencyMs: Date.now() - startTime });
          } catch (e: any) {
            // Handle specific OpenAI errors
            const errorMessage = e.status === 401 
              ? 'Invalid API key - please check your OPENAI_API_KEY'
              : e.message || 'Connection failed';
            return res.json({ success: false, error: errorMessage, latencyMs: Date.now() - startTime });
          }
        }
        
        case 'database': {
          const dbCheck = await storage.healthCheck?.() ?? { status: 'ok', latencyMs: 0 };
          return res.json({ 
            success: dbCheck.status === 'ok', 
            latencyMs: dbCheck.latencyMs || Date.now() - startTime,
            error: dbCheck.status !== 'ok' ? 'Database connection failed' : undefined,
          });
        }
        
        default:
          return res.status(400).json({ error: 'Unknown integration' });
      }
    } catch (error) {
      structuredLogger.error("Test integration error:", error);
      res.status(500).json({ error: "Failed to test integration" });
    }
  });

  // Get system logs with filters
  app.get("/api/super-admin/system/logs", requireSuperAdmin, async (req, res) => {
    try {
      const { level, source, workspaceId, clientId, isResolved, search, startDate, endDate, limit, offset } = req.query;
      
      const filters: any = {};
      if (level) filters.level = String(level);
      if (source) filters.source = String(source);
      if (workspaceId) filters.workspaceId = String(workspaceId);
      if (clientId) filters.clientId = String(clientId);
      if (isResolved !== undefined) filters.isResolved = isResolved === 'true';
      if (search) filters.search = String(search);
      if (startDate) filters.startDate = new Date(String(startDate));
      if (endDate) filters.endDate = new Date(String(endDate));
      if (limit) filters.limit = parseInt(String(limit), 10);
      if (offset) filters.offset = parseInt(String(offset), 10);
      
      const result = await storage.getSystemLogs(filters);
      res.json(result);
    } catch (error) {
      structuredLogger.error("Get system logs error:", error);
      res.status(500).json({ error: "Failed to fetch system logs" });
    }
  });

  // Get single system log
  app.get("/api/super-admin/system/logs/:id", requireSuperAdmin, async (req, res) => {
    try {
      const log = await storage.getSystemLogById(req.params.id);
      if (!log) {
        return res.status(404).json({ error: "Log not found" });
      }
      res.json(log);
    } catch (error) {
      structuredLogger.error("Get system log error:", error);
      res.status(500).json({ error: "Failed to fetch system log" });
    }
  });

  // Resolve a system log
  app.post("/api/super-admin/system/logs/:id/resolve", requireSuperAdmin, async (req, res) => {
    try {
      const { notes } = req.body;
      const user = req.user;
      
      const resolved = await storage.resolveSystemLog(req.params.id, user?.username || 'super-admin', notes);
      res.json(resolved);
    } catch (error) {
      structuredLogger.error("Resolve system log error:", error);
      res.status(500).json({ error: "Failed to resolve log" });
    }
  });

  // Create a system log (for testing or manual logging)
  app.post("/api/super-admin/system/logs", requireSuperAdmin, async (req, res) => {
    try {
      const logSchema = z.object({
        level: z.enum(['debug', 'info', 'warn', 'error', 'critical']).default('info'),
        source: z.string().min(1),
        message: z.string().min(1),
        workspaceId: z.string().optional(),
        clientId: z.string().optional(),
        details: z.record(z.any()).optional(),
      });
      
      const validation = logSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ error: validation.error.message });
      }
      
      const log = await storage.createSystemLog(validation.data);
      res.status(201).json(log);
    } catch (error) {
      structuredLogger.error("Create system log error:", error);
      res.status(500).json({ error: "Failed to create system log" });
    }
  });

  // =============================================
  // SUPER-ADMIN: USER MANAGEMENT
  // =============================================

  // List all admin users
  app.get("/api/super-admin/users", requireSuperAdmin, async (req, res) => {
    try {
      const users = await db.select({
        id: adminUsers.id,
        username: adminUsers.username,
        role: adminUsers.role,
        clientId: adminUsers.clientId,
        createdAt: adminUsers.createdAt,
      }).from(adminUsers).orderBy(adminUsers.username);
      res.json(users);
    } catch (error) {
      structuredLogger.error("Get admin users error:", error);
      res.status(500).json({ error: "Failed to fetch admin users" });
    }
  });

  // Create new admin user schema with strong password
  const createUserSchema = z.object({
    username: z.string().min(3, "Username must be at least 3 characters").max(50),
    password: strongPasswordSchema,
    role: z.enum(['super_admin', 'client_admin']),
    clientId: z.string().optional(),
  });

  // Create new admin user
  app.post("/api/super-admin/users", requireSuperAdmin, async (req, res) => {
    try {
      const validation = createUserSchema.safeParse(req.body);
      if (!validation.success) {
        const errorMessage = validation.error.errors.map(e => e.message).join(', ');
        return res.status(400).json({ error: errorMessage });
      }
      
      const { username, password, role, clientId } = validation.data;
      
      // Check if username already exists
      const existing = await db.select().from(adminUsers).where(eq(adminUsers.username, username)).limit(1);
      if (existing.length > 0) {
        return res.status(409).json({ error: "Username already exists" });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Create user
      const [newUser] = await db.insert(adminUsers).values({
        username,
        passwordHash: hashedPassword,
        role,
        clientId: role === 'client_admin' ? clientId : null,
      }).returning({
        id: adminUsers.id,
        username: adminUsers.username,
        role: adminUsers.role,
        clientId: adminUsers.clientId,
        createdAt: adminUsers.createdAt,
      });
      
      // Log the creation
      await storage.createSystemLog({
        level: 'info',
        source: 'super-admin',
        message: `New admin user created: ${username} (${role})`,
      });
      
      res.status(201).json(newUser);
    } catch (error) {
      structuredLogger.error("Create admin user error:", error);
      res.status(500).json({ error: "Failed to create admin user" });
    }
  });

  // Update admin user schema (password is optional but must be strong if provided)
  const updateUserSchema = z.object({
    role: z.enum(['super_admin', 'client_admin']).optional(),
    clientId: z.string().optional(),
    password: strongPasswordSchema.optional(),
  });

  // Update admin user
  app.patch("/api/super-admin/users/:id", requireSuperAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      
      const validation = updateUserSchema.safeParse(req.body);
      if (!validation.success) {
        const errorMessage = validation.error.errors.map(e => e.message).join(', ');
        return res.status(400).json({ error: errorMessage });
      }
      
      const { role, clientId, password } = validation.data;
      
      // Find the user
      const existing = await db.select().from(adminUsers).where(eq(adminUsers.id, id)).limit(1);
      if (existing.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const updateData: Record<string, any> = {};
      
      if (role && ['super_admin', 'client_admin'].includes(role)) {
        updateData.role = role;
        updateData.clientId = role === 'client_admin' ? (clientId || existing[0].clientId) : null;
      }
      
      if (password) {
        updateData.passwordHash = await bcrypt.hash(password, 10);
      }
      
      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ error: "No valid fields to update" });
      }
      
      const [updated] = await db.update(adminUsers)
        .set(updateData)
        .where(eq(adminUsers.id, id))
        .returning({
          id: adminUsers.id,
          username: adminUsers.username,
          role: adminUsers.role,
          clientId: adminUsers.clientId,
          createdAt: adminUsers.createdAt,
        });
      
      res.json(updated);
    } catch (error) {
      structuredLogger.error("Update admin user error:", error);
      res.status(500).json({ error: "Failed to update admin user" });
    }
  });

  // Delete admin user
  app.delete("/api/super-admin/users/:id", requireSuperAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const currentUserId = (req.session as any)?.passport?.user;
      
      // Prevent self-deletion
      if (currentUserId === id) {
        return res.status(400).json({ error: "Cannot delete your own account" });
      }
      
      // Find the user
      const existing = await db.select().from(adminUsers).where(eq(adminUsers.id, id)).limit(1);
      if (existing.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const username = existing[0].username;
      
      // Delete the user
      await db.delete(adminUsers).where(eq(adminUsers.id, id));
      
      // Log the deletion
      await storage.createSystemLog({
        level: 'info',
        source: 'super-admin',
        message: `Admin user deleted: ${username}`,
      });
      
      res.json({ success: true, message: `User ${username} deleted successfully` });
    } catch (error) {
      structuredLogger.error("Delete admin user error:", error);
      res.status(500).json({ error: "Failed to delete admin user" });
    }
  });

  // =============================================
  // SUPER-ADMIN: DELETE BOT
  // =============================================

  // Delete a bot and its associated client
  app.delete("/api/super-admin/bots/:botId", requireSuperAdmin, async (req, res) => {
    try {
      const { botId } = req.params;
      
      let clientId: string | null = null;
      let deletedFromDb = false;
      
      // First, try to find and delete from database directly
      const existingBot = await storage.getBotByBotId(botId);
      if (existingBot) {
        // Get the workspace to find clientId (workspace slug)
        const [workspace] = await db.select().from(workspaces).where(eq(workspaces.id, existingBot.workspaceId)).limit(1);
        clientId = workspace?.slug || existingBot.workspaceId;
        
        // Delete bot settings first (use bot's internal id)
        await db.delete(botSettings).where(eq(botSettings.botId, existingBot.id));
        // Delete bot
        await db.delete(bots).where(eq(bots.id, existingBot.id));
        deletedFromDb = true;
      }
      
      // Fallback: Check JSON file cache if not found in database
      if (!deletedFromDb) {
        const botConfig = getAllBotConfigs().find(b => b.botId === botId);
        if (botConfig) {
          clientId = botConfig.clientId;
          // Try to delete JSON file
          const botFilePath = path.join(process.cwd(), 'bots', `${botId}.json`);
          if (fs.existsSync(botFilePath)) {
            fs.unlinkSync(botFilePath);
          }
        }
      }
      
      // If we couldn't find the bot anywhere, return 404
      if (!clientId && !deletedFromDb) {
        return res.status(404).json({ error: "Bot not found" });
      }
      
      // Delete related data if we have a clientId
      if (clientId) {
        await db.delete(leads).where(eq(leads.clientId, clientId));
        await db.delete(appointments).where(eq(appointments.clientId, clientId));
        await db.delete(clientSettings).where(eq(clientSettings.clientId, clientId));
      }
      
      // Clear the bot config cache to ensure consistency
      clearCache();
      
      // Log the deletion
      await storage.createSystemLog({
        level: 'info',
        source: 'super-admin',
        message: `Bot deleted: ${botId}${clientId ? ` (client: ${clientId})` : ''}`,
        clientId: clientId || undefined,
      });
      
      res.json({ success: true, message: `Bot ${botId} deleted successfully` });
    } catch (error) {
      structuredLogger.error("Delete bot error:", error);
      res.status(500).json({ error: "Failed to delete bot" });
    }
  });

  // =============================================
  // SUPER-ADMIN: GLOBAL ANALYTICS (Enhanced)
  // =============================================

  // Get global analytics with daily trends
  app.get("/api/super-admin/analytics/global", requireSuperAdmin, async (req, res) => {
    try {
      const { days: daysParam } = req.query;
      const days = daysParam ? parseInt(String(daysParam), 10) : 7;
      
      const allBots = getAllBotConfigs();
      const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
      
      // Get aggregated stats across all bots
      let totalConversations = 0;
      let totalMessages = 0;
      let totalLeads = 0;
      let totalAppointments = 0;
      let activeWorkspaces = new Set<string>();
      
      const dailyData: Record<string, { conversations: number; leads: number; appointments: number }> = {};
      
      // Initialize daily data for the date range
      for (let i = 0; i < days; i++) {
        const date = new Date(Date.now() - (days - 1 - i) * 24 * 60 * 60 * 1000);
        const dateStr = date.toISOString().split('T')[0];
        dailyData[dateStr] = { conversations: 0, leads: 0, appointments: 0 };
      }
      
      for (const bot of allBots) {
        const summary = await storage.getClientAnalyticsSummary(bot.clientId, bot.botId, startDate);
        totalConversations += summary.totalConversations;
        totalMessages += summary.totalMessages;
        totalAppointments += summary.appointmentRequests;
        
        if (summary.totalConversations > 0) {
          activeWorkspaces.add(bot.clientId);
        }
        
        // Get daily trends for this bot
        const trends = await storage.getClientDailyTrends(bot.clientId, bot.botId, days);
        trends.forEach(trend => {
          if (dailyData[trend.date]) {
            dailyData[trend.date].conversations += trend.totalConversations;
            dailyData[trend.date].appointments += trend.appointmentRequests;
          }
        });
        
        // Get leads for this bot
        const { leads } = await storage.getLeads(bot.clientId, { limit: 1000 });
        const recentLeads = leads.filter(l => l.createdAt >= startDate);
        totalLeads += recentLeads.length;
        
        // Add leads to daily data
        recentLeads.forEach(lead => {
          const dateStr = lead.createdAt.toISOString().split('T')[0];
          if (dailyData[dateStr]) {
            dailyData[dateStr].leads += 1;
          }
        });
      }
      
      // Convert daily data to array sorted by date
      const dailyTrends = Object.entries(dailyData)
        .sort((a, b) => a[0].localeCompare(b[0]))
        .map(([date, data]) => ({ date, ...data }));
      
      res.json({
        summary: {
          totalConversations,
          totalMessages,
          totalLeads,
          totalAppointments,
          activeWorkspaces: activeWorkspaces.size,
          totalBots: allBots.length,
        },
        dailyTrends,
        dateRange: {
          start: startDate.toISOString(),
          end: new Date().toISOString(),
          days,
        },
      });
    } catch (error) {
      structuredLogger.error("Get global analytics error:", error);
      res.status(500).json({ error: "Failed to fetch global analytics" });
    }
  });
  
  // Get recent activity across all bots
  app.get("/api/super-admin/analytics/recent-activity", requireSuperAdmin, async (req, res) => {
    try {
      const { limit: limitParam } = req.query;
      const limit = limitParam ? parseInt(String(limitParam), 10) : 20;
      
      const allBots = getAllBotConfigs();
      const activities: Array<{
        type: 'conversation' | 'lead' | 'session';
        clientId: string;
        botId: string;
        botName: string;
        details: any;
        timestamp: Date;
      }> = [];
      
      // Get recent leads and sessions from all bots
      for (const bot of allBots) {
        // Get recent leads
        const { leads } = await storage.getLeads(bot.clientId, { limit: 10 });
        leads.forEach(lead => {
          activities.push({
            type: 'lead',
            clientId: bot.clientId,
            botId: bot.botId,
            botName: bot.name || bot.botId,
            details: {
              id: lead.id,
              name: lead.name || 'Anonymous',
              email: lead.email,
              phone: lead.phone,
              source: lead.source,
              status: lead.status,
            },
            timestamp: lead.createdAt,
          });
        });
        
        // Get recent sessions
        const sessions = await storage.getClientRecentSessions(bot.clientId, bot.botId, 10);
        sessions.forEach(session => {
          activities.push({
            type: 'session',
            clientId: bot.clientId,
            botId: bot.botId,
            botName: bot.name || bot.botId,
            details: {
              sessionId: session.sessionId,
              messageCount: session.userMessageCount + session.botMessageCount,
              topics: session.topics || [],
            },
            timestamp: session.startedAt,
          });
        });
      }
      
      // Sort by timestamp descending and limit
      activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      const recentActivities = activities.slice(0, limit);
      
      res.json({
        activities: recentActivities,
        total: recentActivities.length,
      });
    } catch (error) {
      structuredLogger.error("Get recent activity error:", error);
      res.status(500).json({ error: "Failed to fetch recent activity" });
    }
  });

  // =============================================
  // SUPER-ADMIN: WORKSPACES MANAGEMENT
  // =============================================

  // List all workspaces with stats
  app.get("/api/super-admin/workspaces", requireSuperAdmin, async (req, res) => {
    try {
      const workspaceList = await getWorkspaces();
      const allBots = getAllBotConfigs();
      
      // Enrich workspace data with stats
      const enrichedWorkspaces = await Promise.all(workspaceList.map(async (ws: any) => {
        const wsBots = allBots.filter(b => b.clientId === ws.slug || b.clientId === ws.id);
        
        let totalConversations = 0;
        let lastActive: Date | null = null;
        
        for (const bot of wsBots) {
          const recentSessions = await storage.getClientRecentSessions(bot.clientId, bot.botId, 10);
          totalConversations += recentSessions.length;
          
          if (recentSessions.length > 0 && recentSessions[0].startedAt) {
            if (!lastActive || recentSessions[0].startedAt > lastActive) {
              lastActive = recentSessions[0].startedAt;
            }
          }
        }
        
        // MULTI-TENANT: Count users (client logins) for this workspace
        // Users with clientId matching the workspace slug are considered workspace members
        const workspaceUsers = await db.select({ id: adminUsers.id })
          .from(adminUsers)
          .where(eq(adminUsers.clientId, ws.slug));
        
        return {
          id: ws.id,
          name: ws.name,
          slug: ws.slug,
          status: ws.status || 'active',
          plan: ws.plan || 'starter',
          botsCount: wsBots.length,
          usersCount: workspaceUsers.length,  // For "View as Client" button state
          totalConversations,
          lastActive: lastActive?.toISOString() || null,
          createdAt: ws.createdAt,
          settings: ws.settings || {},
          adminNotes: ws.adminNotes || '',
          isDemo: ws.isDemo ?? false,
        };
      }));
      
      res.json({
        workspaces: enrichedWorkspaces,
        total: enrichedWorkspaces.length,
      });
    } catch (error) {
      structuredLogger.error("Get workspaces error:", error);
      res.status(500).json({ error: "Failed to fetch workspaces" });
    }
  });

  // Get single workspace with detailed stats
  app.get("/api/super-admin/workspaces/:slug", requireSuperAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      const workspace = await getWorkspaceBySlug(slug);
      
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      const allBots = getAllBotConfigs();
      const wsBots = allBots.filter(b => b.clientId === workspace.slug || b.clientId === (workspace as any).id);
      
      // Get 30-day stats
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      let totalConversations30d = 0;
      let totalLeads30d = 0;
      let totalAppointments30d = 0;
      
      const botDetails = await Promise.all(wsBots.map(async (bot) => {
        const summary = await storage.getClientAnalyticsSummary(bot.clientId, bot.botId, thirtyDaysAgo);
        const recentSessions = await storage.getClientRecentSessions(bot.clientId, bot.botId, 5);
        const { leads } = await storage.getLeads(bot.clientId, { limit: 100 });
        const recentLeads = leads.filter(l => l.createdAt >= thirtyDaysAgo);
        
        totalConversations30d += summary.totalConversations;
        totalLeads30d += recentLeads.length;
        totalAppointments30d += summary.appointmentRequests;
        
        return {
          botId: bot.botId,
          name: bot.name,
          status: (bot as any).status || 'active',
          lastActive: recentSessions[0]?.startedAt?.toISOString() || null,
          conversations30d: summary.totalConversations,
          leads30d: recentLeads.length,
        };
      }));
      
      res.json({
        workspace: {
          id: (workspace as any).id,
          name: workspace.name,
          slug: workspace.slug,
          status: (workspace as any).status || 'active',
          plan: (workspace as any).plan || 'starter',
          settings: (workspace as any).settings || {},
          createdAt: (workspace as any).createdAt,
          isDemo: (workspace as any).isDemo ?? false,
          botsCount: wsBots.length,
          totalConversations: totalConversations30d,
        },
        stats: {
          conversations30d: totalConversations30d,
          leads30d: totalLeads30d,
          appointments30d: totalAppointments30d,
        },
        bots: botDetails,
      });
    } catch (error) {
      structuredLogger.error("Get workspace error:", error);
      res.status(500).json({ error: "Failed to fetch workspace" });
    }
  });

  // Update workspace status (suspend/reactivate)
  app.patch("/api/super-admin/workspaces/:slug/status", requireSuperAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      const { status } = req.body;
      
      if (!['active', 'paused', 'suspended', 'cancelled', 'demo'].includes(status)) {
        return res.status(400).json({ error: "Invalid status. Must be one of: active, paused, suspended, cancelled, demo" });
      }
      
      const workspace = await getWorkspaceBySlug(slug);
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Log this action
      await storage.createSystemLog({
        level: 'info',
        source: 'super-admin',
        message: `Workspace ${slug} status changed to ${status}`,
        workspaceId: (workspace as any).id,
        details: { previousStatus: (workspace as any).status || 'active', newStatus: status },
      });
      
      // Update client status through existing mechanism (for JSON-backed clients)
      updateClientStatus(slug, status);
      
      // Also update all bots for this workspace in the database
      const workspaceBots = await storage.getBotsByWorkspaceId((workspace as any).id);
      for (const bot of workspaceBots) {
        await saveBotConfigAsync(bot.botId, { status: status as 'active' | 'paused' });
      }
      
      res.json({ success: true, slug, status });
    } catch (error) {
      structuredLogger.error("Update workspace status error:", error);
      res.status(500).json({ error: "Failed to update workspace status" });
    }
  });

  // Update workspace plan
  app.patch("/api/super-admin/workspaces/:slug/plan", requireSuperAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      const { plan } = req.body;
      
      const validPlans = ['starter', 'professional', 'enterprise'];
      if (!validPlans.includes(plan)) {
        return res.status(400).json({ error: `Invalid plan. Must be one of: ${validPlans.join(', ')}` });
      }
      
      // Get workspace first
      const workspace = await getWorkspaceBySlug(slug);
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      const previousPlan = (workspace as any).plan || 'starter';
      
      // Update workspace plan in database
      const result = await updateWorkspacePlan(slug, plan);
      if (!result.success) {
        return res.status(404).json({ error: result.error || "Failed to update workspace plan" });
      }
      
      // Log this action
      await storage.createSystemLog({
        level: 'info',
        source: 'super-admin',
        message: `Workspace ${slug} plan changed to ${plan}`,
        workspaceId: (workspace as any).id,
        details: { previousPlan, newPlan: plan },
      });
      
      res.json({ success: true, slug, plan });
    } catch (error) {
      structuredLogger.error("Update workspace plan error:", error);
      res.status(500).json({ error: "Failed to update workspace plan" });
    }
  });

  // NOTE: Legacy impersonation routes (/api/super-admin/impersonate/:clientId and /api/super-admin/end-impersonation)
  // have been removed. Use POST /api/super-admin/impersonate with body {clientId} and POST /api/super-admin/impersonate/stop instead.
  // These new routes have proper CSRF protection, rate limiting, and tenant validation.

  // Helper function to generate a cryptographically secure temporary password
  function generateTemporaryPassword(length: number = 12): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    const randomBytes = crypto.randomBytes(length);
    let password = '';
    for (let i = 0; i < length; i++) {
      password += chars.charAt(randomBytes[i] % chars.length);
    }
    return password;
  }

  // Create new workspace with client account
  app.post("/api/super-admin/workspaces", requireSuperAdmin, async (req, res) => {
    try {
      const { name, slug, ownerId, plan, settings, clientEmail } = req.body;
      
      // Validate required fields
      if (!name || !slug) {
        return res.status(400).json({ error: "name and slug are required" });
      }
      
      // Validate slug format (alphanumeric and underscores only)
      if (!/^[a-z0-9_]+$/.test(slug)) {
        return res.status(400).json({ error: "Slug must be lowercase alphanumeric with underscores only" });
      }
      
      // Check if slug already exists
      const existing = await getWorkspaceBySlug(slug);
      if (existing) {
        return res.status(409).json({ error: `Workspace with slug '${slug}' already exists` });
      }
      
      // If clientEmail provided, check it doesn't already exist
      if (clientEmail) {
        const existingUser = await storage.findAdminByUsername(clientEmail);
        if (existingUser) {
          return res.status(409).json({ error: `An account with email '${clientEmail}' already exists` });
        }
      }
      
      let clientUser = null;
      let temporaryPassword = null;
      
      // If clientEmail is provided, create a client account
      if (clientEmail) {
        temporaryPassword = generateTemporaryPassword();
        const passwordHash = await bcrypt.hash(temporaryPassword, 10);
        
        // Create the client user account
        const [newUser] = await db.insert(adminUsers).values({
          username: clientEmail,
          passwordHash,
          role: "client_admin",
          clientId: slug,
        }).returning();
        
        clientUser = newUser;
      }
      
      // Determine the owner - use client user if created, otherwise use provided ownerId
      const effectiveOwnerId = clientUser?.id || ownerId;
      
      if (!effectiveOwnerId) {
        return res.status(400).json({ error: "Either clientEmail or ownerId is required" });
      }
      
      // Validate owner exists if ownerId was provided (not using new client user)
      if (!clientUser && ownerId) {
        const [owner] = await db.select().from(adminUsers).where(eq(adminUsers.id, ownerId)).limit(1);
        if (!owner) {
          return res.status(400).json({ error: "Invalid ownerId - user not found" });
        }
      }
      
      const workspace = await createWorkspace({
        name,
        slug,
        ownerId: effectiveOwnerId,
        plan: plan || 'starter',
        settings: settings || {},
      });
      
      // Create workspace membership for the client user
      if (clientUser) {
        await db.insert(workspaceMemberships).values({
          workspaceId: workspace.id,
          userId: clientUser.id,
          role: "owner",
          status: "active",
          acceptedAt: new Date(),
        });
        
        // Create default bot for the workspace
        const defaultBotId = `${slug}_bot`;
        await db.insert(bots).values({
          botId: defaultBotId,
          workspaceId: workspace.id,
          name: `${name} Assistant`,
          botType: "generic",
          businessProfile: {
            businessName: name,
            type: "generic",
            location: "",
            phone: "",
            email: clientEmail,
            website: "",
            hours: {},
          },
          systemPrompt: `You are a helpful AI assistant for ${name}. Be friendly, professional, and help visitors with their questions.`,
          theme: {
            primaryColor: "#06b6d4",
            welcomeMessage: `Welcome to ${name}! How can I help you today?`,
          },
          status: "active",
        });
        
        // Create default bot settings
        await db.insert(botSettings).values({
          botId: defaultBotId,
          faqs: [],
          rules: {},
          automations: {},
        });
        
        // Create client settings
        await db.insert(clientSettings).values({
          clientId: slug,
          businessName: name,
          tagline: "Welcome to our business",
          primaryEmail: clientEmail,
          status: "active",
          knowledgeBase: {
            about: `Welcome to ${name}.`,
            requirements: "",
            pricing: "",
            application: "",
          },
          operatingHours: {
            enabled: false,
            timezone: "America/New_York",
            schedule: {
              monday: { open: "09:00", close: "17:00", enabled: true },
              tuesday: { open: "09:00", close: "17:00", enabled: true },
              wednesday: { open: "09:00", close: "17:00", enabled: true },
              thursday: { open: "09:00", close: "17:00", enabled: true },
              friday: { open: "09:00", close: "17:00", enabled: true },
              saturday: { open: "09:00", close: "17:00", enabled: false },
              sunday: { open: "09:00", close: "17:00", enabled: false },
            },
            afterHoursMessage: "We're currently closed. Please leave a message and we'll get back to you.",
          },
        });
      }
      
      // Log this action
      await storage.createSystemLog({
        level: 'info',
        source: 'super-admin',
        message: `Workspace ${slug} created${clientUser ? ' with client account' : ''}`,
        workspaceId: workspace.id,
        details: { 
          name, 
          plan: plan || 'starter', 
          ownerId: effectiveOwnerId,
          clientEmail: clientEmail || null,
          hasClientAccount: !!clientUser,
        } as any,
      });
      
      // Return workspace with client credentials if created
      const response: any = {
        ...workspace,
        clientCredentials: clientUser ? {
          email: clientEmail,
          temporaryPassword,
          loginUrl: '/login',
          dashboardUrl: '/client/dashboard',
          message: 'Share these credentials with your client. They can change their password after logging in.',
        } : null,
      };
      
      res.status(201).json(response);
    } catch (error) {
      structuredLogger.error("Create workspace error:", error);
      res.status(500).json({ error: "Failed to create workspace" });
    }
  });

  // =============================================
  // UNIFIED NEW CLIENT WIZARD ENDPOINT
  // =============================================
  // Creates workspace + client_admin + bot from template with persona/FAQ overrides
  app.post("/api/super-admin/new-client", requireSuperAdmin, async (req, res) => {
    try {
      const {
        // Business basics
        businessName,
        industry, // maps to template ID (e.g., "sober_living", "barber", "gym")
        slug,
        contactName,
        contactEmail,
        contactPhone,
        businessLocation, // { city, state }
        websiteUrl,
        plan,
        // Persona fields
        assistantName,
        assistantRole,
        toneKeywords, // array of strings
        toneDescription,
        targetCustomer,
        uniqueSellingPoints, // array of strings
        // FAQs
        faqs, // array of { question, answer }
      } = req.body;

      // Validate required fields
      if (!businessName || !slug || !contactEmail) {
        return res.status(400).json({ 
          error: "businessName, slug, and contactEmail are required" 
        });
      }

      // Validate slug format
      if (!/^[a-z0-9_]+$/.test(slug)) {
        return res.status(400).json({ 
          error: "Slug must be lowercase alphanumeric with underscores only" 
        });
      }

      // Check if slug already exists
      const existingWorkspace = await getWorkspaceBySlug(slug);
      if (existingWorkspace) {
        return res.status(409).json({ 
          error: `Workspace with slug '${slug}' already exists` 
        });
      }

      // Check if email already exists
      const existingUser = await storage.findAdminByUsername(contactEmail);
      if (existingUser) {
        return res.status(409).json({ 
          error: `An account with email '${contactEmail}' already exists` 
        });
      }

      // 1. Create client user account
      const temporaryPassword = generateTemporaryPassword();
      const passwordHash = await bcrypt.hash(temporaryPassword, 10);
      
      const [clientUser] = await db.insert(adminUsers).values({
        username: contactEmail,
        passwordHash,
        role: "client_admin",
        clientId: slug,
      }).returning();

      // 2. Create workspace
      const workspace = await createWorkspace({
        name: businessName,
        slug,
        ownerId: clientUser.id,
        plan: plan || 'starter',
        settings: {},
      });

      // 3. Create workspace membership
      await db.insert(workspaceMemberships).values({
        workspaceId: workspace.id,
        userId: clientUser.id,
        role: "owner",
        status: "active",
        acceptedAt: new Date(),
      });

      // 4. Validate industry against INDUSTRY_TEMPLATES
      const templateId = industry || 'restaurant'; // Default to restaurant instead of 'general'
      const template = INDUSTRY_TEMPLATES[templateId];
      if (!template) {
        return res.status(400).json({ 
          error: `Invalid industry: ${industry}. Valid options: ${Object.keys(INDUSTRY_TEMPLATES).join(', ')}` 
        });
      }

      // 5. Build persona config from wizard inputs
      const personaConfig = {
        assistantName: assistantName || `${businessName} Assistant`,
        assistantRole: assistantRole || 'customer service representative',
        toneKeywords: toneKeywords || ['friendly', 'professional'],
        toneDescription: toneDescription || 'Be helpful, friendly, and professional.',
        targetCustomer: targetCustomer || '',
        uniqueSellingPoints: uniqueSellingPoints || [],
      };

      // 6. Build enhanced system prompt with persona
      const buildSystemPrompt = () => {
        let prompt = template.defaultConfig.systemPromptIntro;
        
        if (personaConfig.assistantName) {
          prompt = `Your name is ${personaConfig.assistantName}. ${prompt}`;
        }
        if (personaConfig.assistantRole) {
          prompt += ` You are the ${personaConfig.assistantRole} for ${businessName}.`;
        }
        if (personaConfig.toneDescription) {
          prompt += ` ${personaConfig.toneDescription}`;
        }
        if (personaConfig.targetCustomer) {
          prompt += ` Your target customers are: ${personaConfig.targetCustomer}.`;
        }
        if (personaConfig.uniqueSellingPoints && personaConfig.uniqueSellingPoints.length > 0) {
          prompt += ` Key selling points to highlight: ${personaConfig.uniqueSellingPoints.join(', ')}.`;
        }
        
        return prompt;
      };

      // 7. Merge template FAQs with custom FAQs
      const mergedFaqs = faqs && faqs.length > 0 ? faqs : template.defaultConfig.faqs;

      // 8. Create bot in database
      const botId = `${slug}_assistant`;
      await db.insert(bots).values({
        botId,
        workspaceId: workspace.id,
        name: personaConfig.assistantName,
        botType: template.botType,
        businessProfile: {
          businessName,
          type: template.botType,
          location: businessLocation ? `${businessLocation.city || ''}, ${businessLocation.state || ''}`.trim() : '',
          phone: contactPhone || '',
          email: contactEmail,
          website: websiteUrl || '',
          hours: {},
          services: template.defaultConfig.businessProfile.services,
          personaConfig, // Store persona config inside businessProfile
        } as any,
        systemPrompt: buildSystemPrompt(),
        theme: {
          primaryColor: "#06b6d4",
          welcomeMessage: `Welcome to ${businessName}! How can I help you today?`,
        },
        status: "active",
      });

      // 9. Create bot settings with FAQs
      await db.insert(botSettings).values({
        botId,
        faqs: mergedFaqs,
        rules: {
          allowedTopics: ["general information", "services", "pricing", "contact methods", "hours of operation"],
          forbiddenTopics: ["medical advice", "legal advice", "financial advice"],
        },
        automations: {},
      });

      // 10. Create client settings
      await db.insert(clientSettings).values({
        clientId: slug,
        businessName,
        tagline: personaConfig.assistantRole ? `Your ${personaConfig.assistantRole}` : "Welcome to our business",
        primaryEmail: contactEmail,
        primaryPhone: contactPhone || '',
        city: businessLocation?.city || '',
        state: businessLocation?.state || '',
        websiteUrl: websiteUrl || '',
        status: "active",
        knowledgeBase: {
          about: `Welcome to ${businessName}.`,
          requirements: "",
          pricing: "",
          application: "",
        },
        operatingHours: {
          enabled: false,
          timezone: "America/New_York",
          schedule: {
            monday: { open: "09:00", close: "17:00", enabled: true },
            tuesday: { open: "09:00", close: "17:00", enabled: true },
            wednesday: { open: "09:00", close: "17:00", enabled: true },
            thursday: { open: "09:00", close: "17:00", enabled: true },
            friday: { open: "09:00", close: "17:00", enabled: true },
            saturday: { open: "09:00", close: "17:00", enabled: false },
            sunday: { open: "09:00", close: "17:00", enabled: false },
          },
          afterHoursMessage: "We're currently closed. Please leave a message and we'll get back to you.",
        },
      });

      // 11. Create default automation workflows for leads and bookings
      const defaultAutomations = [
        {
          botId,
          name: "New Lead – Tag & Status",
          description: "Automatically tags new leads with 'inbound' and sets status tracking",
          triggerType: "lead_captured",
          triggerConfig: { eventType: "lead_captured" },
          conditions: [],
          actions: [
            {
              id: "action_1",
              type: "tag_session" as const,
              order: 1,
              config: { tags: ["inbound", "new-lead"] }
            }
          ],
          status: "active",
          priority: 10,
          throttleSeconds: 0,
          maxExecutionsPerSession: 1,
        },
        {
          botId,
          name: "New Booking – Notification",
          description: "Automatically tags new bookings and notifies staff",
          triggerType: "appointment_booked",
          triggerConfig: { eventType: "appointment_booked" },
          conditions: [],
          actions: [
            {
              id: "action_1",
              type: "tag_session" as const,
              order: 1,
              config: { tags: ["booking", "appointment"] }
            },
            {
              id: "action_2",
              type: "notify_staff" as const,
              order: 2,
              config: { message: `New booking received for ${businessName}` }
            }
          ],
          status: "active",
          priority: 10,
          throttleSeconds: 0,
          maxExecutionsPerSession: 1,
        }
      ];

      let automationsCreated = 0;
      for (const automation of defaultAutomations) {
        try {
          await storage.createAutomationWorkflow(automation as any);
          automationsCreated++;
        } catch (err) {
          structuredLogger.warn(`Failed to create default automation "${automation.name}":`, err);
        }
      }

      // 12. Log this action
      await storage.createSystemLog({
        level: 'info',
        source: 'super-admin',
        message: `New client created via wizard: ${businessName} (${slug})`,
        workspaceId: workspace.id,
        details: {
          industry: industry || 'general',
          templateUsed: templateId,
          contactEmail,
          botId,
          personaConfigured: !!(assistantName || assistantRole || toneDescription),
          faqCount: mergedFaqs.length,
          automationsCreated,
        } as any,
      });

      // 13. Generate widget embed code
      const baseUrl = req.protocol + '://' + req.get('host');
      const widgetEmbedCode = `<script>
!function(w,d,s,id,f){if(d.getElementById(id))return;
  var js=d.createElement(s);js.id=id;js.src=f;js.async=1;
  d.head.appendChild(js);
  js.onload=function(){tcai('init',{botId:'${botId}',clientId:'${slug}'})};
}(window,document,'script','tcai-widget','${baseUrl}/widget/embed.js');
</script>`;

      // 14. Return success response with all relevant info
      res.status(201).json({
        success: true,
        workspace: {
          id: workspace.id,
          slug,
          name: businessName,
          plan: plan || 'starter',
        },
        bot: {
          botId,
          name: personaConfig.assistantName,
          type: template.botType,
          faqCount: mergedFaqs.length,
          automationsCreated,
        },
        clientCredentials: {
          email: contactEmail,
          temporaryPassword,
          loginUrl: '/login',
          dashboardUrl: '/client/dashboard',
          message: 'Share these credentials with your client. They can change their password after logging in.',
        },
        widgetEmbedCode,
        viewAsClientUrl: `/client/dashboard?impersonate=${slug}`,
      });

    } catch (error: any) {
      structuredLogger.error("New client wizard error:", { error: error?.message, stack: error?.stack });
      res.status(500).json({ 
        error: "Failed to create client",
        details: error?.message || "Unknown error"
      });
    }
  });

  // =============================================
  // DEMO WORKSPACES ENDPOINTS
  // =============================================
  
  // Get all demo workspaces
  app.get("/api/super-admin/demo-workspaces", requireSuperAdmin, async (req, res) => {
    try {
      const demoWorkspaces = await db
        .select()
        .from(workspaces)
        .where(eq(workspaces.isDemo, true));
      
      // Enrich with bot info
      const enrichedWorkspaces = await Promise.all(demoWorkspaces.map(async (ws) => {
        // Get associated bots
        const wsBots = await db
          .select()
          .from(bots)
          .where(eq(bots.workspaceId, ws.id));
        
        return {
          id: ws.id,
          name: ws.name,
          slug: ws.slug,
          plan: ws.plan,
          isDemo: ws.isDemo,
          createdAt: ws.createdAt,
          bots: wsBots.map(b => ({
            botId: b.botId,
            name: b.name,
            botType: b.botType,
          })),
          demoPageUrl: `/demo/${ws.slug.replace(/_/g, '-')}`,
          viewAsClientUrl: `/client/dashboard?impersonate=${ws.slug}`,
        };
      }));
      
      res.json({ demoWorkspaces: enrichedWorkspaces });
    } catch (error) {
      structuredLogger.error("Get demo workspaces error:", error);
      res.status(500).json({ error: "Failed to fetch demo workspaces" });
    }
  });

  // Reset demo workspace data (clears and reseeds)
  app.post("/api/super-admin/demo-workspaces/:slug/reset", requireSuperAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      
      // Get workspace and verify it's a demo
      const workspace = await getWorkspaceBySlug(slug);
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      if (!(workspace as any).isDemo) {
        return res.status(403).json({ error: "Only demo workspaces can be reset" });
      }
      
      // Check if this is a known demo workspace with seed data
      const demoConfig = getDemoConfig(slug);
      if (!demoConfig) {
        // Just clear data if no seed config available
        const clientId = slug;
        await db.delete(appointments).where(eq(appointments.clientId, clientId));
        await db.delete(leads).where(eq(leads.clientId, clientId));
        await db.delete(chatAnalyticsEvents).where(eq(chatAnalyticsEvents.clientId, clientId));
        await db.delete(chatSessions).where(eq(chatSessions.clientId, clientId));
        await db.delete(dailyAnalytics).where(eq(dailyAnalytics.clientId, clientId));
        
        await storage.createSystemLog({
          level: 'info',
          source: 'super-admin',
          message: `Demo workspace ${slug} data cleared (no seed config)`,
          workspaceId: (workspace as any).id,
          details: { resetBy: req.session?.userId?.toString() || 'unknown' } as any,
        });
        
        return res.json({ 
          success: true, 
          message: `Demo data for ${slug} has been cleared`,
          workspace: { slug, name: (workspace as any).name },
          stats: { leads: 0, bookings: 0, sessions: 0 },
        });
      }
      
      // Reset and reseed with demo data
      const result = await resetDemoWorkspace(slug);
      
      // Log this action
      await storage.createSystemLog({
        level: 'info',
        source: 'super-admin',
        message: `Demo workspace ${slug} data reset and reseeded`,
        workspaceId: (workspace as any).id,
        details: { 
          resetBy: req.session?.userId,
          stats: result.stats,
        } as any,
      });
      
      // Audit log for demo reset
      const audit = createAuditHelper(req);
      await audit.log('demo_reset', 'workspace', {
        workspaceId: (workspace as any).id,
        resourceId: slug,
        details: {
          workspaceName: (workspace as any).name,
          stats: result.stats,
        },
      });
      
      res.json({ 
        success: true, 
        message: `Demo data for ${slug} has been reset and reseeded`,
        workspace: { slug, name: (workspace as any).name },
        stats: result.stats,
      });
    } catch (error) {
      structuredLogger.error("Reset demo error:", error);
      res.status(500).json({ error: "Failed to reset demo data" });
    }
  });

  // Seed all demo workspaces (create them if they don't exist)
  app.post("/api/super-admin/demo-workspaces/seed-all", requireSuperAdmin, async (req, res) => {
    try {
      const result = await seedAllDemoWorkspaces();
      
      await storage.createSystemLog({
        level: 'info',
        source: 'super-admin',
        message: `Seeded ${result.seeded.length} demo workspaces`,
        details: { seeded: result.seeded, errors: result.errors } as any,
      });
      
      res.json({ 
        success: true, 
        message: `Seeded ${result.seeded.length} demo workspaces`,
        seeded: result.seeded,
        errors: result.errors,
        availableDemos: getDemoSlugs(),
      });
    } catch (error) {
      structuredLogger.error("Seed all demos error:", error);
      res.status(500).json({ error: "Failed to seed demo workspaces" });
    }
  });

  // =============================================
  // INTEGRATION / WIDGET EMBED ENDPOINTS
  // =============================================

  // Get integration info and widget embed code for a workspace
  app.get("/api/super-admin/workspaces/:slug/integration", requireSuperAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      
      const workspace = await getWorkspaceBySlug(slug);
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Get the primary bot for this workspace
      const workspaceBots = await getBotsByWorkspaceId((workspace as any).id);
      
      // Handle case where workspace has no bots yet
      if (!workspaceBots || workspaceBots.length === 0) {
        // Generate a placeholder embed code using workspace slug as bot ID
        const placeholderBotId = `${slug}_main`;
        const embedOptions: WidgetEmbedOptions = {
          workspaceSlug: slug,
          botId: placeholderBotId,
          primaryColor: "#00E5CC",
          businessName: (workspace as any).name || "AI Assistant",
          businessSubtitle: "Powered by TCAI",
          showGreetingPopup: false,
        };
        
        const widgetEmbedCode = getWidgetEmbedCode(embedOptions);
        const instructions = getEmbedInstructions();
        
        return res.json({
          workspaceSlug: slug,
          workspaceName: (workspace as any).name,
          workspaceId: (workspace as any).id,
          primaryBotId: null,
          primaryBotName: null,
          hasBot: false,
          needsBot: true,
          message: "No bot configured yet. Create an assistant first, then the embed code will use its settings.",
          widgetEmbedCode,
          embedInstructions: instructions,
          customization: {
            primaryColor: embedOptions.primaryColor,
            businessName: embedOptions.businessName,
            businessSubtitle: embedOptions.businessSubtitle,
          },
        });
      }
      
      // Use the first bot as the primary
      const primaryBot = workspaceBots[0];
      
      // Build embed options from bot configuration
      const embedOptions: WidgetEmbedOptions = {
        workspaceSlug: slug,
        botId: primaryBot.botId,
        primaryColor: (primaryBot as any).theme?.primaryColor || "#00E5CC",
        businessName: primaryBot.businessProfile?.businessName || primaryBot.name || "AI Assistant",
        businessSubtitle: primaryBot.businessProfile?.type || "Powered by TCAI",
        showGreetingPopup: false,
      };
      
      const widgetEmbedCode = getWidgetEmbedCode(embedOptions);
      const instructions = getEmbedInstructions();
      
      res.json({
        workspaceSlug: slug,
        workspaceName: (workspace as any).name,
        workspaceId: (workspace as any).id,
        primaryBotId: primaryBot.botId,
        primaryBotName: primaryBot.name,
        hasBot: true,
        needsBot: false,
        widgetEmbedCode,
        embedInstructions: instructions,
        customization: {
          primaryColor: embedOptions.primaryColor,
          businessName: embedOptions.businessName,
          businessSubtitle: embedOptions.businessSubtitle,
        },
      });
    } catch (error) {
      structuredLogger.error("Get integration error:", error);
      res.status(500).json({ error: "Failed to get integration info" });
    }
  });

  // Update workspace (name, plan, settings, owner, adminNotes)
  app.patch("/api/super-admin/workspaces/:slug", requireSuperAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      const { name, ownerId, plan, settings, adminNotes } = req.body;
      
      const existing = await getWorkspaceBySlug(slug);
      if (!existing) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Validate owner if provided
      if (ownerId) {
        const [owner] = await db.select().from(adminUsers).where(eq(adminUsers.id, ownerId)).limit(1);
        if (!owner) {
          return res.status(400).json({ error: "Invalid ownerId - user not found" });
        }
      }
      
      const workspace = await updateWorkspace(slug, { name, ownerId, plan, settings, adminNotes });
      
      // Log this action
      await storage.createSystemLog({
        level: 'info',
        source: 'super-admin',
        message: `Workspace ${slug} updated`,
        workspaceId: workspace.id,
        details: { name, plan, ownerId, adminNotes: adminNotes ? 'updated' : undefined } as any,
      });
      
      res.json(workspace);
    } catch (error) {
      structuredLogger.error("Update workspace error:", error);
      res.status(500).json({ error: "Failed to update workspace" });
    }
  });

  // Delete workspace
  app.delete("/api/super-admin/workspaces/:slug", requireSuperAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      
      const existing = await getWorkspaceBySlug(slug);
      if (!existing) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Get bots associated with this workspace to cascade delete
      const allBots = getAllBotConfigs();
      const workspaceBots = allBots.filter(b => b.clientId === slug);
      
      // Delete associated bots (from file system and database)
      for (const bot of workspaceBots) {
        try {
          // Delete from database
          await db.delete(bots).where(eq(bots.botId, bot.botId));
          await db.delete(botSettings).where(eq(botSettings.botId, bot.botId));
          
          // Delete config file if exists
          const configPath = path.join(process.cwd(), 'data', 'bot-configs', `${bot.botId}.json`);
          if (fs.existsSync(configPath)) {
            fs.unlinkSync(configPath);
          }
        } catch (e) {
          structuredLogger.error(`Error deleting bot ${bot.botId}:`, e);
        }
      }
      
      // Log before delete
      await storage.createSystemLog({
        level: 'warning',
        source: 'super-admin',
        message: `Workspace ${slug} deleted`,
        workspaceId: (existing as any).id,
        details: { deletedBots: workspaceBots.length } as any,
      });
      
      await deleteWorkspace(slug);
      
      res.json({ success: true, slug, deletedBots: workspaceBots.length });
    } catch (error) {
      structuredLogger.error("Delete workspace error:", error);
      res.status(500).json({ error: "Failed to delete workspace" });
    }
  });

  // =============================================
  // SUPER-ADMIN: WORKSPACE DETAIL ENDPOINTS
  // =============================================

  // Get workspace conversations
  app.get("/api/super-admin/workspaces/:slug/conversations", requireSuperAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      
      const workspace = await getWorkspaceBySlug(slug);
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Get all bots for this workspace
      const allBots = getAllBotConfigs();
      const wsBots = allBots.filter(b => b.clientId === slug || b.clientId === (workspace as any).id);
      
      // Aggregate conversations from all bots
      const allConversations: any[] = [];
      for (const bot of wsBots) {
        const sessions = await storage.getClientRecentSessions(bot.clientId, bot.botId, 100);
        for (const session of sessions) {
          const metadata = session.metadata as Record<string, any> || {};
          allConversations.push({
            id: session.id,
            sessionId: session.sessionId,
            botId: bot.botId,
            visitorName: metadata.visitorName || null,
            visitorEmail: metadata.visitorEmail || null,
            visitorPhone: metadata.visitorPhone || null,
            messageCount: session.userMessageCount + session.botMessageCount,
            sentiment: metadata.sentiment || null,
            summary: metadata.aiSummary || null,
            createdAt: session.startedAt?.toISOString(),
            updatedAt: session.endedAt?.toISOString() || session.startedAt?.toISOString(),
          });
        }
      }
      
      // Sort by date, most recent first
      allConversations.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      
      res.json({
        conversations: allConversations,
        total: allConversations.length,
      });
    } catch (error) {
      structuredLogger.error("Get workspace conversations error:", error);
      res.status(500).json({ error: "Failed to fetch workspace conversations" });
    }
  });

  // Get workspace leads
  app.get("/api/super-admin/workspaces/:slug/leads", requireSuperAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      
      const workspace = await getWorkspaceBySlug(slug);
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Get leads for this workspace (using slug as clientId)
      const { leads } = await storage.getLeads(slug, { limit: 500 });
      
      const formattedLeads = leads.map(lead => ({
        id: lead.id,
        name: lead.name || 'Anonymous',
        email: lead.email || null,
        phone: lead.phone || null,
        context: lead.conversationPreview || lead.notes || null,
        status: lead.status || 'new',
        createdAt: lead.createdAt?.toISOString(),
        updatedAt: lead.updatedAt?.toISOString() || null,
        tags: lead.tags || [],
        notes: lead.notes || null,
      }));
      
      res.json({
        leads: formattedLeads,
        total: formattedLeads.length,
      });
    } catch (error) {
      structuredLogger.error("Get workspace leads error:", error);
      res.status(500).json({ error: "Failed to fetch workspace leads" });
    }
  });

  // Get workspace appointments/bookings (for admin view)
  app.get("/api/super-admin/workspaces/:slug/appointments", requireSuperAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      
      const workspace = await getWorkspaceBySlug(slug);
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Get appointments for this workspace (using slug as clientId)
      const appointmentsList = await storage.getAllAppointments(slug);
      
      const formattedAppointments = appointmentsList.map((apt: any) => ({
        id: apt.id,
        name: apt.name || 'Unknown',
        contact: apt.contact || null,
        email: apt.email || null,
        appointmentType: apt.appointmentType || 'appointment',
        preferredTime: apt.preferredTime || 'To be confirmed',
        status: apt.status || 'new',
        notes: apt.notes || null,
        createdAt: apt.createdAt?.toISOString(),
      }));
      
      res.json({
        appointments: formattedAppointments,
        total: formattedAppointments.length,
      });
    } catch (error) {
      structuredLogger.error("Get workspace appointments error:", error);
      res.status(500).json({ error: "Failed to fetch workspace appointments" });
    }
  });

  // Get workspace users
  app.get("/api/super-admin/workspaces/:slug/users", requireSuperAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      
      const workspace = await getWorkspaceBySlug(slug);
      if (!workspace) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      
      // Get users associated with this workspace
      // Users with clientId matching the workspace slug are members
      const workspaceUsers = await db.select({
        id: adminUsers.id,
        email: adminUsers.username,
        username: adminUsers.username,
        role: adminUsers.role,
        createdAt: adminUsers.createdAt,
      }).from(adminUsers).where(eq(adminUsers.clientId, slug));
      
      res.json({ users: workspaceUsers });
    } catch (error) {
      structuredLogger.error("Get workspace users error:", error);
      res.status(500).json({ error: "Failed to fetch workspace users" });
    }
  });

  // =============================================
  // SUPER-ADMIN: ENHANCED BOT STATS
  // =============================================

  // Get bot with enriched stats (for control center)
  app.get("/api/super-admin/bots/:botId/stats", requireSuperAdmin, async (req, res) => {
    try {
      const { botId } = req.params;
      const { days: daysParam } = req.query;
      const days = daysParam ? parseInt(String(daysParam), 10) : 7;
      
      const bot = getBotConfigByBotId(botId);
      if (!bot) {
        return res.status(404).json({ error: "Bot not found" });
      }
      
      const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
      const summary = await storage.getClientAnalyticsSummary(bot.clientId, bot.botId, startDate);
      const { leads } = await storage.getLeads(bot.clientId, { limit: 1000 });
      const recentLeads = leads.filter(l => l.createdAt >= startDate);
      const recentSessions = await storage.getClientRecentSessions(bot.clientId, bot.botId, 5);
      
      res.json({
        botId,
        clientId: bot.clientId,
        name: bot.name,
        businessName: bot.businessProfile?.businessName,
        stats: {
          conversations: summary.totalConversations,
          leads: recentLeads.length,
          appointments: summary.appointmentRequests,
          messages: summary.totalMessages,
          avgResponseTimeMs: summary.avgResponseTimeMs,
        },
        lastActive: recentSessions[0]?.startedAt?.toISOString() || null,
        dateRange: { days, startDate: startDate.toISOString() },
      });
    } catch (error) {
      structuredLogger.error("Get bot stats error:", error);
      res.status(500).json({ error: "Failed to fetch bot stats" });
    }
  });

  // =============================================
  // NEEDS REVIEW / FLAGGED CONVERSATIONS API
  // =============================================

  // Get all flagged conversations that need admin review
  app.get("/api/super-admin/needs-review", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId, status, limit = '50' } = req.query;
      
      const flaggedConversations = await storage.getFlaggedConversations({
        clientId: clientId as string,
        status: status as string,
        limit: parseInt(limit as string)
      });
      
      res.json({ conversations: flaggedConversations });
    } catch (error) {
      structuredLogger.error("Get flagged conversations error:", error);
      res.status(500).json({ error: "Failed to get flagged conversations" });
    }
  });

  // Get count of pending reviews
  app.get("/api/super-admin/needs-review/count", requireSuperAdmin, async (req, res) => {
    try {
      const count = await storage.getFlaggedConversationsCount();
      res.json({ count });
    } catch (error) {
      structuredLogger.error("Get flagged count error:", error);
      res.status(500).json({ error: "Failed to get count" });
    }
  });

  // Mark a conversation as reviewed
  app.post("/api/super-admin/needs-review/:sessionId/review", requireSuperAdmin, async (req, res) => {
    try {
      const { sessionId } = req.params;
      const { adminNotes, action } = req.body; // action: 'resolved', 'add_to_faq', 'update_knowledge'
      const adminUser = (req.session as any).user;
      
      await storage.markConversationReviewed(sessionId, {
        reviewedBy: adminUser?.username || 'admin',
        adminNotes,
        action
      });
      
      res.json({ success: true });
    } catch (error) {
      structuredLogger.error("Mark reviewed error:", error);
      res.status(500).json({ error: "Failed to mark as reviewed" });
    }
  });

  // Dismiss a flagged conversation (mark as not needing review)
  app.post("/api/super-admin/needs-review/:sessionId/dismiss", requireSuperAdmin, async (req, res) => {
    try {
      const { sessionId } = req.params;
      const adminUser = (req.session as any).user;
      
      await storage.dismissFlaggedConversation(sessionId, adminUser?.username || 'admin');
      
      res.json({ success: true });
    } catch (error) {
      structuredLogger.error("Dismiss flagged error:", error);
      res.status(500).json({ error: "Failed to dismiss" });
    }
  });

  // Get conversation messages for review
  app.get("/api/super-admin/sessions/:sessionId/messages", requireSuperAdmin, async (req, res) => {
    try {
      const { sessionId } = req.params;
      
      const messages = await storage.getSessionMessages(sessionId);
      const session = await storage.getSessionById(sessionId);
      
      res.json({ messages, session });
    } catch (error) {
      structuredLogger.error("Get session messages error:", error);
      res.status(500).json({ error: "Failed to get messages" });
    }
  });

  // Admin notes for clients
  app.get("/api/super-admin/clients/:clientId/notes", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const notes = await storage.getClientNotes(clientId);
      res.json({ notes });
    } catch (error) {
      structuredLogger.error("Get client notes error:", error);
      res.status(500).json({ error: "Failed to get notes" });
    }
  });

  app.post("/api/super-admin/clients/:clientId/notes", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      const { content, category } = req.body;
      const adminUser = (req.session as any).user;
      
      const note = await storage.addClientNote({
        clientId,
        content,
        category,
        createdBy: adminUser?.username || 'admin'
      });
      
      res.json({ note });
    } catch (error) {
      structuredLogger.error("Add client note error:", error);
      res.status(500).json({ error: "Failed to add note" });
    }
  });

  app.delete("/api/super-admin/clients/:clientId/notes/:noteId", requireSuperAdmin, async (req, res) => {
    try {
      const { noteId } = req.params;
      await storage.deleteClientNote(noteId);
      res.json({ success: true });
    } catch (error) {
      structuredLogger.error("Delete client note error:", error);
      res.status(500).json({ error: "Failed to delete note" });
    }
  });

  // =============================================
  // DEMO RESET ENDPOINT - Faith House Demo
  // =============================================
  // 
  // IMPORTANT: Faith House Workspace Architecture
  // - "faith_house" is the CANONICAL workspace used by:
  //   - Client login: demo_faith_house (password: demo123)
  //   - Super-admin workspace view for "Faith House"
  //
  // - "faith_house_demo" is a SEPARATE demo workspace used ONLY by:
  //   - /demo/faith-house public demo page
  //   - This reset endpoint
  //   - Isolated from canonical to allow safe demo resets
  //
  // The demo_faith_house user's client_id points to "faith_house" (canonical),
  // so admin and client dashboards show the same data.
  // =============================================
  
  app.post("/api/admin/demo/faith-house/reset", requireSuperAdmin, async (req, res) => {
    try {
      const DEMO_CLIENT_ID = "faith_house_demo";
      const DEMO_BOT_ID = "faith_house_demo_main";
      
      // CRITICAL SAFETY CHECK: Verify target is actually a demo workspace
      const [workspace] = await db.select()
        .from(workspaces)
        .where(eq(workspaces.slug, DEMO_CLIENT_ID))
        .limit(1);
      
      if (!workspace) {
        structuredLogger.error(`[DEMO RESET] Workspace not found: ${DEMO_CLIENT_ID}`);
        return res.status(404).json({ error: "Demo workspace not found" });
      }
      
      if (!workspace.isDemo) {
        structuredLogger.error(`[DEMO RESET] SAFETY ABORT: Attempted reset on non-demo workspace: ${DEMO_CLIENT_ID}`);
        return res.status(403).json({ 
          error: "Cannot reset non-demo workspace",
          message: "This is a safety feature to prevent accidental data loss on live workspaces."
        });
      }
      
      structuredLogger.info(`[DEMO RESET] Starting reset for demo workspace: ${DEMO_CLIENT_ID}`);
      
      // Delete demo data in order (respecting foreign key constraints)
      // 1. Delete appointments
      const deletedAppointments = await db.delete(appointments)
        .where(eq(appointments.clientId, DEMO_CLIENT_ID))
        .returning();
      
      // 2. Delete leads
      const deletedLeads = await db.delete(leads)
        .where(eq(leads.clientId, DEMO_CLIENT_ID))
        .returning();
      
      // 3. Delete chat messages (by sessionId in sessions belonging to demo)
      const demoSessions = await db.select({ sessionId: chatSessions.sessionId })
        .from(chatSessions)
        .where(eq(chatSessions.clientId, DEMO_CLIENT_ID));
      
      let deletedMessages = 0;
      for (const session of demoSessions) {
        const deleted = await db.delete(conversationMessages)
          .where(eq(conversationMessages.conversationId, session.sessionId))
          .returning();
        deletedMessages += deleted.length;
      }
      
      // 4. Delete chat analytics events
      const deletedAnalyticsEvents = await db.delete(chatAnalyticsEvents)
        .where(eq(chatAnalyticsEvents.clientId, DEMO_CLIENT_ID))
        .returning();
      
      // 5. Delete chat sessions
      const deletedSessions = await db.delete(chatSessions)
        .where(eq(chatSessions.clientId, DEMO_CLIENT_ID))
        .returning();
      
      // 6. Delete daily analytics
      const deletedDailyAnalytics = await db.delete(dailyAnalytics)
        .where(eq(dailyAnalytics.clientId, DEMO_CLIENT_ID))
        .returning();
      
      structuredLogger.info(`[DEMO RESET] Deleted: ${deletedAppointments.length} appointments, ${deletedLeads.length} leads, ${deletedMessages} messages, ${deletedSessions.length} sessions, ${deletedAnalyticsEvents.length} analytics events, ${deletedDailyAnalytics.length} daily analytics`);
      
      // Re-seed demo data
      const now = new Date();
      const seededData = { leads: 0, appointments: 0, sessions: 0 };
      
      // Create sample leads
      const sampleLeads = [
        { name: "Michael Thompson", phone: "(555) 123-4567", email: "michael.t@email.com", source: "chat", notes: "Interested in Phase 1 program, has prior treatment experience" },
        { name: "David Rodriguez", phone: "(555) 234-5678", email: "david.r@email.com", source: "chat", notes: "Family member reached out, brother needs help" },
        { name: "James Wilson", phone: "(555) 345-6789", email: null, source: "chat", notes: "Called about pricing, seems motivated" },
      ];
      
      for (const lead of sampleLeads) {
        await db.insert(leads).values({
          clientId: DEMO_CLIENT_ID,
          botId: DEMO_BOT_ID,
          name: lead.name,
          phone: lead.phone,
          email: lead.email,
          source: lead.source,
          notes: lead.notes,
          status: "new",
          createdAt: new Date(now.getTime() - Math.random() * 7 * 24 * 60 * 60 * 1000), // Random within last 7 days
        });
        seededData.leads++;
      }
      
      // Create sample appointments
      const sampleAppointments = [
        { name: "Michael Thompson", contact: "(555) 123-4567", email: "michael.t@email.com", appointmentType: "tour", preferredTime: "Tomorrow at 2pm", notes: "Coming with family", contactPreference: "phone" },
        { name: "Robert Johnson", contact: "(555) 456-7890", email: "robert.j@email.com", appointmentType: "phone_call", preferredTime: "Monday morning", notes: "Wants to discuss payment options", contactPreference: "phone" },
        { name: "William Davis", contact: "(555) 567-8901", email: null, appointmentType: "tour", preferredTime: "This Saturday", notes: "Referred by AA sponsor", contactPreference: "phone" },
      ];
      
      for (const apt of sampleAppointments) {
        await db.insert(appointments).values({
          clientId: DEMO_CLIENT_ID,
          botId: DEMO_BOT_ID,
          name: apt.name,
          contact: apt.contact,
          contactPreference: apt.contactPreference,
          email: apt.email,
          appointmentType: apt.appointmentType as 'tour' | 'phone_call',
          preferredTime: apt.preferredTime,
          notes: apt.notes,
          status: "pending",
          createdAt: new Date(now.getTime() - Math.random() * 5 * 24 * 60 * 60 * 1000), // Random within last 5 days
        });
        seededData.appointments++;
      }
      
      // Create sample chat sessions
      const sampleSessions = [
        { userMessages: 4, botMessages: 4, appointmentRequested: true, topics: ["tour scheduling", "program details"] },
        { userMessages: 2, botMessages: 2, appointmentRequested: false, topics: ["general inquiry"] },
        { userMessages: 6, botMessages: 6, appointmentRequested: false, topics: ["pricing", "insurance"] },
      ];
      
      for (const session of sampleSessions) {
        const sessionId = `demo_session_${Date.now()}_${Math.random().toString(36).substring(7)}`;
        await db.insert(chatSessions).values({
          sessionId,
          clientId: DEMO_CLIENT_ID,
          botId: DEMO_BOT_ID,
          userMessageCount: session.userMessages,
          botMessageCount: session.botMessages,
          totalResponseTimeMs: Math.floor(Math.random() * 2000) + 500,
          crisisDetected: false,
          appointmentRequested: session.appointmentRequested,
          needsReview: false,
          topics: session.topics,
          startedAt: new Date(now.getTime() - Math.random() * 3 * 24 * 60 * 60 * 1000),
          endedAt: null,
        });
        seededData.sessions++;
      }
      
      // Log the reset
      await storage.createSystemLog({
        level: 'info',
        source: 'demo-reset',
        message: `Demo data reset for Faith House (${DEMO_CLIENT_ID})`,
        workspaceId: workspace.id,
        details: {
          deleted: {
            appointments: deletedAppointments.length,
            leads: deletedLeads.length,
            messages: deletedMessages,
            sessions: deletedSessions.length,
          },
          seeded: seededData,
          resetBy: req.session.userId,
        } as any,
      });
      
      // Audit log for demo reset
      const audit = createAuditHelper(req);
      await audit.log('demo_reset', 'workspace', {
        workspaceId: workspace.id,
        resourceId: DEMO_CLIENT_ID,
        details: {
          workspaceName: 'Faith House Demo',
          deleted: { appointments: deletedAppointments.length, leads: deletedLeads.length, messages: deletedMessages, sessions: deletedSessions.length },
          seeded: seededData,
        },
      });
      
      res.json({
        success: true,
        message: "Demo data has been reset successfully",
        deleted: {
          appointments: deletedAppointments.length,
          leads: deletedLeads.length,
          messages: deletedMessages,
          sessions: deletedSessions.length,
          analyticsEvents: deletedAnalyticsEvents.length,
          dailyAnalytics: deletedDailyAnalytics.length,
        },
        seeded: seededData,
      });
    } catch (error) {
      structuredLogger.error("[DEMO RESET] Error resetting demo data:", error);
      res.status(500).json({ error: "Failed to reset demo data" });
    }
  });
  
  // Get demo status endpoint
  app.get("/api/admin/demo/faith-house/status", requireSuperAdmin, async (req, res) => {
    try {
      const DEMO_CLIENT_ID = "faith_house_demo";
      
      const [workspace] = await db.select()
        .from(workspaces)
        .where(eq(workspaces.slug, DEMO_CLIENT_ID))
        .limit(1);
      
      if (!workspace) {
        return res.status(404).json({ error: "Demo workspace not found" });
      }
      
      // Get counts
      const [leadsCount] = await db.select({ count: sql<number>`count(*)` })
        .from(leads)
        .where(eq(leads.clientId, DEMO_CLIENT_ID));
      
      const [appointmentsCount] = await db.select({ count: sql<number>`count(*)` })
        .from(appointments)
        .where(eq(appointments.clientId, DEMO_CLIENT_ID));
      
      const [sessionsCount] = await db.select({ count: sql<number>`count(*)` })
        .from(chatSessions)
        .where(eq(chatSessions.clientId, DEMO_CLIENT_ID));
      
      res.json({
        workspace: {
          id: workspace.id,
          name: workspace.name,
          slug: workspace.slug,
          isDemo: workspace.isDemo,
          status: workspace.status,
        },
        data: {
          leads: Number(leadsCount?.count || 0),
          appointments: Number(appointmentsCount?.count || 0),
          sessions: Number(sessionsCount?.count || 0),
        },
      });
    } catch (error) {
      structuredLogger.error("Get demo status error:", error);
      res.status(500).json({ error: "Failed to get demo status" });
    }
  });

  // =============================================
  // PAWS & SUDS DEMO RESET ENDPOINT
  // =============================================
  
  app.post("/api/admin/demo/paws-suds/reset", requireSuperAdmin, async (req, res) => {
    try {
      const DEMO_CLIENT_ID = "demo_paws_suds_grooming_demo";
      const DEMO_BOT_ID = "demo_paws_suds_grooming_demo_assistant";
      
      // CRITICAL SAFETY CHECK: Verify target is actually a demo workspace
      const [workspace] = await db.select()
        .from(workspaces)
        .where(eq(workspaces.slug, DEMO_CLIENT_ID))
        .limit(1);
      
      if (!workspace) {
        structuredLogger.error(`[DEMO RESET] Workspace not found: ${DEMO_CLIENT_ID}`);
        return res.status(404).json({ error: "Demo workspace not found" });
      }
      
      if (!workspace.isDemo) {
        structuredLogger.error(`[DEMO RESET] SAFETY ABORT: Attempted reset on non-demo workspace: ${DEMO_CLIENT_ID}`);
        return res.status(403).json({ 
          error: "Cannot reset non-demo workspace",
          message: "This is a safety feature to prevent accidental data loss on live workspaces."
        });
      }
      
      structuredLogger.info(`[DEMO RESET] Starting reset for demo workspace: ${DEMO_CLIENT_ID}`);
      
      // Delete demo data
      const deletedAppointments = await db.delete(appointments)
        .where(eq(appointments.clientId, DEMO_CLIENT_ID))
        .returning();
      
      const deletedLeads = await db.delete(leads)
        .where(eq(leads.clientId, DEMO_CLIENT_ID))
        .returning();
      
      const demoSessions = await db.select({ sessionId: chatSessions.sessionId })
        .from(chatSessions)
        .where(eq(chatSessions.clientId, DEMO_CLIENT_ID));
      
      let deletedMessages = 0;
      for (const session of demoSessions) {
        const deleted = await db.delete(conversationMessages)
          .where(eq(conversationMessages.conversationId, session.sessionId))
          .returning();
        deletedMessages += deleted.length;
      }
      
      const deletedAnalyticsEvents = await db.delete(chatAnalyticsEvents)
        .where(eq(chatAnalyticsEvents.clientId, DEMO_CLIENT_ID))
        .returning();
      
      const deletedSessions = await db.delete(chatSessions)
        .where(eq(chatSessions.clientId, DEMO_CLIENT_ID))
        .returning();
      
      const deletedDailyAnalytics = await db.delete(dailyAnalytics)
        .where(eq(dailyAnalytics.clientId, DEMO_CLIENT_ID))
        .returning();
      
      structuredLogger.info(`[DEMO RESET] Deleted: ${deletedAppointments.length} appointments, ${deletedLeads.length} leads, ${deletedMessages} messages, ${deletedSessions.length} sessions`);
      
      // Re-seed demo data for Paws & Suds
      const now = new Date();
      const seededData = { leads: 0, appointments: 0, sessions: 0 };
      
      // Create sample leads
      const sampleLeads = [
        { name: "Sarah W.", phone: "(772) 555-2345", email: "sarah.w@example.com", source: "chat", notes: "Golden Retriever needs de-shedding treatment" },
        { name: "Jennifer L.", phone: "(561) 555-6789", email: "jennifer.l@example.com", source: "chat", notes: "New puppy owner, interested in first grooming" },
        { name: "Amanda C.", phone: "(772) 555-0123", email: "amanda.c@example.com", source: "chat", notes: "Regular customer, cat grooming inquiry" },
      ];
      
      for (const lead of sampleLeads) {
        await db.insert(leads).values({
          clientId: DEMO_CLIENT_ID,
          botId: DEMO_BOT_ID,
          name: lead.name,
          phone: lead.phone,
          email: lead.email,
          source: lead.source,
          status: "new",
          notes: lead.notes,
          createdAt: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
        });
        seededData.leads++;
      }
      
      // Create sample appointments
      const sampleAppointments = [
        { name: "Sarah W.", contact: "(772) 555-2345", email: "sarah.w@example.com", type: "deshedding", time: "Saturday at 11:00 AM", notes: "Golden Retriever - heavy shedder" },
        { name: "Mike B.", contact: "(772) 555-7890", email: "mike.b@example.com", type: "full-grooming", time: "Friday at 9:00 AM", notes: "Standard Poodle - regular client" },
      ];
      
      for (const apt of sampleAppointments) {
        await db.insert(appointments).values({
          clientId: DEMO_CLIENT_ID,
          botId: DEMO_BOT_ID,
          name: apt.name,
          contact: apt.contact,
          email: apt.email,
          appointmentType: apt.type,
          preferredTime: apt.time,
          status: "new",
          notes: apt.notes,
        });
        seededData.appointments++;
      }
      
      await storage.createSystemLog({
        level: 'info',
        source: 'demo-reset',
        message: `Demo data reset for Paws & Suds (${DEMO_CLIENT_ID})`,
        workspaceId: workspace.id,
        details: {
          deleted: {
            appointments: deletedAppointments.length,
            leads: deletedLeads.length,
            messages: deletedMessages,
            sessions: deletedSessions.length,
          },
          seeded: seededData,
          resetBy: req.session.userId,
        } as any,
      });
      
      // Audit log for demo reset
      const audit = createAuditHelper(req);
      await audit.log('demo_reset', 'workspace', {
        workspaceId: workspace.id,
        resourceId: DEMO_CLIENT_ID,
        details: {
          workspaceName: 'Paws & Suds Demo',
          deleted: { appointments: deletedAppointments.length, leads: deletedLeads.length, messages: deletedMessages, sessions: deletedSessions.length },
          seeded: seededData,
        },
      });
      
      res.json({
        success: true,
        message: "Paws & Suds demo data has been reset successfully",
        deleted: {
          appointments: deletedAppointments.length,
          leads: deletedLeads.length,
          messages: deletedMessages,
          sessions: deletedSessions.length,
        },
        seeded: seededData,
      });
    } catch (error) {
      structuredLogger.error("[DEMO RESET] Error resetting Paws & Suds demo data:", error);
      res.status(500).json({ error: "Failed to reset demo data" });
    }
  });
  
  // Get Paws & Suds demo status endpoint
  app.get("/api/admin/demo/paws-suds/status", requireSuperAdmin, async (req, res) => {
    try {
      const DEMO_CLIENT_ID = "demo_paws_suds_grooming_demo";
      
      const [workspace] = await db.select()
        .from(workspaces)
        .where(eq(workspaces.slug, DEMO_CLIENT_ID))
        .limit(1);
      
      if (!workspace) {
        return res.status(404).json({ error: "Demo workspace not found" });
      }
      
      const [leadsCount] = await db.select({ count: sql<number>`count(*)` })
        .from(leads)
        .where(eq(leads.clientId, DEMO_CLIENT_ID));
      
      const [appointmentsCount] = await db.select({ count: sql<number>`count(*)` })
        .from(appointments)
        .where(eq(appointments.clientId, DEMO_CLIENT_ID));
      
      const [sessionsCount] = await db.select({ count: sql<number>`count(*)` })
        .from(chatSessions)
        .where(eq(chatSessions.clientId, DEMO_CLIENT_ID));
      
      res.json({
        workspace: {
          id: workspace.id,
          name: workspace.name,
          slug: workspace.slug,
          isDemo: workspace.isDemo,
          status: workspace.status,
        },
        data: {
          leads: Number(leadsCount?.count || 0),
          appointments: Number(appointmentsCount?.count || 0),
          sessions: Number(sessionsCount?.count || 0),
        },
      });
    } catch (error) {
      structuredLogger.error("Get Paws & Suds demo status error:", error);
      res.status(500).json({ error: "Failed to get demo status" });
    }
  });

  // =============================================
  // PHASE 4: AUTOMATION V2 API ENDPOINTS
  // =============================================

  // Automation workflow Zod schemas
  const automationWorkflowSchema = z.object({
    name: z.string().min(1).max(100),
    description: z.string().optional().nullable(),
    botId: z.string().min(1),
    triggerType: z.enum(['keyword', 'schedule', 'inactivity', 'message_count', 'lead_captured', 'appointment_booked']),
    triggerConfig: z.object({
      keywords: z.array(z.string()).optional(),
      matchType: z.enum(['exact', 'contains', 'regex']).optional(),
      schedule: z.string().optional(),
      inactivityMinutes: z.number().optional(),
      messageCountThreshold: z.number().optional(),
      eventType: z.string().optional(),
    }).optional(),
    conditions: z.array(z.object({
      id: z.string(),
      field: z.string(),
      operator: z.enum(['equals', 'contains', 'greater_than', 'less_than', 'matches_regex', 'in_list']),
      value: z.union([z.string(), z.number(), z.array(z.string())]),
      groupId: z.string().optional(),
    })).optional(),
    actions: z.array(z.object({
      id: z.string(),
      type: z.enum(['send_message', 'capture_lead', 'tag_session', 'notify_staff', 'send_email', 'delay', 'set_variable']),
      order: z.number(),
      config: z.object({
        message: z.string().optional(),
        delay: z.number().optional(),
        template: z.string().optional(),
        channel: z.enum(['chat', 'email', 'sms']).optional(),
        tags: z.array(z.string()).optional(),
        variable: z.object({ name: z.string(), value: z.string() }).optional(),
      }),
    })).optional(),
    status: z.enum(['active', 'paused', 'draft']).optional(),
    priority: z.number().optional(),
    throttleSeconds: z.number().optional(),
    maxExecutionsPerSession: z.number().optional().nullable(),
    scheduleTimezone: z.string().optional(),
  });

  // List automation workflows for a bot
  app.get("/api/bots/:botId/automations", requireClientAuth, async (req, res) => {
    try {
      const { botId } = req.params;
      
      // Validate tenant access
      if (!await validateBotAccess(req, res, botId)) return;
      
      const workflows = await storage.getAutomationWorkflowsByBot(botId);
      res.json({ workflows });
    } catch (error) {
      structuredLogger.error("Get automations error:", error);
      res.status(500).json({ error: "Failed to get automation workflows" });
    }
  });

  // Get a single automation workflow
  app.get("/api/bots/:botId/automations/:workflowId", requireClientAuth, async (req, res) => {
    try {
      const { botId, workflowId } = req.params;
      
      // Validate tenant access
      if (!await validateBotAccess(req, res, botId)) return;
      
      const workflow = await storage.getAutomationWorkflow(workflowId);
      
      if (!workflow || workflow.botId !== botId) {
        return res.status(404).json({ error: "Automation workflow not found" });
      }
      
      res.json({ workflow });
    } catch (error) {
      structuredLogger.error("Get automation error:", error);
      res.status(500).json({ error: "Failed to get automation workflow" });
    }
  });

  // Create a new automation workflow
  app.post("/api/bots/:botId/automations", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const { botId } = req.params;
      
      // Validate tenant access
      if (!await validateBotAccess(req, res, botId)) return;
      
      const validation = automationWorkflowSchema.safeParse({ ...req.body, botId });
      
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid automation data", details: validation.error.format() });
      }
      
      const workflow = await storage.createAutomationWorkflow(validation.data as any);
      res.status(201).json({ workflow });
    } catch (error) {
      structuredLogger.error("Create automation error:", error);
      res.status(500).json({ error: "Failed to create automation workflow" });
    }
  });

  // Update an automation workflow
  app.patch("/api/bots/:botId/automations/:workflowId", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const { botId, workflowId } = req.params;
      
      // Validate tenant access
      if (!await validateBotAccess(req, res, botId)) return;
      
      const existing = await storage.getAutomationWorkflow(workflowId);
      
      if (!existing || existing.botId !== botId) {
        return res.status(404).json({ error: "Automation workflow not found" });
      }
      
      const partialSchema = automationWorkflowSchema.partial();
      const validation = partialSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid update data", details: validation.error.format() });
      }
      
      const updated = await storage.updateAutomationWorkflow(workflowId, validation.data as any);
      res.json({ workflow: updated });
    } catch (error) {
      structuredLogger.error("Update automation error:", error);
      res.status(500).json({ error: "Failed to update automation workflow" });
    }
  });

  // Delete an automation workflow (admin only)
  app.delete("/api/bots/:botId/automations/:workflowId", requireAdminRole, async (req, res) => {
    try {
      const { botId, workflowId } = req.params;
      
      // Validate tenant access
      if (!await validateBotAccess(req, res, botId)) return;
      
      const existing = await storage.getAutomationWorkflow(workflowId);
      
      if (!existing || existing.botId !== botId) {
        return res.status(404).json({ error: "Automation workflow not found" });
      }
      
      await storage.deleteAutomationWorkflow(workflowId);
      res.json({ success: true });
    } catch (error) {
      structuredLogger.error("Delete automation error:", error);
      res.status(500).json({ error: "Failed to delete automation workflow" });
    }
  });

  // Toggle automation status (quick action)
  app.post("/api/bots/:botId/automations/:workflowId/toggle", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const { botId, workflowId } = req.params;
      
      // Validate tenant access
      if (!await validateBotAccess(req, res, botId)) return;
      
      const existing = await storage.getAutomationWorkflow(workflowId);
      
      if (!existing || existing.botId !== botId) {
        return res.status(404).json({ error: "Automation workflow not found" });
      }
      
      const newStatus = existing.status === 'active' ? 'paused' : 'active';
      const updated = await storage.updateAutomationWorkflow(workflowId, { status: newStatus });
      res.json({ workflow: updated });
    } catch (error) {
      structuredLogger.error("Toggle automation error:", error);
      res.status(500).json({ error: "Failed to toggle automation status" });
    }
  });

  // Get automation run history for a workflow
  app.get("/api/bots/:botId/automations/:workflowId/runs", requireClientAuth, async (req, res) => {
    try {
      const { botId, workflowId } = req.params;
      const limit = parseInt(req.query.limit as string) || 50;
      
      // Validate tenant access
      if (!await validateBotAccess(req, res, botId)) return;
      
      const existing = await storage.getAutomationWorkflow(workflowId);
      if (!existing || existing.botId !== botId) {
        return res.status(404).json({ error: "Automation workflow not found" });
      }
      
      const runs = await storage.getAutomationRunsByWorkflow(workflowId, limit);
      res.json({ runs });
    } catch (error) {
      structuredLogger.error("Get automation runs error:", error);
      res.status(500).json({ error: "Failed to get automation runs" });
    }
  });

  // Get all automation runs for a bot (recent 24h by default)
  app.get("/api/bots/:botId/automation-runs", requireClientAuth, async (req, res) => {
    try {
      const { botId } = req.params;
      const hours = parseInt(req.query.hours as string) || 24;
      
      // Validate tenant access
      if (!await validateBotAccess(req, res, botId)) return;
      
      const runs = await storage.getRecentAutomationRuns(botId, hours);
      res.json({ runs });
    } catch (error) {
      structuredLogger.error("Get bot automation runs error:", error);
      res.status(500).json({ error: "Failed to get automation runs" });
    }
  });

  // Test an automation workflow (dry run)
  app.post("/api/bots/:botId/automations/:workflowId/test", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const { botId, workflowId } = req.params;
      const { testMessage, testContext } = req.body;
      
      // Validate tenant access
      if (!await validateBotAccess(req, res, botId)) return;
      
      const workflow = await storage.getAutomationWorkflow(workflowId);
      if (!workflow || workflow.botId !== botId) {
        return res.status(404).json({ error: "Automation workflow not found" });
      }
      
      // Simulate workflow execution
      const testResult = {
        wouldTrigger: false,
        matchedConditions: [] as string[],
        actionsToExecute: workflow.actions || [],
        testMessage,
        workflow: {
          name: workflow.name,
          triggerType: workflow.triggerType,
        }
      };
      
      // Check trigger conditions based on type
      if (workflow.triggerType === 'keyword' && workflow.triggerConfig) {
        const keywords = (workflow.triggerConfig as any).keywords || [];
        const matchType = (workflow.triggerConfig as any).matchType || 'contains';
        const message = (testMessage || '').toLowerCase();
        
        for (const keyword of keywords) {
          const kw = keyword.toLowerCase();
          let matched = false;
          
          if (matchType === 'exact') {
            matched = message === kw;
          } else if (matchType === 'contains') {
            matched = message.includes(kw);
          } else if (matchType === 'regex') {
            try {
              matched = new RegExp(keyword, 'i').test(message);
            } catch { matched = false; }
          }
          
          if (matched) {
            testResult.wouldTrigger = true;
            testResult.matchedConditions.push(`Keyword: "${keyword}"`);
          }
        }
      } else if (workflow.triggerType === 'message_count' && workflow.triggerConfig) {
        const threshold = (workflow.triggerConfig as any).messageCountThreshold || 1;
        const currentCount = testContext?.messageCount || 0;
        if (currentCount >= threshold) {
          testResult.wouldTrigger = true;
          testResult.matchedConditions.push(`Message count: ${currentCount} >= ${threshold}`);
        }
      }
      
      res.json({ testResult });
    } catch (error) {
      structuredLogger.error("Test automation error:", error);
      res.status(500).json({ error: "Failed to test automation" });
    }
  });

  // =============================================
  // PHASE 5: WIDGET SETTINGS ENDPOINTS
  // =============================================

  // Widget settings validation schema - includes all appearance customization fields
  const hexColorRegex = /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/;
  const widgetSettingsSchema = z.object({
    // Core appearance
    position: z.enum(['bottom-left', 'bottom-right']).optional(),
    theme: z.enum(['light', 'dark', 'auto']).optional(),
    
    // Colors - Primary & Accent
    primaryColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional(),
    secondaryColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    accentColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    
    // Colors - Background
    backgroundColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    headerBackgroundColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    
    // Colors - Text
    textColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    textMutedColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    
    // Colors - Messages
    userMessageColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    userMessageTextColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    botMessageColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    botMessageTextColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    
    // Colors - Input
    inputBackgroundColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    inputTextColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    inputBorderColor: z.string().regex(hexColorRegex, 'Invalid hex color').optional().nullable(),
    
    // Avatar
    avatarUrl: z.string().url().optional().nullable(),
    showAvatar: z.boolean().optional(),
    
    // Layout
    bubbleSize: z.enum(['small', 'medium', 'large']).optional(),
    windowWidth: z.number().min(280).max(600).optional(),
    windowHeight: z.number().min(400).max(800).optional(),
    borderRadius: z.number().min(0).max(32).optional(),
    shadowIntensity: z.enum(['none', 'soft', 'medium', 'strong']).optional(),
    
    // Launcher
    launcherIconStyle: z.enum(['chat-bubble', 'robot', 'message']).optional(),
    showLauncherLabel: z.boolean().optional(),
    launcherLabel: z.string().max(50).optional().nullable(),
    
    // Typography
    fontFamily: z.enum(['system', 'Inter', 'Roboto', 'Nunito']).optional(),
    fontSize: z.enum(['sm', 'md', 'lg']).optional(),
    
    // Branding
    showPoweredBy: z.boolean().optional(),
    headerTitle: z.string().max(50).optional().nullable(),
    headerSubtitle: z.string().max(30).optional().nullable(),
    
    // Messages
    welcomeMessage: z.string().max(500).optional().nullable(),
    placeholderText: z.string().max(100).optional().nullable(),
    offlineMessage: z.string().max(500).optional().nullable(),
    
    // Behavior
    autoOpen: z.boolean().optional(),
    autoOpenDelay: z.number().min(0).max(60).optional(),
    autoOpenOnce: z.boolean().optional(),
    soundEnabled: z.boolean().optional(),
    soundUrl: z.string().url().optional().nullable(),
    mobileFullscreen: z.boolean().optional(),
    mobileBreakpoint: z.number().min(320).max(768).optional(),
    
    // Advanced
    customCss: z.string().max(10000).optional().nullable(),
    advanced: z.object({
      hideOnPages: z.array(z.string()).optional(),
      showOnPages: z.array(z.string()).optional(),
      triggerSelector: z.string().optional(),
      zIndex: z.number().optional(),
    }).optional(),
  });

  // Get widget settings for a bot
  app.get("/api/bots/:botId/widget-settings", requireClientAuth, async (req, res) => {
    try {
      const { botId } = req.params;
      
      // Validate tenant access
      if (!await validateBotAccess(req, res, botId)) return;
      
      const settings = await storage.getWidgetSettingsWithDefaults(botId);
      res.json({ settings });
    } catch (error) {
      structuredLogger.error("Get widget settings error:", error);
      res.status(500).json({ error: "Failed to get widget settings" });
    }
  });

  // Update widget settings for a bot (upsert)
  app.put("/api/bots/:botId/widget-settings", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const { botId } = req.params;
      
      // Validate tenant access
      if (!await validateBotAccess(req, res, botId)) return;
      
      const validation = widgetSettingsSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid widget settings", details: validation.error.format() });
      }
      
      const settings = await storage.upsertWidgetSettings(botId, validation.data as any);
      res.json({ settings });
    } catch (error) {
      structuredLogger.error("Update widget settings error:", error);
      res.status(500).json({ error: "Failed to update widget settings" });
    }
  });

  // Delete widget settings for a bot (reset to defaults)
  app.delete("/api/bots/:botId/widget-settings", requireClientAuth, requireDestructiveAccess, async (req, res) => {
    try {
      const { botId } = req.params;
      
      // Validate tenant access
      if (!await validateBotAccess(req, res, botId)) return;
      
      await storage.deleteWidgetSettings(botId);
      res.json({ success: true, message: "Widget settings reset to defaults" });
    } catch (error) {
      structuredLogger.error("Delete widget settings error:", error);
      res.status(500).json({ error: "Failed to reset widget settings" });
    }
  });

  // Update the widget config endpoint to return full settings
  app.get('/api/widget/full-config/:clientId/:botId', widgetCors, async (req, res) => {
    try {
      const { clientId, botId } = req.params;
      
      const botConfig = getBotConfig(clientId, botId);
      if (!botConfig) {
        return res.status(404).json({ error: 'Bot not found' });
      }
      
      const clientStatus = getClientStatus(clientId);
      if (clientStatus === 'paused') {
        return res.json({
          status: 'paused',
          message: 'This service is currently paused.'
        });
      }
      
      // Get widget settings from database
      const widgetConfig = await storage.getWidgetSettingsWithDefaults(botId);
      
      // Generate signed widget token (expires in 24 hours)
      const widgetToken = generateWidgetToken(clientId, botId, 86400);
      
      // Return full widget configuration
      res.json({
        status: 'active',
        token: widgetToken,
        bot: {
          name: botConfig.name,
          businessName: botConfig.businessProfile?.businessName || botConfig.name,
        },
        widget: {
          position: widgetConfig.position,
          theme: widgetConfig.theme,
          primaryColor: widgetConfig.primaryColor,
          accentColor: widgetConfig.accentColor,
          avatarUrl: widgetConfig.avatarUrl,
          bubbleSize: widgetConfig.bubbleSize,
          windowWidth: widgetConfig.windowWidth,
          windowHeight: widgetConfig.windowHeight,
          borderRadius: widgetConfig.borderRadius,
          showPoweredBy: widgetConfig.showPoweredBy,
          headerTitle: widgetConfig.headerTitle || botConfig.businessProfile?.businessName || 'Chat Assistant',
          headerSubtitle: widgetConfig.headerSubtitle,
          welcomeMessage: widgetConfig.welcomeMessage || `Hi! I'm the ${botConfig.businessProfile?.businessName || 'AI'} assistant. How can I help you today?`,
          placeholderText: widgetConfig.placeholderText,
          offlineMessage: widgetConfig.offlineMessage,
          autoOpen: widgetConfig.autoOpen,
          autoOpenDelay: widgetConfig.autoOpenDelay,
          autoOpenOnce: widgetConfig.autoOpenOnce,
          soundEnabled: widgetConfig.soundEnabled,
          soundUrl: widgetConfig.soundUrl,
          mobileFullscreen: widgetConfig.mobileFullscreen,
          mobileBreakpoint: widgetConfig.mobileBreakpoint,
          customCss: widgetConfig.customCss,
          advanced: widgetConfig.advanced,
        }
      });
    } catch (error) {
      structuredLogger.error('Widget full config error:', error);
      res.status(500).json({ error: 'Failed to load widget configuration' });
    }
  });

  // =============================================
  // DATA LIFECYCLE ENDPOINTS (Phase 8.8)
  // =============================================

  // Client data export (GDPR-style)
  app.get("/api/client/data/export", requireClientAuth, requireConfigAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const data = await exportClientData(clientId);
      
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="data_export_${clientId}_${Date.now()}.json"`);
      res.json(data);
    } catch (error) {
      structuredLogger.error("Data export error:", error);
      res.status(500).json({ error: "Failed to export data" });
    }
  });

  // Client data deletion (right to be forgotten)
  app.delete("/api/client/data", requireClientAuth, requireDestructiveAccess, async (req, res) => {
    try {
      const clientId = req.effectiveClientId;
      if (!clientId) {
        return res.status(401).json({ error: "Client ID required" });
      }
      const { deleteLeads, deleteAppointments, deleteChatSessions, deleteAnalytics } = req.body;
      
      const result = await deleteClientData(clientId, {
        deleteLeads: deleteLeads !== false,
        deleteAppointments: deleteAppointments !== false,
        deleteChatSessions: deleteChatSessions !== false,
        deleteAnalytics: deleteAnalytics !== false,
      });
      
      await logAuditEvent({
        action: 'data_delete',
        userId: req.session.userId!,
        username: req.session.username || 'unknown',
        resourceType: 'client_data',
        resourceId: clientId,
        details: { deletedCounts: result.deletedCounts },
        ipAddress: req.ip || 'unknown',
        userAgent: req.headers['user-agent'] || 'unknown',
      });
      
      res.json(result);
    } catch (error) {
      structuredLogger.error("Data deletion error:", error);
      res.status(500).json({ error: "Failed to delete data" });
    }
  });

  // Super admin: view retention config
  app.get("/api/super-admin/retention/config", requireSuperAdmin, async (_req, res) => {
    try {
      const config = getRetentionConfig();
      res.json(config);
    } catch (error) {
      structuredLogger.error("Get retention config error:", error);
      res.status(500).json({ error: "Failed to get retention config" });
    }
  });

  // Super admin: trigger data purge
  app.post("/api/super-admin/retention/purge", requireSuperAdmin, async (req, res) => {
    try {
      const result = await purgeOldData();
      
      await logAuditEvent({
        action: 'data_purge',
        userId: req.session.userId!,
        username: req.session.username || 'unknown',
        resourceType: 'system',
        resourceId: 'retention_purge',
        details: { purgedCounts: result.purgedCounts },
        ipAddress: req.ip || 'unknown',
        userAgent: req.headers['user-agent'] || 'unknown',
      });
      
      res.json(result);
    } catch (error) {
      structuredLogger.error("Data purge error:", error);
      res.status(500).json({ error: "Failed to purge old data" });
    }
  });

  // =============================================
  // AGENCY ONBOARDING CONSOLE ENDPOINTS
  // =============================================

  const agencyOnboardingIntakeSchema = z.object({
    businessName: z.string().min(1, "Business name is required"),
    industryTemplate: z.string().min(1, "Industry template is required"),
    websiteUrl: z.string().url().optional().or(z.literal("")),
    primaryPhone: z.string().optional(),
    primaryEmail: z.string().email().optional().or(z.literal("")),
    serviceArea: z.string().optional(),
    primaryCTA: z.enum(['tour', 'consult', 'book', 'reserve', 'estimate', 'call']).optional(),
    bookingPreference: z.enum(['internal', 'external']).optional(),
    externalBookingUrl: z.string().url().optional().or(z.literal("")),
    internalNotes: z.string().optional(),
    doNotSay: z.array(z.string()).optional(),
    behaviorPreset: z.enum(['support_lead_focused', 'informational', 'sales_focused', 'minimal_proactive']).optional(),
    styleConfig: z.object({
      primaryColor: z.string().optional(),
      accentColor: z.string().optional(),
      theme: z.enum(['dark', 'light']).optional(),
      logoUrl: z.string().optional(),
    }).optional(),
    // KB Draft from frontend - will auto-inject template defaults if below minimum
    kbDraft: z.object({
      services: z.array(z.object({
        name: z.string(),
        description: z.string().optional(),
      })).optional(),
      faqs: z.array(z.object({
        question: z.string(),
        answer: z.string(),
      })).optional(),
      policies: z.string().optional(),
      hours: z.record(z.string()).optional(),
    }).optional(),
  });

  // Minimum Viable KB thresholds
  const KB_MINIMUM = {
    SERVICES_MIN: 6,
    FAQS_MIN: 8,
    ABOUT_MIN_CHARS: 80,
  };

  // Helper: Check if KB content meets minimum viable threshold
  function checkKBMinimum(kbDraft: { 
    services?: Array<{ name: string }>; 
    faqs?: Array<{ question: string; answer: string }>; 
    policies?: string;
  }): { meetsMinimum: boolean; missing: string[] } {
    const missing: string[] = [];
    const servicesOk = (kbDraft.services?.length || 0) >= KB_MINIMUM.SERVICES_MIN;
    const faqsOk = (kbDraft.faqs?.length || 0) >= KB_MINIMUM.FAQS_MIN;
    const aboutOk = (kbDraft.policies?.length || 0) >= KB_MINIMUM.ABOUT_MIN_CHARS;
    
    // KB is viable if ANY of these conditions is met
    const hasKBContent = servicesOk || faqsOk || aboutOk;
    
    if (!servicesOk) missing.push('services');
    if (!faqsOk) missing.push('faqs');
    if (!aboutOk) missing.push('about');
    
    return { meetsMinimum: hasKBContent, missing };
  }

  // Helper: Inject template defaults into KB with "Template default" labels
  function injectTemplateDefaults(
    kbDraft: {
      services?: Array<{ name: string; description?: string }>;
      faqs?: Array<{ question: string; answer: string }>;
      policies?: string;
    },
    template: IndustryTemplate
  ): {
    services: Array<{ name: string; description: string; isTemplateDefault?: boolean }>;
    faqs: Array<{ question: string; answer: string; isTemplateDefault?: boolean }>;
    policies: string;
    injectedDefaults: string[];
  } {
    const injectedDefaults: string[] = [];
    
    // Start with provided KB data
    let services: Array<{ name: string; description: string; isTemplateDefault?: boolean }> = 
      (kbDraft.services || []).map(s => ({ name: s.name, description: s.description || '' }));
    let faqs: Array<{ question: string; answer: string; isTemplateDefault?: boolean }> = 
      (kbDraft.faqs || []).map(f => ({ question: f.question, answer: f.answer }));
    let policies = kbDraft.policies || '';
    
    // Inject template services if below minimum
    if (services.length < KB_MINIMUM.SERVICES_MIN) {
      const existingNames = new Set(services.map(s => s.name.toLowerCase()));
      const templateServices = template.defaultConfig.businessProfile.services
        .filter(s => !existingNames.has(s.toLowerCase()))
        .map(s => ({ name: s, description: '(Template default)', isTemplateDefault: true }));
      services = [...services, ...templateServices];
      if (templateServices.length > 0) injectedDefaults.push('services');
    }
    
    // Inject template FAQs if below minimum
    if (faqs.length < KB_MINIMUM.FAQS_MIN) {
      const existingQuestions = new Set(faqs.map(f => f.question.toLowerCase()));
      const templateFaqs = template.defaultConfig.faqs
        .filter(f => !existingQuestions.has(f.question.toLowerCase()))
        .map(f => ({ ...f, isTemplateDefault: true }));
      faqs = [...faqs, ...templateFaqs];
      if (templateFaqs.length > 0) injectedDefaults.push('faqs');
    }
    
    // Inject template about/policies if below minimum
    if (policies.length < KB_MINIMUM.ABOUT_MIN_CHARS) {
      const templateAbout = `Welcome to our ${template.defaultConfig.businessProfile.type}. ${template.defaultConfig.systemPromptIntro} (Template default)`;
      policies = policies ? `${policies}\n\n${templateAbout}` : templateAbout;
      injectedDefaults.push('about');
    }
    
    return { services, faqs, policies, injectedDefaults };
  }

  // Generate Draft Setup - Creates workspace + bot in DRAFT mode
  app.post("/api/agency-onboarding/generate-draft-setup", requireSuperAdmin, async (req, res) => {
    try {
      const validation = agencyOnboardingIntakeSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validation.error.errors 
        });
      }

      const intake = validation.data;
      
      // Use database template - NO FALLBACK to hardcoded templates in production
      const dbTemplate = await getTemplateById(intake.industryTemplate);
      
      if (!dbTemplate) {
        // In production, fail loudly - no fallback to hardcoded templates
        if (process.env.NODE_ENV === 'production') {
          structuredLogger.error('[Agency Onboarding] Template not found in DB and fallback disabled in production', { templateId: intake.industryTemplate });
          return res.status(400).json({ error: `Template not found in database: ${intake.industryTemplate}. DB templates are required in production.` });
        }
        // In development, allow fallback but log warning
        const fallbackTemplate = INDUSTRY_TEMPLATES[intake.industryTemplate];
        if (!fallbackTemplate) {
          return res.status(400).json({ error: `Unknown industry template: ${intake.industryTemplate}` });
        }
        structuredLogger.warn('[Agency Onboarding] Using fallback INDUSTRY_TEMPLATES - migrate to DB templates', { templateId: intake.industryTemplate });
      }
      
      // Build a unified template shape for compatibility
      const template = dbTemplate ? {
        id: dbTemplate.templateId,
        name: dbTemplate.name,
        icon: dbTemplate.icon,
        description: dbTemplate.description,
        botType: dbTemplate.botType,
        defaultConfig: dbTemplate.defaultConfig,
        bookingProfile: dbTemplate.defaultConfig?.bookingProfile || { mode: 'internal' as const, primaryCTA: 'call' as const, failsafeEnabled: true },
        ctaButtons: dbTemplate.defaultConfig?.bookingProfile?.ctas || [],
        disclaimer: dbTemplate.defaultConfig?.bookingProfile?.disclaimers?.text || '',
      } : INDUSTRY_TEMPLATES[intake.industryTemplate];

      // Generate slugified client/workspace ID
      const clientId = intake.businessName
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_|_$/g, '')
        .substring(0, 50) + '_' + Date.now().toString(36);
      
      const botId = `${clientId}_bot`;

      // Step 1: Create workspace in DRAFT status
      const workspace = await createWorkspace({
        name: intake.businessName,
        slug: clientId,
        ownerId: req.session.userId?.toString() || 'admin',
        plan: 'starter',
        status: 'draft', // DRAFT mode - not active yet
        settings: {
          onboardingData: intake,
          createdViaOnboarding: true,
        },
      });

      // Step 2: Build bot configuration from template + intake
      let scrapedData: any = null;
      let websiteSuggestions: any[] = [];
      
      // If website URL provided, run scraper
      if (intake.websiteUrl) {
        try {
          const scrapeResult = await scrapeWebsite(intake.websiteUrl, clientId, botId);
          if (scrapeResult.success) {
            const scrape = await storage.getScrapedWebsiteById(scrapeResult.scrapeId);
            if (scrape?.extractedData) {
              scrapedData = scrape.extractedData;
              
              // Build website suggestions with confidence scores
              const extracted = scrape.extractedData as any;
              if (extracted.services?.length) {
                websiteSuggestions.push({
                  type: 'services',
                  label: 'Services',
                  items: extracted.services,
                  sourceUrl: intake.websiteUrl,
                  confidence: 0.85,
                  selected: true,
                });
              }
              if (extracted.faqs?.length) {
                websiteSuggestions.push({
                  type: 'faqs',
                  label: 'FAQs',
                  items: extracted.faqs,
                  sourceUrl: intake.websiteUrl,
                  confidence: 0.80,
                  selected: true,
                });
              }
              if (extracted.contactInfo) {
                websiteSuggestions.push({
                  type: 'contact',
                  label: 'Contact Info',
                  items: [extracted.contactInfo],
                  sourceUrl: intake.websiteUrl,
                  confidence: 0.90,
                  selected: true,
                });
              }
              if (extracted.hours || extracted.contactInfo?.hours) {
                websiteSuggestions.push({
                  type: 'hours',
                  label: 'Business Hours',
                  items: [extracted.hours || extracted.contactInfo?.hours],
                  sourceUrl: intake.websiteUrl,
                  confidence: 0.75,
                  selected: true,
                });
              }
            }
          }
        } catch (scrapeError) {
          structuredLogger.error('[Agency Onboarding] Scrape failed:', scrapeError);
          // Continue without scraped data
        }
      }

      // Step 3: Build KB from intake.kbDraft + scraped data, with template auto-injection
      // Priority: intake.kbDraft > scrapedData > template defaults (auto-injected if below minimum)
      const rawKbDraft = {
        services: [
          ...(intake.kbDraft?.services || []),
          ...(scrapedData?.services?.map((s: any) => ({ name: s.name, description: s.description || '' })) || []),
        ],
        faqs: [
          ...(intake.kbDraft?.faqs || []),
          ...(scrapedData?.faqs || []),
        ],
        policies: intake.kbDraft?.policies || '',
        hours: intake.kbDraft?.hours || scrapedData?.contactInfo?.hours || {},
      };

      // Check if KB meets minimum and inject template defaults if needed
      const kbCheck = checkKBMinimum(rawKbDraft);
      let injectedDefaults: string[] = [];
      let finalKb: {
        services: Array<{ name: string; description: string; isTemplateDefault?: boolean }>;
        faqs: Array<{ question: string; answer: string; isTemplateDefault?: boolean }>;
        policies: string;
      };

      if (!kbCheck.meetsMinimum) {
        // Auto-inject template defaults
        const injected = injectTemplateDefaults(rawKbDraft, template);
        finalKb = injected;
        injectedDefaults = injected.injectedDefaults;
        structuredLogger.info(`[Agency Onboarding] KB below minimum, auto-injected template defaults: ${injectedDefaults.join(', ')}`);
      } else {
        // Use raw KB as-is
        finalKb = {
          services: rawKbDraft.services.map(s => ({ name: s.name, description: s.description || '' })),
          faqs: rawKbDraft.faqs.map(f => ({ question: f.question, answer: f.answer })),
          policies: rawKbDraft.policies,
        };
      }

      // Deduplicate services and FAQs
      const mergedServices = finalKb.services
        .filter((s, i, arr) => arr.findIndex(x => x.name.toLowerCase() === s.name.toLowerCase()) === i)
        .map(s => s.name);

      const mergedFaqs = finalKb.faqs
        .filter((faq, i, arr) => 
          arr.findIndex(f => f.question.toLowerCase() === faq.question.toLowerCase()) === i
        );

      // Step 4: Determine booking behavior with FAILSAFE
      let bookingMode = intake.bookingPreference || template.bookingProfile.mode;
      let externalBookingUrl = intake.externalBookingUrl || '';
      let failsafeActive = false;

      // FAILSAFE: If external mode but no valid HTTPS URL, fallback to internal
      // Use comprehensive validateBookingUrl to block dangerous URLs (javascript:, http:, payment URLs)
      if (bookingMode === 'external') {
        const urlValidation = validateBookingUrl(externalBookingUrl);
        if (!urlValidation.valid) {
          bookingMode = 'internal';
          failsafeActive = true;
          structuredLogger.info(`[Agency Onboarding] FAILSAFE ACTIVATED: External booking URL invalid (${urlValidation.error}), falling back to internal request_callback`);
        } else {
          // Use the normalized URL from validator
          externalBookingUrl = urlValidation.url!;
        }
      }

      // Step 5: Create bot config
      const botConfig: BotConfig = {
        botId,
        clientId,
        name: `${intake.businessName} Assistant`,
        description: template.description,
        systemPrompt: template.defaultConfig.systemPromptIntro,
        businessProfile: {
          businessName: intake.businessName,
          type: template.defaultConfig.businessProfile.type,
          location: intake.serviceArea || '',
          phone: intake.primaryPhone || '',
          email: intake.primaryEmail || '',
          website: intake.websiteUrl || '',
          hours: scrapedData?.contactInfo?.hours || {},
          services: mergedServices,
        },
        faqs: mergedFaqs,
        rules: {
          allowedTopics: [],
          forbiddenTopics: intake.doNotSay || [],
          crisisHandling: {
            onCrisisKeywords: ['suicide', 'self-harm', 'emergency', '911'],
            responseTemplate: 'If you are in crisis, please call 911 or a crisis hotline immediately.',
          },
        },
        personality: {
          formality: template.defaultConfig.personality.formality,
          enthusiasm: 50,
          warmth: 50,
          humor: 20,
          responseLength: 'medium',
        },
        quickActions: template.ctaButtons,
        automations: {
          leadCapture: {
            enabled: true,
            collectFields: ['name', 'phone', 'email'],
            confirmationMessage: 'Thank you! Someone will be in touch soon.',
          },
          bookingCapture: {
            enabled: true,
            mode: bookingMode,
            externalUrl: bookingMode === 'external' ? externalBookingUrl : undefined,
            failsafeEnabled: template.bookingProfile.failsafeEnabled,
            failsafeActive,
          },
        },
        metadata: {
          isDemo: false,
          industryTemplate: intake.industryTemplate,
          createdViaOnboarding: true,
          disclaimer: template.disclaimer,
          onboardingStatus: 'draft',
        },
      };

      // Save bot config
      const success = await saveBotConfigAsync(botId, botConfig);
      if (!success) {
        throw new Error('Failed to save bot configuration');
      }

      // Register client
      registerClient(clientId, intake.businessName, template.botType, botId, 'paused');

      // Create clientSettings with behaviorPreset
      await db.insert(clientSettings).values({
        clientId,
        businessName: intake.businessName,
        tagline: template.description || "Welcome to our business",
        primaryEmail: intake.primaryEmail || '',
        primaryPhone: intake.primaryPhone || '',
        websiteUrl: intake.websiteUrl || '',
        status: "paused", // Draft mode
        behaviorPreset: intake.behaviorPreset || 'support_lead_focused',
        bookingMode: bookingMode,
        externalBookingUrl: bookingMode === 'external' ? externalBookingUrl : null,
        knowledgeBase: {
          about: `Welcome to ${intake.businessName}.`,
          requirements: "",
          pricing: "",
          application: "",
        },
        operatingHours: {
          enabled: false,
          timezone: "America/New_York",
          schedule: {
            monday: { open: "09:00", close: "17:00", enabled: true },
            tuesday: { open: "09:00", close: "17:00", enabled: true },
            wednesday: { open: "09:00", close: "17:00", enabled: true },
            thursday: { open: "09:00", close: "17:00", enabled: true },
            friday: { open: "09:00", close: "17:00", enabled: true },
            saturday: { open: "09:00", close: "17:00", enabled: false },
            sunday: { open: "09:00", close: "17:00", enabled: false },
          },
          afterHoursMessage: "We're currently closed. Please leave a message and we'll get back to you.",
        },
      });

      // Log audit event
      await logAuditEvent({
        action: 'onboarding_draft_created',
        userId: req.session.userId!,
        username: req.session.username || 'admin',
        resourceType: 'workspace',
        resourceId: clientId,
        details: {
          businessName: intake.businessName,
          industryTemplate: intake.industryTemplate,
          failsafeActive,
          websiteScraped: !!scrapedData,
        },
        ipAddress: req.ip || 'unknown',
        userAgent: req.headers['user-agent'] || 'unknown',
      });

      res.json({
        success: true,
        clientId,
        botId,
        workspaceId: workspace.id,
        websiteSuggestions,
        kbDraft: {
          services: mergedServices,
          faqs: mergedFaqs,
          policies: finalKb.policies || template.disclaimer,
          hours: rawKbDraft.hours,
        },
        kbAutoInjection: {
          wasInjected: injectedDefaults.length > 0,
          injectedCategories: injectedDefaults,
          meetsMinimum: kbCheck.meetsMinimum,
          missing: kbCheck.missing,
        },
        bookingConfig: {
          mode: bookingMode,
          primaryCTA: intake.primaryCTA || template.bookingProfile.primaryCTA,
          externalUrl: externalBookingUrl,
          failsafeActive,
          failsafeEnabled: template.bookingProfile.failsafeEnabled,
        },
        ctaButtons: template.ctaButtons,
        widgetTheme: template.defaultConfig.theme,
      });
    } catch (error) {
      structuredLogger.error('[Agency Onboarding] Generate draft error:', error);
      res.status(500).json({ error: 'Failed to generate draft setup' });
    }
  });

  // Client Health Glance - Quick health metrics for onboarding console
  app.get("/api/agency-onboarding/client-health/:clientId", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId } = req.params;
      
      if (!clientId) {
        return res.status(400).json({ error: 'clientId is required' });
      }

      // Get last chat activity
      let lastChatActivity: { sessionId: string; startedAt: string; messageCount: number } | null = null;
      try {
        const recentSession = await db.select()
          .from(chatSessions)
          .where(eq(chatSessions.clientId, clientId))
          .orderBy(desc(chatSessions.startedAt))
          .limit(1);
        
        if (recentSession.length > 0) {
          lastChatActivity = {
            sessionId: recentSession[0].sessionId,
            startedAt: recentSession[0].startedAt.toISOString(),
            messageCount: recentSession[0].userMessageCount + recentSession[0].botMessageCount,
          };
        }
      } catch (err) {
        structuredLogger.error('[Client Health] Failed to get chat activity:', err);
      }

      // Get errors in last 15 minutes for this client
      let errorsLast15m: { count: number; recent: Array<{ message: string; source: string; createdAt: string }> } = {
        count: 0,
        recent: [],
      };
      try {
        const recentErrors = await db.select()
          .from(systemLogs)
          .where(and(
            or(eq(systemLogs.level, 'error'), eq(systemLogs.level, 'critical')),
            gte(systemLogs.createdAt, new Date(Date.now() - 15 * 60 * 1000)),
            eq(systemLogs.clientId, clientId)
          ))
          .orderBy(desc(systemLogs.createdAt))
          .limit(10);
        
        errorsLast15m.count = recentErrors.length;
        errorsLast15m.recent = recentErrors.slice(0, 5).map(log => ({
          message: log.message?.substring(0, 100) || 'Unknown error',
          source: log.source || 'system',
          createdAt: log.createdAt.toISOString(),
        }));
      } catch (err) {
        structuredLogger.error('[Client Health] Failed to get errors:', err);
      }

      // Get notification status from client settings
      let notificationStatus: { emailEnabled: boolean; smsEnabled: boolean; lastAttempt?: string } = {
        emailEnabled: false,
        smsEnabled: false,
      };
      try {
        const settings = await db.select()
          .from(clientSettings)
          .where(eq(clientSettings.clientId, clientId))
          .limit(1);
        
        if (settings.length > 0) {
          notificationStatus.emailEnabled = settings[0].enableEmailNotifications || false;
          notificationStatus.smsEnabled = settings[0].enableSmsNotifications || false;
        }
      } catch (err) {
        structuredLogger.error('[Client Health] Failed to get notification status:', err);
      }

      // Get widget fetch status - check if bot exists and is configured
      let widgetStatus: { configured: boolean; botId?: string; lastFetchable: boolean } = {
        configured: false,
        lastFetchable: false,
      };
      try {
        const clientBots = await getBotsByClientId(clientId);
        if (clientBots && clientBots.length > 0) {
          widgetStatus.configured = true;
          widgetStatus.botId = clientBots[0].botId;
          widgetStatus.lastFetchable = true;
        }
      } catch (err) {
        structuredLogger.error('[Client Health] Failed to get widget status:', err);
      }

      res.json({
        clientId,
        timestamp: new Date().toISOString(),
        lastChatActivity,
        errorsLast15m,
        notificationStatus,
        widgetStatus,
      });
    } catch (error) {
      structuredLogger.error('[Agency Onboarding] Client health error:', error);
      res.status(500).json({ error: 'Failed to get client health' });
    }
  });

  // Get industry templates list
  app.get("/api/agency-onboarding/templates", requireSuperAdmin, async (_req, res) => {
    try {
      // Use database templates instead of hardcoded INDUSTRY_TEMPLATES
      const dbTemplates = await getAllTemplates();
      
      const templates = dbTemplates.filter(t => t.isActive).map(t => ({
        id: t.templateId,
        name: t.name,
        icon: t.icon,
        description: t.description,
        botType: t.botType,
        bookingProfile: t.defaultConfig?.bookingProfile,
        primaryCTA: t.defaultConfig?.bookingProfile?.ctas?.find((cta: any) => cta.kind === 'primary'),
      }));
      res.json(templates);
    } catch (error) {
      structuredLogger.error('[Agency Onboarding] Get templates error:', error);
      res.status(500).json({ error: 'Failed to get templates' });
    }
  });

  // Run QA Gate - Validates bot is ready for launch
  app.post("/api/agency-onboarding/run-qa-gate", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId, botId } = req.body;
      
      if (!clientId || !botId) {
        return res.status(400).json({ error: 'clientId and botId are required' });
      }

      const checks: Array<{ name: string; status: 'pass' | 'fail' | 'warn'; message: string }> = [];
      let allPassed = true;

      // Check 1: Widget config fetch
      try {
        const botConfig = await getBotConfigByBotIdAsync(botId);
        if (botConfig) {
          checks.push({ name: 'Widget Config', status: 'pass', message: 'Bot configuration loaded successfully' });
        } else {
          checks.push({ name: 'Widget Config', status: 'fail', message: 'Bot configuration not found' });
          allPassed = false;
        }
      } catch {
        checks.push({ name: 'Widget Config', status: 'fail', message: 'Failed to load bot configuration' });
        allPassed = false;
      }

      // Check 2: Test chat response (simulate)
      try {
        const botConfig = await getBotConfigByBotIdAsync(botId);
        if (botConfig?.systemPrompt && botConfig.systemPrompt.length > 10) {
          checks.push({ name: 'Chat Response', status: 'pass', message: 'System prompt configured correctly' });
        } else {
          checks.push({ name: 'Chat Response', status: 'warn', message: 'System prompt may need enhancement' });
        }
      } catch {
        checks.push({ name: 'Chat Response', status: 'fail', message: 'Chat configuration error' });
        allPassed = false;
      }

      // Check 3: Lead capture configuration
      try {
        const botConfig = await getBotConfigByBotIdAsync(botId);
        const leadCapture = (botConfig as any)?.automations?.leadCapture;
        if (leadCapture?.enabled) {
          checks.push({ name: 'Lead Capture', status: 'pass', message: 'Lead capture automation enabled' });
        } else {
          checks.push({ name: 'Lead Capture', status: 'warn', message: 'Lead capture not enabled' });
        }
      } catch {
        checks.push({ name: 'Lead Capture', status: 'fail', message: 'Lead capture check failed' });
      }

      // Check 4: Booking behavior
      try {
        const botConfig = await getBotConfigByBotIdAsync(botId);
        const bookingCapture = (botConfig as any)?.automations?.bookingCapture;
        if (bookingCapture?.enabled) {
          if (bookingCapture.mode === 'external' && !bookingCapture.externalUrl) {
            checks.push({ name: 'Booking Flow', status: 'warn', message: 'External booking configured but URL missing - failsafe active' });
          } else {
            checks.push({ name: 'Booking Flow', status: 'pass', message: `Booking mode: ${bookingCapture.mode}` });
          }
        } else {
          checks.push({ name: 'Booking Flow', status: 'warn', message: 'Booking capture not enabled' });
        }
      } catch {
        checks.push({ name: 'Booking Flow', status: 'fail', message: 'Booking configuration error' });
      }

      // Check 5: Business info completeness
      try {
        const botConfig = await getBotConfigByBotIdAsync(botId);
        const bp = botConfig?.businessProfile;
        const hasName = !!bp?.businessName;
        const hasContact = !!(bp?.phone || bp?.email);
        
        if (hasName && hasContact) {
          checks.push({ name: 'Business Info', status: 'pass', message: 'Business profile complete' });
        } else if (hasName) {
          checks.push({ name: 'Business Info', status: 'warn', message: 'Missing contact information' });
        } else {
          checks.push({ name: 'Business Info', status: 'fail', message: 'Business profile incomplete' });
          allPassed = false;
        }
      } catch {
        checks.push({ name: 'Business Info', status: 'fail', message: 'Business profile check failed' });
        allPassed = false;
      }

      // Generate CLIENT_LAUNCH_REPORT
      const reportDate = new Date().toISOString();
      const botConfig = await getBotConfigByBotIdAsync(botId);
      const launchReport = `# CLIENT LAUNCH REPORT
Generated: ${reportDate}

## Client Details
- **Client ID:** ${clientId}
- **Bot ID:** ${botId}
- **Business Name:** ${botConfig?.businessProfile?.businessName || 'Unknown'}
- **Industry:** ${(botConfig?.metadata as any)?.industryTemplate || 'Unknown'}

## QA Gate Results
${checks.map(c => `- **${c.name}:** ${c.status.toUpperCase()} - ${c.message}`).join('\n')}

## Overall Status
${allPassed ? 'READY FOR LAUNCH' : 'ISSUES FOUND - Review required'}

## Configuration Summary
- **Booking Mode:** ${(botConfig as any)?.automations?.bookingCapture?.mode || 'Not configured'}
- **Lead Capture:** ${(botConfig as any)?.automations?.leadCapture?.enabled ? 'Enabled' : 'Disabled'}
- **FAQs:** ${botConfig?.faqs?.length || 0} configured
- **Services:** ${botConfig?.businessProfile?.services?.length || 0} listed

---
*This report was generated by the Agency Onboarding Console*
`;

      res.json({
        success: true,
        allPassed,
        checks,
        launchReport,
        readyForGoLive: allPassed,
      });
    } catch (error) {
      structuredLogger.error('[Agency Onboarding] QA Gate error:', error);
      res.status(500).json({ error: 'Failed to run QA gate' });
    }
  });

  // Go Live - Activate workspace and generate embed code
  app.post("/api/agency-onboarding/go-live", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId, botId } = req.body;
      
      if (!clientId || !botId) {
        return res.status(400).json({ error: 'clientId and botId are required' });
      }

      // Update workspace status to active
      const workspace = await getWorkspaceBySlug(clientId);
      if (workspace) {
        await updateWorkspace(workspace.id, { status: 'active' });
      }

      // Update client status to active
      updateClientStatus(clientId, 'active');

      // Update bot metadata to mark as live
      const botConfig = await getBotConfigByBotIdAsync(botId);
      if (botConfig) {
        const updatedConfig: BotConfig = {
          ...botConfig,
          metadata: {
            ...(botConfig.metadata || {}),
            onboardingStatus: 'live' as const,
            goLiveDate: new Date().toISOString(),
          },
        };
        await saveBotConfigAsync(botId, updatedConfig);
      }

      // Generate embed code (NO secrets included)
      const embedCode = getWidgetEmbedCode({
        workspaceSlug: clientId,
        botId,
        primaryColor: botConfig?.businessProfile?.website ? '#00E5CC' : '#00E5CC',
        businessName: botConfig?.businessProfile?.businessName || 'AI Assistant',
        businessSubtitle: 'Powered by TCAI',
      });

      const minimalEmbed = `<script src="/widget/embed.js" data-client-id="${clientId}" data-bot-id="${botId}"></script>`;

      // Log audit event
      await logAuditEvent({
        action: 'onboarding_go_live',
        userId: req.session.userId!,
        username: req.session.username || 'admin',
        resourceType: 'workspace',
        resourceId: clientId,
        details: {
          botId,
          businessName: botConfig?.businessProfile?.businessName,
        },
        ipAddress: req.ip || 'unknown',
        userAgent: req.headers['user-agent'] || 'unknown',
      });

      res.json({
        success: true,
        status: 'live',
        clientId,
        botId,
        embedCode,
        minimalEmbed,
        instructions: getEmbedInstructions(),
      });
    } catch (error) {
      structuredLogger.error('[Agency Onboarding] Go Live error:', error);
      res.status(500).json({ error: 'Failed to go live' });
    }
  });

  // Update draft setup - Allows editing KB, CTAs, etc before go-live
  app.put("/api/agency-onboarding/draft/:clientId/:botId", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId, botId } = req.params;
      const updates = req.body;

      const botConfig = await getBotConfigByBotIdAsync(botId);
      if (!botConfig) {
        return res.status(404).json({ error: 'Bot not found' });
      }

      // Merge updates with existing config
      const updatedConfig: BotConfig = {
        ...botConfig,
        faqs: updates.faqs || botConfig.faqs,
        businessProfile: {
          ...botConfig.businessProfile,
          services: updates.services || botConfig.businessProfile?.services,
          hours: updates.hours || botConfig.businessProfile?.hours,
        },
        quickActions: updates.ctaButtons || botConfig.quickActions,
        automations: {
          ...((botConfig as any).automations || {}),
          bookingCapture: updates.bookingConfig 
            ? { ...((botConfig as any).automations?.bookingCapture || {}), ...updates.bookingConfig }
            : (botConfig as any).automations?.bookingCapture,
        },
      };

      const success = await saveBotConfigAsync(botId, updatedConfig);
      
      if (success) {
        res.json({ success: true, config: updatedConfig });
      } else {
        res.status(500).json({ error: 'Failed to save updates' });
      }
    } catch (error) {
      structuredLogger.error('[Agency Onboarding] Update draft error:', error);
      res.status(500).json({ error: 'Failed to update draft' });
    }
  });

  // Get draft status
  app.get("/api/agency-onboarding/draft/:clientId/:botId", requireSuperAdmin, async (req, res) => {
    try {
      const { clientId, botId } = req.params;

      const botConfig = await getBotConfigByBotIdAsync(botId);
      if (!botConfig) {
        return res.status(404).json({ error: 'Bot not found' });
      }

      const workspace = await getWorkspaceBySlug(clientId);
      
      // Get template from DB, fallback to INDUSTRY_TEMPLATES only in development
      const industryTemplateId = (botConfig.metadata as any)?.industryTemplate;
      let templateData: any = null;
      if (industryTemplateId) {
        const dbTemplate = await getTemplateById(industryTemplateId);
        if (dbTemplate) {
          templateData = {
            disclaimer: dbTemplate.defaultConfig?.bookingProfile?.disclaimers?.text || '',
            ctaButtons: dbTemplate.defaultConfig?.bookingProfile?.ctas || [],
            defaultConfig: dbTemplate.defaultConfig,
          };
        } else if (process.env.NODE_ENV !== 'production') {
          // Development fallback only
          const fallback = INDUSTRY_TEMPLATES[industryTemplateId];
          if (fallback) {
            templateData = fallback;
          }
        }
      }

      res.json({
        clientId,
        botId,
        status: (botConfig.metadata as any)?.onboardingStatus || 'draft',
        workspaceStatus: workspace?.status || 'unknown',
        businessName: botConfig.businessProfile?.businessName,
        industryTemplate: industryTemplateId,
        kbDraft: {
          services: botConfig.businessProfile?.services || [],
          faqs: botConfig.faqs || [],
          policies: (botConfig.metadata as any)?.disclaimer || templateData?.disclaimer || '',
          hours: botConfig.businessProfile?.hours || {},
        },
        bookingConfig: (botConfig as any).automations?.bookingCapture,
        ctaButtons: botConfig.quickActions || templateData?.ctaButtons || [],
        widgetTheme: {
          primaryColor: templateData?.defaultConfig?.theme?.primaryColor || '#00E5CC',
          welcomeMessage: templateData?.defaultConfig?.theme?.welcomeMessage || 'Hello! How can I help?',
        },
      });
    } catch (error) {
      structuredLogger.error('[Agency Onboarding] Get draft error:', error);
      res.status(500).json({ error: 'Failed to get draft' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
