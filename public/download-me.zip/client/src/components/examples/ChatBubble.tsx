import ChatBubble from '../ChatBubble';

export default function ChatBubbleExample() {
  return <ChatBubble onClick={() => console.log('Chat bubble clicked')} />;
}
